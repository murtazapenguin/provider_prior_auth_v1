"""
Penguin LLM Types Module

Defines standardized response types for multi-provider LLM communication.
"""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from enum import Enum

from .messages import ToolCall


class FinishReason(str, Enum):
    """
    Standardized finish reasons across all providers.

    Mapping from providers:
    - OpenAI: stop, length, tool_calls, content_filter
    - Gemini: STOP, MAX_TOKENS, TOOL_USE, SAFETY
    - Claude: end_turn, max_tokens, tool_use, stop_sequence
    """
    STOP = "stop"
    LENGTH = "length"
    TOOL_CALLS = "tool_calls"
    CONTENT_FILTER = "content_filter"
    ERROR = "error"


class TokenUsage(BaseModel):
    """
    Standardized token usage across all providers.

    All providers report these core metrics, though naming differs:
    - OpenAI: prompt_tokens, completion_tokens, total_tokens
    - Gemini: prompt_token_count, candidates_token_count, total_token_count
    - Claude: input_tokens, output_tokens
    """
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0

    # Provider-specific extensions (optional)
    thinking_tokens: Optional[int] = None  # Gemini thinking mode
    cached_tokens: Optional[int] = None    # Anthropic prompt caching

    @property
    def input_tokens(self) -> int:
        """Alias for prompt_tokens (Claude naming)."""
        return self.prompt_tokens

    @property
    def output_tokens(self) -> int:
        """Alias for completion_tokens (Claude naming)."""
        return self.completion_tokens

    @property
    def billable_tokens(self) -> int:
        """Tokens used for billing (excludes cached)."""
        cached = self.cached_tokens or 0
        return self.total_tokens - cached

    def __add__(self, other: "TokenUsage") -> "TokenUsage":
        """Add two TokenUsage objects together."""
        return TokenUsage(
            prompt_tokens=self.prompt_tokens + other.prompt_tokens,
            completion_tokens=self.completion_tokens + other.completion_tokens,
            total_tokens=self.total_tokens + other.total_tokens,
            thinking_tokens=(self.thinking_tokens or 0) + (other.thinking_tokens or 0) or None,
            cached_tokens=(self.cached_tokens or 0) + (other.cached_tokens or 0) or None,
        )


class ChatCompletionResult(BaseModel):
    """
    Standardized completion result from any provider.

    This is the unified response format that all provider implementations
    must return from their create() method.
    """
    # Core response content
    content: Optional[Any] = None  # str for text, dict for structured output
    tool_calls: Optional[List[ToolCall]] = None
    thinking: Optional[str] = None  # Extended thinking content

    # Completion metadata
    finish_reason: FinishReason = FinishReason.STOP
    usage: TokenUsage = Field(default_factory=TokenUsage)

    # Provider info
    model: str
    provider: str

    # Raw response for debugging (excluded from serialization)
    raw_response: Optional[Any] = Field(default=None, exclude=True)

    # Additional metadata
    metadata: Dict[str, Any] = Field(default_factory=dict)

    @property
    def has_tool_calls(self) -> bool:
        """Check if this result contains tool calls."""
        return bool(self.tool_calls)

    @property
    def text(self) -> str:
        """Get content as string, handling structured output."""
        if self.content is None:
            return ""
        if isinstance(self.content, str):
            return self.content
        # For structured output, convert to string
        import json
        return json.dumps(self.content)

    def to_assistant_message(self) -> "AssistantMessage":
        """
        Convert this result to an AssistantMessage for multi-turn conversations.

        This method handles all provider-specific internal details (like signatures)
        automatically, so users don't need to worry about them.

        Usage:
            result = await client.create(messages, tools=tools)
            messages.append(result.to_assistant_message())
            messages.append(ToolMessage(...))  # Tool result
            result = await client.create(messages, tools=tools)  # Continue conversation
        """
        from .messages import AssistantMessage

        # Merge metadata to preserve provider-specific internal data
        # (e.g., thinking_signature for Claude, thought_signature in tool_calls for Gemini)
        return AssistantMessage(
            content=self.text if isinstance(self.content, str) else None,
            tool_calls=self.tool_calls,
            thinking=self.thinking,
            metadata=self.metadata,  # Carries internal signatures etc.
        )

    class Config:
        use_enum_values = True


class ChatCompletionChunk(BaseModel):
    """
    Streaming chunk from any provider.

    Used by create_stream() to yield incremental responses.
    """
    # Delta content (incremental)
    delta_content: Optional[str] = None
    delta_tool_calls: Optional[List[ToolCall]] = None
    delta_thinking: Optional[str] = None

    # Completion status (usually only in final chunk)
    finish_reason: Optional[FinishReason] = None
    usage: Optional[TokenUsage] = None  # Often only in final chunk

    # Provider info
    model: str
    provider: str
    chunk_index: int = 0

    @property
    def is_final(self) -> bool:
        """Check if this is the final chunk."""
        return self.finish_reason is not None

    class Config:
        use_enum_values = True


class ProviderCapabilities(BaseModel):
    """
    Declares what a provider supports.

    Used to check compatibility before making requests.
    """
    supports_streaming: bool = True
    supports_tool_calls: bool = True
    supports_vision: bool = False
    supports_thinking: bool = False
    supports_structured_output: bool = True
    supports_system_message: bool = True
    max_context_tokens: int = 128000
    max_output_tokens: int = 8192

    def validate_request(
        self,
        has_tools: bool = False,
        has_images: bool = False,
        wants_thinking: bool = False,
        wants_streaming: bool = False,
    ) -> List[str]:
        """
        Validate if provider can handle the request.

        Returns list of warning messages for unsupported features.
        """
        warnings = []

        if has_tools and not self.supports_tool_calls:
            warnings.append("Provider does not support tool calls")

        if has_images and not self.supports_vision:
            warnings.append("Provider does not support vision/images")

        if wants_thinking and not self.supports_thinking:
            warnings.append("Provider does not support thinking mode")

        if wants_streaming and not self.supports_streaming:
            warnings.append("Provider does not support streaming")

        return warnings
