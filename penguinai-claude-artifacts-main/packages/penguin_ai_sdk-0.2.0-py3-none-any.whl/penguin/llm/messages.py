"""
Penguin LLM Messages Module

Defines the message hierarchy for multi-provider LLM communication.
Based on OpenAI's message format as the common standard.
"""

from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, Field, field_validator
import uuid


class MessageRole:
    """Constants for message roles."""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


class ToolCall(BaseModel):
    """
    Represents a function/tool call from the assistant.

    This is the standardized format - each provider will convert
    to/from their native format.

    Attributes:
        call_id: Unique identifier for this tool call
        tool_name: Name of the tool/function to call
        parameters: Arguments to pass to the tool
        metadata: Provider-specific data (signatures, etc.) - handled internally
    """
    call_id: str = Field(default_factory=lambda: f"call_{uuid.uuid4().hex[:8]}")
    tool_name: str
    parameters: Dict[str, Any] = Field(default_factory=dict)
    metadata: Dict[str, Any] = Field(default_factory=dict)  # Internal provider data

    class Config:
        frozen = False
        arbitrary_types_allowed = True


class Message(BaseModel):
    """Base message class for all message types."""
    role: str
    content: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

    class Config:
        extra = "allow"


class SystemMessage(Message):
    """
    System instruction message.

    Sets the behavior, personality, or constraints for the assistant.
    Not all providers handle system messages the same way:
    - OpenAI: First message with role="system"
    - Gemini: Separate system_instruction parameter
    - Claude: system parameter in request body
    """
    role: str = MessageRole.SYSTEM
    content: str

    def __init__(self, content: str, **kwargs):
        super().__init__(role=MessageRole.SYSTEM, content=content, **kwargs)


class UserMessage(Message):
    """
    User input message.

    Represents a message from the user to the assistant.
    """
    role: str = MessageRole.USER
    content: str

    def __init__(self, content: str, **kwargs):
        super().__init__(role=MessageRole.USER, content=content, **kwargs)


class AssistantMessage(Message):
    """
    Assistant response message.

    Can contain:
    - text content (regular response)
    - tool_calls (function calling)
    - thinking (chain-of-thought for supported models)
    """
    role: str = MessageRole.ASSISTANT
    content: Optional[str] = None
    tool_calls: Optional[List[ToolCall]] = None
    thinking: Optional[str] = None  # For models with extended thinking (Gemini 2.0, Claude)

    def __init__(
        self,
        content: Optional[str] = None,
        tool_calls: Optional[List[ToolCall]] = None,
        thinking: Optional[str] = None,
        **kwargs
    ):
        super().__init__(
            role=MessageRole.ASSISTANT,
            content=content,
            **kwargs
        )
        self.tool_calls = tool_calls
        self.thinking = thinking

    @property
    def has_tool_calls(self) -> bool:
        """Check if this message contains tool calls."""
        return bool(self.tool_calls)


class ToolMessage(Message):
    """
    Tool/function result message.

    Contains the result of a tool execution that should be
    sent back to the model.
    """
    role: str = MessageRole.TOOL
    tool_call_id: str
    tool_name: str
    content: str  # JSON-serialized result or string
    is_error: bool = False

    def __init__(
        self,
        tool_call_id: str,
        tool_name: str,
        content: str,
        is_error: bool = False,
        **kwargs
    ):
        # Pass all required fields to Pydantic's __init__
        super().__init__(
            role=MessageRole.TOOL,
            content=content,
            tool_call_id=tool_call_id,
            tool_name=tool_name,
            is_error=is_error,
            **kwargs
        )


# Type alias for any message type
AnyMessage = Union[SystemMessage, UserMessage, AssistantMessage, ToolMessage, Message]


def create_message(role: str, content: str, **kwargs) -> Message:
    """
    Factory function to create appropriate message type based on role.

    Args:
        role: Message role (system, user, assistant, tool)
        content: Message content
        **kwargs: Additional arguments for specific message types

    Returns:
        Appropriate Message subclass instance
    """
    role_map = {
        MessageRole.SYSTEM: SystemMessage,
        MessageRole.USER: UserMessage,
        MessageRole.ASSISTANT: AssistantMessage,
        MessageRole.TOOL: ToolMessage,
    }

    msg_class = role_map.get(role, Message)

    if msg_class == ToolMessage:
        # ToolMessage requires additional fields
        return msg_class(
            tool_call_id=kwargs.pop("tool_call_id", ""),
            tool_name=kwargs.pop("tool_name", ""),
            content=content,
            **kwargs
        )
    elif msg_class == Message:
        return msg_class(role=role, content=content, **kwargs)
    else:
        return msg_class(content=content, **kwargs)
