"""
Penguin Gemini LLM Provider

Google Gemini implementation of BaseChatCompletionClient.
"""

import json
import logging
import os
import re
from typing import Any, AsyncGenerator, Dict, List, Optional, Type

logger = logging.getLogger("penguin.llm.gemini")

from google import genai
from google.genai import types
from pydantic import BaseModel

# Try to import json_repair for robust JSON parsing
try:
    from json_repair import repair_json
    HAS_JSON_REPAIR = True
except ImportError:
    HAS_JSON_REPAIR = False

from ..base import (
    BaseChatCompletionClient,
    ChatCompletionError,
    AuthenticationError,
)
from ..messages import (
    Message,
    SystemMessage,
    AssistantMessage,
    ToolMessage,
    ToolCall,
    MessageRole,
)
from ..types import (
    ChatCompletionResult,
    ChatCompletionChunk,
    TokenUsage,
    ProviderCapabilities,
    FinishReason,
)
from ..models import get_model


class GeminiChatClient(BaseChatCompletionClient):
    """
    Google Gemini chat completion client.

    Supports:
    - Gemini 3.x Pro/Flash (latest, uses thinking_level)
    - Gemini 2.5.x Pro/Flash/Flash-Lite (stable, uses thinking_budget)
    - Gemini 2.0.x Flash (deprecated March 3, 2026)
    - Structured output via JSON schema
    - Tool/function calling
    - Streaming responses
    """

    def __init__(
        self,
        model: str = "gemini-2.5-flash",
        api_key: Optional[str] = None,
        **kwargs: Any
    ):
        """
        Initialize Gemini client.

        Args:
            model: Model identifier (e.g., "gemini-2.0-flash")
            api_key: API key (falls back to GEMINI_API_KEY env var)
            **kwargs: Additional configuration
        """
        api_key = api_key or os.environ.get("GEMINI_API_KEY")
        if not api_key:
            raise AuthenticationError(
                "GEMINI_API_KEY environment variable is required",
                provider="gemini"
            )

        super().__init__(model=model, api_key=api_key, **kwargs)
        self.client = genai.Client(api_key=api_key)

        # Deprecation warning for Gemini 2.0 models
        if "gemini-2.0" in model:
            logger.warning(
                f"Model '{model}' will be retired on March 3, 2026. "
                "Consider migrating to 'gemini-2.5-flash' or 'gemini-2.5-flash-lite'."
            )

    @property
    def provider_name(self) -> str:
        return "gemini"

    @property
    def capabilities(self) -> ProviderCapabilities:
        # Get capabilities from centralized model registry
        model_info = get_model(self.model)
        return ProviderCapabilities(
            supports_streaming=True,
            supports_tool_calls=True,
            supports_vision=model_info.supports_vision if model_info else False,
            supports_thinking=model_info.supports_thinking if model_info else False,
            supports_structured_output=True,
            supports_system_message=True,
            max_context_tokens=model_info.context_window if model_info else 1000000,
            max_output_tokens=model_info.max_tokens if model_info else 8192,
        )

    # ================== THINKING MODE HELPERS ==================

    def _has_default_thinking(self) -> bool:
        """
        Check if model has thinking enabled by default.

        Gemini 3.x models and 2.5.x models have thinking ON by default,
        meaning you will be charged for thinking tokens even if you don't
        explicitly request thinking mode.
        """
        model_info = get_model(self.model)
        if model_info:
            return getattr(model_info, 'thinking_default', False)
        # Fallback: check model name patterns
        default_thinking_patterns = [
            "gemini-3-pro", "gemini-3-flash",
            "gemini-2.5-pro", "gemini-2.5-flash"
        ]
        return any(pattern in self.model for pattern in default_thinking_patterns)

    def _can_disable_thinking(self) -> bool:
        """
        Check if thinking can be disabled for this model.

        Gemini 3 Pro cannot disable thinking at all.
        Gemini 3 Flash can reduce thinking with thinkingLevel="minimal".
        Gemini 2.5.x can disable with thinkingBudget=0.
        """
        model_info = get_model(self.model)
        if model_info:
            return getattr(model_info, 'thinking_disableable', True)
        # Fallback: Gemini 3 Pro (non-flash) cannot disable
        if "gemini-3-pro" in self.model and "flash" not in self.model:
            return False
        return True

    def _is_gemini_3x(self) -> bool:
        """Check if this is a Gemini 3.x model (uses thinking_level)."""
        return "gemini-3" in self.model

    def _is_gemini_25x(self) -> bool:
        """Check if this is a Gemini 2.5.x model (uses thinking_budget)."""
        return "gemini-2.5" in self.model or "2.5" in self.model

    def _is_gemini_20x(self) -> bool:
        """Check if this is a Gemini 2.0.x model (deprecated)."""
        return "gemini-2.0" in self.model or "2.0" in self.model

    # ================== MESSAGE CONVERSION ==================

    def _convert_messages(self, messages: List[Message]) -> tuple:
        """
        Convert Penguin messages to Gemini Content format.

        Returns:
            Tuple of (contents list, system_instruction string or None)
        """
        contents = []
        system_instruction = None

        for msg in messages:
            # System messages are handled separately in Gemini
            if isinstance(msg, SystemMessage):
                system_instruction = msg.content
                continue

            role = self._map_role(msg.role)
            parts = self._convert_to_parts(msg)
            contents.append(types.Content(role=role, parts=parts))

        return contents, system_instruction

    def _map_role(self, role: str) -> str:
        """Map standard roles to Gemini roles."""
        mapping = {
            MessageRole.USER: "user",
            MessageRole.ASSISTANT: "model",
            MessageRole.TOOL: "user",  # Tool results go as user messages
        }
        return mapping.get(role, "user")

    def _convert_to_parts(self, msg: Message) -> List[types.Part]:
        """Convert message content to Gemini Parts."""
        parts = []

        if isinstance(msg, ToolMessage):
            # Tool result as function response
            parts.append(types.Part.from_function_response(
                name=msg.tool_name,
                response={"result": msg.content}
            ))
        elif isinstance(msg, AssistantMessage):
            # Assistant message with optional tool calls
            if msg.content:
                parts.append(types.Part.from_text(text=msg.content))
            if msg.tool_calls:
                for tc in msg.tool_calls:
                    # Extract thought_signature from metadata (Gemini 3 requires this for multi-turn)
                    # This is handled internally - users don't need to know about it
                    thought_sig = tc.metadata.get("thought_signature") if tc.metadata else None
                    if thought_sig:
                        # Use Part constructor to include thought_signature
                        func_call_part = types.Part(
                            function_call=types.FunctionCall(
                                name=tc.tool_name,
                                args=tc.parameters
                            ),
                            thought_signature=thought_sig
                        )
                    else:
                        # No thought_signature - use factory method
                        func_call_part = types.Part.from_function_call(
                            name=tc.tool_name,
                            args=tc.parameters
                        )
                    parts.append(func_call_part)
        else:
            # Regular user message
            parts.append(types.Part.from_text(text=msg.content or ""))

        return parts

    def _convert_tools(
        self,
        tools: Optional[List[Dict[str, Any]]]
    ) -> Optional[List[types.Tool]]:
        """
        Convert OpenAI-format tools to Gemini format.

        Gemini expects tools as types.Tool objects with FunctionDeclaration.
        """
        if not tools:
            return None

        function_declarations = []
        for tool in tools:
            # Handle OpenAI format: {"type": "function", "function": {...}}
            if "type" in tool and tool["type"] == "function":
                func_def = tool["function"]
                schema = func_def.get("parameters", {})
            else:
                # Flat format - check for both "parameters" and "input_schema" (Anthropic format)
                func_def = tool
                schema = tool.get("input_schema") or tool.get("parameters", {})

            # Build FunctionDeclaration
            func_decl = types.FunctionDeclaration(
                name=func_def.get("name", ""),
                description=func_def.get("description", ""),
                parameters=self._convert_schema_to_gemini(schema)
            )
            function_declarations.append(func_decl)

        return [types.Tool(function_declarations=function_declarations)]

    def _convert_schema_to_gemini(self, schema: Dict[str, Any]) -> Dict[str, Any]:
        """Convert JSON Schema to Gemini-compatible format (uppercase types)."""
        if not schema:
            return {}

        result = {}

        # Convert type to uppercase
        if "type" in schema:
            result["type"] = schema["type"].upper()

        if "properties" in schema:
            result["properties"] = {
                key: self._convert_schema_to_gemini(value)
                for key, value in schema["properties"].items()
            }

        if "items" in schema:
            result["items"] = self._convert_schema_to_gemini(schema["items"])

        if "required" in schema:
            result["required"] = schema["required"]

        if "description" in schema:
            result["description"] = schema["description"]

        if "enum" in schema:
            result["enum"] = schema["enum"]

        return result

    # ================== RESPONSE NORMALIZATION ==================

    def _normalize_response(self, response: Any) -> ChatCompletionResult:
        """Normalize Gemini response to standard format."""
        candidate = response.candidates[0] if response.candidates else None

        content = None
        tool_calls = None
        thinking = None

        if candidate and candidate.content and candidate.content.parts:
            text_parts = []
            thinking_parts = []
            for part in candidate.content.parts:
                # Check if this part is a "thought" (thinking content)
                # Gemini returns thought=True for thinking parts, the content is in text
                is_thought = getattr(part, 'thought', False)

                # Handle text content
                if hasattr(part, 'text') and part.text:
                    if is_thought:
                        # This is thinking content
                        thinking_parts.append(part.text)
                    else:
                        # This is regular content
                        text_parts.append(part.text)
                # Handle function calls
                elif hasattr(part, 'function_call') and part.function_call:
                    if tool_calls is None:
                        tool_calls = []
                    # Capture thought_signature in metadata (Gemini 3 requires this for multi-turn)
                    # Stored internally - users don't need to handle this
                    thought_sig = getattr(part, 'thought_signature', None)
                    metadata = {"thought_signature": thought_sig} if thought_sig else {}
                    tool_calls.append(ToolCall(
                        call_id=f"call_{len(tool_calls)}",
                        tool_name=part.function_call.name,
                        parameters=dict(part.function_call.args) if part.function_call.args else {},
                        metadata=metadata
                    ))

            content = "\n".join(text_parts) if text_parts else None
            thinking = "\n".join(thinking_parts) if thinking_parts else None

        # Handle structured output (parsed JSON)
        if hasattr(response, 'parsed') and response.parsed is not None:
            content = response.parsed

        finish_reason = self._map_finish_reason(candidate)
        usage = self._normalize_usage(response.usage_metadata)

        return ChatCompletionResult(
            content=content,
            tool_calls=tool_calls,
            thinking=thinking,
            finish_reason=finish_reason,
            usage=usage,
            model=self.model,
            provider=self.provider_name,
            raw_response=response,
        )

    def _map_finish_reason(self, candidate: Any) -> FinishReason:
        """Map Gemini finish reason to standard format."""
        if not candidate:
            return FinishReason.ERROR

        finish = getattr(candidate, 'finish_reason', None)
        if finish:
            finish_str = str(finish)
            mapping = {
                "STOP": FinishReason.STOP,
                "MAX_TOKENS": FinishReason.LENGTH,
                "TOOL_USE": FinishReason.TOOL_CALLS,
                "SAFETY": FinishReason.CONTENT_FILTER,
                "RECITATION": FinishReason.CONTENT_FILTER,
                # Gemini 3 Pro Preview bug - returns this when tool calling fails
                "UNEXPECTED_TOOL_CALL": FinishReason.ERROR,
            }
            return mapping.get(finish_str, FinishReason.STOP)
        return FinishReason.STOP

    def _normalize_usage(self, usage: Any) -> TokenUsage:
        """Normalize Gemini usage metadata to standard format."""
        if not usage:
            return TokenUsage()
        return TokenUsage(
            prompt_tokens=getattr(usage, 'prompt_token_count', 0) or 0,
            completion_tokens=getattr(usage, 'candidates_token_count', 0) or 0,
            total_tokens=getattr(usage, 'total_token_count', 0) or 0,
        )

    def _convert_schema_types(self, schema: Dict) -> Dict:
        """Convert JSON Schema types to Gemini format (uppercase)."""
        type_mapping = {
            "string": "STRING",
            "integer": "INTEGER",
            "number": "NUMBER",
            "boolean": "BOOLEAN",
            "array": "ARRAY",
            "object": "OBJECT",
        }

        result = schema.copy()

        if "type" in result:
            result["type"] = type_mapping.get(result["type"], result["type"])

        if "properties" in result:
            result["properties"] = {
                key: self._convert_schema_types(value)
                for key, value in result["properties"].items()
            }

        if "items" in result:
            result["items"] = self._convert_schema_types(result["items"])

        return result

    def _extract_and_parse_json(self, content: str) -> Optional[Dict[str, Any]]:
        """
        Extract and parse JSON from LLM response content.

        Handles:
        - Plain JSON
        - JSON wrapped in markdown code blocks (```json ... ```)
        - Malformed JSON (using json_repair if available)

        Args:
            content: Raw content from LLM response

        Returns:
            Parsed JSON dict if successful, None otherwise
        """
        if not content:
            return None

        # Step 1: Try to extract JSON from markdown code blocks
        # Matches ```json ... ``` or ``` ... ```
        code_block_pattern = r"```(?:json)?\s*([\s\S]*?)```"
        matches = re.findall(code_block_pattern, content, re.IGNORECASE)

        # Use the first code block if found, otherwise use original content
        json_str = matches[0].strip() if matches else content.strip()

        # Step 2: Try direct JSON parsing
        try:
            return json.loads(json_str)
        except json.JSONDecodeError:
            pass

        # Step 3: Try json_repair if available
        if HAS_JSON_REPAIR:
            try:
                repaired = repair_json(json_str, return_objects=True)
                if isinstance(repaired, dict):
                    return repaired
            except Exception:
                pass

        # Step 4: Try to find JSON object in the string (fallback)
        # Look for content between first { and last }
        try:
            start_idx = json_str.find('{')
            end_idx = json_str.rfind('}')
            if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
                potential_json = json_str[start_idx:end_idx + 1]
                return json.loads(potential_json)
        except json.JSONDecodeError:
            pass

        # Step 5: Try json_repair on extracted portion
        if HAS_JSON_REPAIR:
            try:
                start_idx = json_str.find('{')
                end_idx = json_str.rfind('}')
                if start_idx != -1 and end_idx != -1:
                    potential_json = json_str[start_idx:end_idx + 1]
                    repaired = repair_json(potential_json, return_objects=True)
                    if isinstance(repaired, dict):
                        return repaired
            except Exception:
                pass

        return None

    # ================== API CALLS ==================

    async def _create_impl(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[Type[BaseModel]] = None,
        temperature: float = 0.7,
        max_tokens: int = 8192,
        thinking: bool = False,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Execute Gemini API call (implementation).

        Args:
            messages: Conversation messages
            tools: Tool definitions
            output_format: Pydantic model for structured output
            temperature: Sampling temperature
            max_tokens: Maximum output tokens
            thinking: Enable extended thinking (Gemini 2.0+)
            **kwargs: Additional parameters (seed, etc.)
        """
        contents, system_instruction = self._convert_messages(messages)

        # Build config
        config_params = {
            "temperature": temperature,
            "max_output_tokens": max_tokens,
        }

        if "seed" in kwargs:
            config_params["seed"] = kwargs["seed"]

        if system_instruction:
            config_params["system_instruction"] = system_instruction

        # Structured output (supports both Pydantic models and raw schema dicts)
        if output_format:
            config_params["response_mime_type"] = "application/json"
            schema, _ = self._normalize_schema(output_format)
            config_params["response_schema"] = self._convert_schema_types(schema)

        # Extended thinking mode
        # Handle models with thinking enabled by default (Gemini 3.x, 2.5.x)
        has_default_thinking = self._has_default_thinking()

        if has_default_thinking:
            # Models with default thinking - always capture thoughts
            config_params["thinking_config"] = types.ThinkingConfig(
                include_thoughts=True
            )

            if thinking is False:
                # User explicitly wants to disable/minimize thinking
                if self._can_disable_thinking():
                    if self._is_gemini_3x():
                        # Gemini 3.x: use thinkingLevel to minimize
                        config_params["thinking_config"] = types.ThinkingConfig(
                            include_thoughts=True,
                            thinking_level="minimal"
                        )
                    else:
                        # Gemini 2.5.x: use thinkingBudget=0 to disable
                        config_params["thinking_config"] = types.ThinkingConfig(
                            include_thoughts=True,
                            thinking_budget=0
                        )
                else:
                    # Model cannot disable thinking (e.g., Gemini 3 Pro, Gemini 2.5 Pro)
                    logger.warning(
                        f"Model '{self.model}' has thinking enabled by default and cannot be disabled. "
                        "You will be charged for thinking tokens."
                    )
        elif thinking and self.capabilities.supports_thinking:
            # User explicitly requested thinking on a model where it's off by default
            if self._is_gemini_25x():
                # Gemini 2.5.x (e.g., flash-lite): need thinking_budget=-1 to enable
                config_params["thinking_config"] = types.ThinkingConfig(
                    include_thoughts=True,
                    thinking_budget=-1  # Dynamic thinking
                )
            else:
                config_params["thinking_config"] = types.ThinkingConfig(
                    include_thoughts=True
                )

        # Tools
        converted_tools = self._convert_tools(tools)
        if converted_tools:
            config_params["tools"] = converted_tools
            # Warn about known Gemini 3 Pro Preview tool calling issues
            if "gemini-3" in self.model and "preview" in self.model:
                import logging
                logging.getLogger("penguin.llm").warning(
                    f"Gemini 3 Pro Preview ({self.model}) has known tool calling issues. "
                    "Consider using 'gemini-2.5-flash' for more reliable tool calling."
                )

        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=contents,
                config=types.GenerateContentConfig(**config_params)
            )
            result = self._normalize_response(response)

            # Parse structured output if requested (fallback if response.parsed wasn't available)
            if output_format and result.content and isinstance(result.content, str):
                parsed = self._extract_and_parse_json(result.content)
                if parsed is not None:
                    result.content = parsed

            return result

        except Exception as e:
            raise ChatCompletionError(
                message=str(e),
                provider=self.provider_name
            )

    async def _create_stream_impl(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[Type[BaseModel]] = None,
        temperature: float = 0.7,
        max_tokens: int = 8192,
        thinking: bool = False,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Execute streaming Gemini API call (implementation).

        Yields ChatCompletionChunk objects with incremental content.
        Supports tool calls and extended thinking in streaming mode.
        """
        contents, system_instruction = self._convert_messages(messages)

        config_params = {
            "temperature": temperature,
            "max_output_tokens": max_tokens,
        }

        if system_instruction:
            config_params["system_instruction"] = system_instruction

        # Extended thinking mode
        # Handle models with thinking enabled by default (Gemini 3.x, 2.5.x)
        has_default_thinking = self._has_default_thinking()

        if has_default_thinking:
            # Models with default thinking - always capture thoughts
            config_params["thinking_config"] = types.ThinkingConfig(
                include_thoughts=True
            )

            if thinking is False:
                # User explicitly wants to disable/minimize thinking
                if self._can_disable_thinking():
                    if self._is_gemini_3x():
                        # Gemini 3.x: use thinkingLevel to minimize
                        config_params["thinking_config"] = types.ThinkingConfig(
                            include_thoughts=True,
                            thinking_level="minimal"
                        )
                    else:
                        # Gemini 2.5.x: use thinkingBudget=0 to disable
                        config_params["thinking_config"] = types.ThinkingConfig(
                            include_thoughts=True,
                            thinking_budget=0
                        )
                else:
                    # Model cannot disable thinking (e.g., Gemini 3 Pro, Gemini 2.5 Pro)
                    logger.warning(
                        f"Model '{self.model}' has thinking enabled by default and cannot be disabled. "
                        "You will be charged for thinking tokens."
                    )
        elif thinking and self.capabilities.supports_thinking:
            # User explicitly requested thinking on a model where it's off by default
            if self._is_gemini_25x():
                # Gemini 2.5.x (e.g., flash-lite): need thinking_budget=-1 to enable
                config_params["thinking_config"] = types.ThinkingConfig(
                    include_thoughts=True,
                    thinking_budget=-1  # Dynamic thinking
                )
            else:
                config_params["thinking_config"] = types.ThinkingConfig(
                    include_thoughts=True
                )

        # Tools support in streaming
        converted_tools = self._convert_tools(tools)
        if converted_tools:
            config_params["tools"] = converted_tools

        try:
            # Use streaming endpoint
            stream = self.client.models.generate_content_stream(
                model=self.model,
                contents=contents,
                config=types.GenerateContentConfig(**config_params)
            )

            chunk_index = 0
            accumulated_tool_calls: List[ToolCall] = []
            finish_reason = None

            for chunk in stream:
                delta_content = None
                delta_tool_calls = None
                delta_thinking = None

                # Extract content from candidates (for thinking support)
                if hasattr(chunk, 'candidates') and chunk.candidates:
                    candidate = chunk.candidates[0]
                    if hasattr(candidate, 'content') and candidate.content:
                        for part in candidate.content.parts:
                            # Check if this is a thinking part
                            is_thought = getattr(part, 'thought', False)

                            if hasattr(part, 'text') and part.text:
                                if is_thought:
                                    delta_thinking = part.text
                                else:
                                    delta_content = part.text

                            elif hasattr(part, 'function_call') and part.function_call:
                                # Capture thought_signature in metadata (Gemini 3 requires for multi-turn)
                                thought_sig = getattr(part, 'thought_signature', None)
                                metadata = {"thought_signature": thought_sig} if thought_sig else {}
                                tool_call = ToolCall(
                                    call_id=f"call_{len(accumulated_tool_calls)}",
                                    tool_name=part.function_call.name,
                                    parameters=dict(part.function_call.args) if part.function_call.args else {},
                                    metadata=metadata
                                )
                                accumulated_tool_calls.append(tool_call)
                                delta_tool_calls = [tool_call]

                    # Check finish reason
                    if hasattr(candidate, 'finish_reason') and candidate.finish_reason:
                        finish_reason = self._map_finish_reason(candidate)

                # Fallback: direct text access (for non-thinking mode)
                elif hasattr(chunk, 'text') and chunk.text:
                    delta_content = chunk.text

                yield ChatCompletionChunk(
                    delta_content=delta_content,
                    delta_tool_calls=delta_tool_calls,
                    delta_thinking=delta_thinking,
                    finish_reason=None,  # Only emit finish_reason in final chunk
                    usage=None,
                    model=self.model,
                    provider=self.provider_name,
                    chunk_index=chunk_index,
                )
                chunk_index += 1

            # Final chunk with finish reason
            # If we accumulated tool calls, set finish reason to TOOL_CALLS
            if accumulated_tool_calls and finish_reason is None:
                finish_reason = FinishReason.TOOL_CALLS
            elif finish_reason is None:
                finish_reason = FinishReason.STOP

            yield ChatCompletionChunk(
                delta_content=None,
                delta_tool_calls=None,
                finish_reason=finish_reason,
                usage=None,
                model=self.model,
                provider=self.provider_name,
                chunk_index=chunk_index,
            )

        except Exception as e:
            raise ChatCompletionError(
                message=str(e),
                provider=self.provider_name
            )


# Backward compatibility alias
GeminiLLMProvider = GeminiChatClient
