"""
Penguin LLM Module (DEPRECATED)

.. deprecated:: 0.2.0
    Use ``penguin.core`` instead. This module provides backward-compatible
    shims that delegate to the new LangChain-based core.

New Usage:
    from penguin.core import create_model
    model = create_model(provider="bedrock", model="claude-sonnet-4-5")
    result = model.invoke([SystemMessage(...), HumanMessage(...)])
"""

import warnings as _warnings

_warnings.warn(
    "penguin.llm is deprecated since v0.2.0. Use penguin.core instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export new API under old names
from penguin.core.models import (
    create_model,
    create_model_from_env,
    list_models,
    get_model_info,
    get_model_capabilities,
    ModelInfo,
    Provider,
    MODEL_REGISTRY,
)

# Backward-compatible aliases
create_client = create_model
create_client_from_env = create_model_from_env
get_model = get_model_info
get_available_providers = lambda: [p.value for p in Provider]

# Re-export LangChain message types for compatibility
from langchain_core.messages import (
    SystemMessage,
    HumanMessage as UserMessage,
    AIMessage as AssistantMessage,
    ToolMessage,
)

# Legacy types - import from old modules that are still on disk
from .messages import MessageRole, AnyMessage, create_message, Message, ToolCall

# Old model registry helpers
from penguin.core.models import MODEL_REGISTRY as MODELS


def get_default_model(provider: str) -> str:
    from penguin.core.models import DEFAULT_MODELS, Provider as P
    try:
        return DEFAULT_MODELS[P(provider)]
    except (ValueError, KeyError):
        raise ValueError(f"Unknown provider: {provider}")


def get_vision_models(provider=None):
    return {m.id for m in list_models(provider) if m.supports_vision}


def get_thinking_models(provider=None):
    return {m.id for m in list_models(provider) if m.supports_thinking}


__all__ = [
    "create_client",
    "create_client_from_env",
    "create_model",
    "create_model_from_env",
    "get_available_providers",
    "ModelInfo",
    "Provider",
    "list_models",
    "get_model",
    "get_default_model",
    "get_vision_models",
    "get_thinking_models",
    "get_model_capabilities",
    "SystemMessage",
    "UserMessage",
    "AssistantMessage",
    "ToolMessage",
]
