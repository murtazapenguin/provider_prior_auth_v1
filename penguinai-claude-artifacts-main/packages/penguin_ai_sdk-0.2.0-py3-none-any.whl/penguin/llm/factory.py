"""
Penguin LLM Factory Module

Factory functions for creating LLM clients with provider auto-detection.
Includes automatic middleware wrapping for tracing when enabled.
"""

import os
from typing import Optional, Union

from .base import BaseChatCompletionClient
from .middleware import MiddlewareWrappedClient
from .models import get_default_model, list_models, get_model


# Provider registry - lazy imports to avoid loading all dependencies
PROVIDER_CLASSES = {
    "gemini": ("penguin.llm.providers.gemini", "GeminiChatClient"),
    "openai": ("penguin.llm.providers.openai", "OpenAIChatClient"),
    "azure_openai": ("penguin.llm.providers.azure_openai", "AzureOpenAIChatClient"),
    "bedrock": ("penguin.llm.providers.bedrock", "BedrockClaudeChatClient"),
}


def _import_provider_class(provider: str) -> type:
    """Dynamically import provider class to avoid loading all dependencies."""
    if provider not in PROVIDER_CLASSES:
        raise ValueError(
            f"Unknown provider: {provider}. "
            f"Available providers: {', '.join(PROVIDER_CLASSES.keys())}"
        )

    module_path, class_name = PROVIDER_CLASSES[provider]

    import importlib
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def create_client(
    provider: str,
    model: Optional[str] = None,
    api_key: Optional[str] = None,
    enable_tracing: Optional[bool] = None,
    **kwargs
) -> Union[BaseChatCompletionClient, MiddlewareWrappedClient]:
    """
    Create an LLM client for the specified provider.

    When tracing is enabled (via PENGUIN_ENABLE_TRACING env var or enable_tracing param),
    the client is automatically wrapped with middleware for automatic span creation.

    Args:
        provider: Provider name ("gemini", "openai", "bedrock")
        model: Model identifier (uses provider default if not specified)
        api_key: API key (falls back to environment variable)
        enable_tracing: Override tracing (None = use env var, True/False = force)
        **kwargs: Additional provider-specific configuration

    Returns:
        Configured LLM client (wrapped with middleware if tracing enabled)

    Example:
        # Create Gemini client
        client = create_client("gemini", model="gemini-2.0-flash")

        # Create OpenAI client with custom API key
        client = create_client("openai", api_key="sk-...")

        # Create Bedrock client with region
        client = create_client("bedrock", region_name="us-west-2")

        # Force enable tracing
        client = create_client("bedrock", enable_tracing=True)
    """
    provider = provider.lower()

    # Use default model if not specified
    if model is None:
        model = get_default_model(provider)

    # Import and instantiate the provider class
    client_class = _import_provider_class(provider)

    # Build kwargs
    init_kwargs = {"model": model, **kwargs}
    if api_key:
        init_kwargs["api_key"] = api_key

    # Create the raw client
    client = client_class(**init_kwargs)

    # Determine if tracing should be enabled
    if enable_tracing is None:
        # Check environment variable
        from penguin.observability import is_tracing_enabled
        tracing = is_tracing_enabled()
    else:
        tracing = enable_tracing

    # Wrap with middleware if tracing enabled
    if tracing:
        # Ensure tracing is set up (creates file exporter if not already done)
        from penguin.observability import setup_tracing, is_tracing_enabled
        if not is_tracing_enabled():
            # Force setup if enable_tracing=True was passed but env var not set
            import os
            os.environ["PENGUIN_ENABLE_TRACING"] = "true"
        setup_tracing()  # Idempotent - safe to call multiple times

        from .middleware import MiddlewareWrappedClient, get_llm_middleware_chain
        chain = get_llm_middleware_chain()
        return MiddlewareWrappedClient(client, chain)

    return client


def create_client_from_env(
    enable_tracing: Optional[bool] = None
) -> Union[BaseChatCompletionClient, "MiddlewareWrappedClient"]:
    """
    Create an LLM client based on environment variables.

    Environment variables checked (in order):
        - PENGUIN_LLM_PROVIDER: Provider name (gemini, openai, bedrock)
        - PENGUIN_LLM_MODEL: Model identifier
        - PENGUIN_ENABLE_TRACING: Enable automatic tracing (true/1)

    Falls back to provider auto-detection based on available API keys:
        1. OPENAI_API_KEY -> OpenAI
        2. GEMINI_API_KEY -> Gemini
        3. AWS credentials -> Bedrock

    Args:
        enable_tracing: Override tracing (None = use env var, True/False = force)

    Returns:
        Configured LLM client (wrapped with middleware if tracing enabled)

    Raises:
        ValueError: If no provider can be determined

    Example:
        # Set environment and create client
        os.environ["PENGUIN_LLM_PROVIDER"] = "openai"
        os.environ["PENGUIN_LLM_MODEL"] = "gpt-4o-mini"
        client = create_client_from_env()
    """
    # Check explicit provider setting
    provider = os.environ.get("PENGUIN_LLM_PROVIDER", "").lower()
    model = os.environ.get("PENGUIN_LLM_MODEL")

    if provider:
        return create_client(provider, model=model, enable_tracing=enable_tracing)

    # Auto-detect based on available credentials
    if os.environ.get("OPENAI_API_KEY"):
        return create_client("openai", model=model, enable_tracing=enable_tracing)

    # Check for Azure OpenAI credentials
    if os.environ.get("AZURE_OPENAI_API_KEY") and os.environ.get("AZURE_OPENAI_ENDPOINT"):
        return create_client("azure_openai", model=model, enable_tracing=enable_tracing)

    if os.environ.get("GEMINI_API_KEY"):
        return create_client("gemini", model=model, enable_tracing=enable_tracing)

    # Check for AWS credentials (multiple methods)
    if any([
        os.environ.get("AWS_ACCESS_KEY_ID"),
        os.environ.get("AWS_PROFILE"),
        os.environ.get("AWS_ROLE_ARN"),
    ]):
        return create_client("bedrock", model=model, enable_tracing=enable_tracing)

    raise ValueError(
        "Could not determine LLM provider. Set PENGUIN_LLM_PROVIDER environment variable "
        "or configure one of: OPENAI_API_KEY, AZURE_OPENAI_API_KEY+AZURE_OPENAI_ENDPOINT, "
        "GEMINI_API_KEY, or AWS credentials."
    )


def get_available_providers() -> list:
    """
    Get list of available providers based on installed dependencies.

    Returns:
        List of provider names that have their dependencies installed
    """
    available = []

    # Check Gemini
    try:
        from google import genai  # noqa: F401
        available.append("gemini")
    except ImportError:
        pass

    # Check OpenAI
    try:
        import openai  # noqa: F401
        available.append("openai")
    except ImportError:
        pass

    # Check Bedrock (boto3)
    try:
        import boto3  # noqa: F401
        available.append("bedrock")
    except ImportError:
        pass

    return available
