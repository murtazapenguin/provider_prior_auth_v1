"""
Penguin LLM Conversation Registry Module

Provides persistence and retrieval of chat sessions.

Convenience functions (no registry instantiation needed):
    from penguin.llm import list_sessions, get_session, delete_session

    # List all saved sessions
    sessions = list_sessions()

    # Load a specific session
    session = get_session(session_id, client)

    # Delete a session
    delete_session(session_id)
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .base import BaseChatCompletionClient
from .session import ChatSession


logger = logging.getLogger("penguin.llm.registry")


# ================== CONVENIENCE FUNCTIONS ==================
# These allow working with sessions without instantiating a registry

_default_registry: Optional["ConversationRegistry"] = None


def _get_default_registry(backend: str = "file") -> "ConversationRegistry":
    """Get or create the default registry singleton."""
    global _default_registry
    if _default_registry is None or _default_registry.backend != backend:
        _default_registry = ConversationRegistry(backend=backend)
    return _default_registry


def list_sessions(
    backend: str = "file",
    limit: int = 100,
    offset: int = 0,
) -> List["SessionSummary"]:
    """
    List all saved chat sessions.

    Args:
        backend: Storage backend ("file" or "memory")
        limit: Maximum number of sessions to return
        offset: Number of sessions to skip

    Returns:
        List of SessionSummary objects

    Example:
        from penguin.llm import list_sessions

        for session in list_sessions():
            print(f"{session.session_id}: {session.message_count} messages")
    """
    registry = _get_default_registry(backend)
    return registry.list_sessions(limit=limit, offset=offset)


def get_session(
    session_id: str,
    client: "BaseChatCompletionClient",
    backend: str = "file",
) -> Optional["ChatSession"]:
    """
    Load a chat session by ID.

    Args:
        session_id: The session ID to load
        client: LLM client to use for the restored session
        backend: Storage backend ("file" or "memory")

    Returns:
        The restored ChatSession, or None if not found

    Example:
        from penguin.llm import get_session, create_client

        client = create_client("bedrock", model="claude-sonnet-4-5")
        session = get_session("my-session-id", client)
        if session:
            response = await session.send("Continue our conversation")
    """
    registry = _get_default_registry(backend)
    return registry.load(session_id, client)


def delete_session(session_id: str, backend: str = "file") -> bool:
    """
    Delete a chat session by ID.

    Args:
        session_id: The session ID to delete
        backend: Storage backend ("file" or "memory")

    Returns:
        True if deleted, False if not found

    Example:
        from penguin.llm import delete_session

        if delete_session("old-session-id"):
            print("Session deleted")
    """
    registry = _get_default_registry(backend)
    return registry.delete(session_id)


def session_exists(session_id: str, backend: str = "file") -> bool:
    """
    Check if a session exists.

    Args:
        session_id: The session ID to check
        backend: Storage backend ("file" or "memory")

    Returns:
        True if exists, False otherwise

    Example:
        from penguin.llm import session_exists

        if session_exists("my-session-id"):
            print("Session found!")
    """
    registry = _get_default_registry(backend)
    return registry.exists(session_id)


class SessionSummary(BaseModel):
    """
    Summary information about a saved session.

    Used for listing sessions without loading full history.
    """

    session_id: str
    created_at: datetime
    message_count: int
    model: str
    provider: str
    system_instruction: Optional[str] = None
    last_message_preview: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}


class ConversationRegistry:
    """
    Stores and retrieves chat sessions.

    Supports multiple storage backends:
    - memory: In-memory storage (default, non-persistent)
    - file: JSON file storage (persistent)

    Example:
        ```python
        from penguin.llm import create_client, ChatSession, ConversationRegistry

        # Create registry with file storage
        registry = ConversationRegistry(backend="file")

        # Create and use a session
        client = create_client("gemini", model="gemini-2.0-flash")
        session = ChatSession(client, system_instruction="You are helpful.")
        await session.send("Hello!")

        # Save session
        registry.save(session)

        # Later, restore the session
        restored = registry.load(session.session_id, client)
        await restored.send("Continue our conversation...")

        # List all sessions
        for summary in registry.list_sessions():
            print(f"{summary.session_id}: {summary.message_count} messages")
        ```
    """

    def __init__(
        self,
        backend: str = "file",
        storage_path: Optional[Path] = None,
    ):
        """
        Initialize the conversation registry.

        Args:
            backend: Storage backend ("memory" or "file")
            storage_path: Path for file storage (default: ~/.penguin/conversations)
        """
        self.backend = backend
        self.storage_path = storage_path or Path.home() / ".penguin" / "conversations"

        # In-memory storage
        self._sessions: Dict[str, Dict[str, Any]] = {}

        # Initialize file backend if needed
        if backend == "file":
            self.storage_path.mkdir(parents=True, exist_ok=True)
            logger.info(f"ConversationRegistry using file storage at {self.storage_path}")
        else:
            logger.info("ConversationRegistry using in-memory storage")

    def save(self, session: ChatSession) -> str:
        """
        Save a session to the registry.

        Args:
            session: The ChatSession to save

        Returns:
            The session ID
        """
        session_data = session.to_dict()

        if self.backend == "file":
            self._save_to_file(session.session_id, session_data)
        else:
            self._sessions[session.session_id] = session_data

        logger.debug(f"Saved session {session.session_id}")
        return session.session_id

    def load(
        self,
        session_id: str,
        client: BaseChatCompletionClient,
    ) -> Optional[ChatSession]:
        """
        Load a session from the registry.

        Args:
            session_id: The session ID to load
            client: LLM client to use for the restored session

        Returns:
            The restored ChatSession, or None if not found
        """
        session_data = None

        if self.backend == "file":
            session_data = self._load_from_file(session_id)
        else:
            session_data = self._sessions.get(session_id)

        if session_data is None:
            logger.warning(f"Session {session_id} not found")
            return None

        session = ChatSession.from_dict(session_data, client)
        logger.debug(f"Loaded session {session_id}")
        return session

    def delete(self, session_id: str) -> bool:
        """
        Delete a session from the registry.

        Args:
            session_id: The session ID to delete

        Returns:
            True if deleted, False if not found
        """
        if self.backend == "file":
            return self._delete_file(session_id)
        else:
            if session_id in self._sessions:
                del self._sessions[session_id]
                logger.debug(f"Deleted session {session_id}")
                return True
            return False

    def list_sessions(
        self,
        limit: int = 100,
        offset: int = 0,
    ) -> List[SessionSummary]:
        """
        List all saved sessions.

        Args:
            limit: Maximum number of sessions to return
            offset: Number of sessions to skip

        Returns:
            List of SessionSummary objects
        """
        summaries: List[SessionSummary] = []

        if self.backend == "file":
            summaries = self._list_from_files()
        else:
            for session_data in self._sessions.values():
                summaries.append(self._create_summary(session_data))

        # Sort by created_at (most recent first)
        summaries.sort(key=lambda s: s.created_at, reverse=True)

        # Apply offset and limit
        return summaries[offset : offset + limit]

    def exists(self, session_id: str) -> bool:
        """
        Check if a session exists.

        Args:
            session_id: The session ID to check

        Returns:
            True if exists, False otherwise
        """
        if self.backend == "file":
            session_file = self.storage_path / f"{session_id}.json"
            return session_file.exists()
        else:
            return session_id in self._sessions

    def get_summary(self, session_id: str) -> Optional[SessionSummary]:
        """
        Get summary for a specific session without loading full history.

        Args:
            session_id: The session ID

        Returns:
            SessionSummary or None if not found
        """
        session_data = None

        if self.backend == "file":
            session_data = self._load_from_file(session_id)
        else:
            session_data = self._sessions.get(session_id)

        if session_data is None:
            return None

        return self._create_summary(session_data)

    def clear_all(self) -> int:
        """
        Delete all sessions.

        Returns:
            Number of sessions deleted
        """
        count = 0

        if self.backend == "file":
            for session_file in self.storage_path.glob("*.json"):
                session_file.unlink()
                count += 1
        else:
            count = len(self._sessions)
            self._sessions.clear()

        logger.info(f"Cleared {count} sessions")
        return count

    # ================== FILE BACKEND HELPERS ==================

    def _save_to_file(self, session_id: str, data: Dict[str, Any]) -> None:
        """Save session data to a JSON file."""
        session_file = self.storage_path / f"{session_id}.json"
        with open(session_file, "w") as f:
            json.dump(data, f, indent=2, default=str)

    def _load_from_file(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Load session data from a JSON file."""
        session_file = self.storage_path / f"{session_id}.json"
        if not session_file.exists():
            return None

        try:
            with open(session_file, "r") as f:
                return json.load(f)
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse session file {session_file}: {e}")
            return None

    def _delete_file(self, session_id: str) -> bool:
        """Delete a session file."""
        session_file = self.storage_path / f"{session_id}.json"
        if session_file.exists():
            session_file.unlink()
            logger.debug(f"Deleted session file {session_file}")
            return True
        return False

    def _list_from_files(self) -> List[SessionSummary]:
        """List all sessions from files."""
        summaries = []

        for session_file in self.storage_path.glob("*.json"):
            try:
                with open(session_file, "r") as f:
                    data = json.load(f)
                    summaries.append(self._create_summary(data))
            except (json.JSONDecodeError, KeyError) as e:
                logger.warning(f"Skipping invalid session file {session_file}: {e}")

        return summaries

    # ================== HELPER METHODS ==================

    def _create_summary(self, data: Dict[str, Any]) -> SessionSummary:
        """Create a SessionSummary from session data."""
        history = data.get("history", [])

        # Get last message preview
        last_message_preview = None
        if history:
            last_msg = history[-1]
            content = last_msg.get("content", "")
            if content:
                last_message_preview = content[:100] + ("..." if len(content) > 100 else "")

        # Parse created_at
        created_at = data.get("created_at")
        if isinstance(created_at, str):
            created_at = datetime.fromisoformat(created_at)
        elif created_at is None:
            created_at = datetime.utcnow()

        return SessionSummary(
            session_id=data.get("session_id", "unknown"),
            created_at=created_at,
            message_count=len(history),
            model=data.get("model", "unknown"),
            provider=data.get("provider", "unknown"),
            system_instruction=data.get("system_instruction"),
            last_message_preview=last_message_preview,
            metadata=data.get("metadata", {}),
        )

    def __repr__(self) -> str:
        if self.backend == "file":
            return f"ConversationRegistry(backend='file', path={self.storage_path})"
        else:
            return f"ConversationRegistry(backend='memory', sessions={len(self._sessions)})"
