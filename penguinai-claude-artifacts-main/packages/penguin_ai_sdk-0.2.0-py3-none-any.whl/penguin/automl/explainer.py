"""
Interpretability Module for AutoML_test
========================================

This module provides model interpretability using SHAP (SHapley Additive exPlanations).
It helps answer "Why did the model make this prediction?"

Key Components:
- ModelExplainer: Main explainer class
- explain_instance: Local explanations for individual predictions
- explain_global: Global feature importance across dataset
- get_feature_importance: Extract and rank feature contributions

SHAP Types Supported:
- TreeExplainer: Fast explanations for tree-based models
- LinearExplainer: Fast explanations for linear models
- KernelExplainer: General-purpose (slower) for any model
"""

from typing import Dict, Any, Optional, List, Union
import numpy as np
import pandas as pd
import warnings

# SHAP library
try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False
    warnings.warn(
        "SHAP is not installed. Install with: pip install shap\n"
        "Interpretability features will be disabled."
    )


class ModelExplainer:
    """
    Model interpretability class using SHAP.

    This class provides comprehensive model explanations using SHAP values,
    including both global feature importance and local instance-level explanations.

    Attributes:
        model: Trained model to explain
        X_background: Background data for SHAP (used for baselines)
        explainer: SHAP explainer instance
        feature_names: Names of features
        explainer_type: Type of SHAP explainer used

    Example:
        >>> explainer = ModelExplainer(trained_model, X_train)
        >>> local_exp = explainer.explain_instance(X_test[0])
        >>> global_exp = explainer.explain_global(X_test)
        >>> importance = explainer.get_feature_importance()
    """

    def __init__(
        self,
        model,
        X_background: np.ndarray,
        feature_names: Optional[List[str]] = None,
        check_additivity: bool = False
    ):
        """
        Initialize the explainer.

        Args:
            model: Trained sklearn-compatible model
            X_background: Background dataset for SHAP (typically training data)
                         Use a sample (e.g., 100 rows) for faster computation
            feature_names: Optional list of feature names
            check_additivity: Whether to check SHAP additivity (slower)

        Raises:
            ImportError: If SHAP is not installed
        """
        if not SHAP_AVAILABLE:
            raise ImportError(
                "SHAP is not installed. Install with: pip install shap"
            )

        self.model = model
        self.X_background = np.array(X_background) if not isinstance(X_background, np.ndarray) else X_background

        # Generate feature names if not provided
        if feature_names is None:
            n_features = self.X_background.shape[1]
            self.feature_names = [f"feature_{i}" for i in range(n_features)]
        else:
            self.feature_names = feature_names

        self.check_additivity = check_additivity
        self.explainer_type = None
        self.explainer = None

        # Initialize the appropriate SHAP explainer
        self._initialize_explainer()

        print(f"ModelExplainer initialized")
        print(f"  Explainer type: {self.explainer_type}")
        print(f"  Background data shape: {self.X_background.shape}")
        print(f"  Number of features: {len(self.feature_names)}")

    def _initialize_explainer(self):
        """
        Initialize the appropriate SHAP explainer based on model type.

        Tries to use the fastest explainer available:
        1. TreeExplainer for tree-based models (RF, XGBoost, etc.)
        2. LinearExplainer for linear models
        3. KernelExplainer as fallback (slower but general)
        """
        model_type = type(self.model).__name__

        # Try TreeExplainer for tree-based models
        tree_models = [
            'RandomForestClassifier', 'RandomForestRegressor',
            'XGBClassifier', 'XGBRegressor',
            'LGBMClassifier', 'LGBMRegressor',
            'CatBoostClassifier', 'CatBoostRegressor',
            'DecisionTreeClassifier', 'DecisionTreeRegressor',
            'GradientBoostingClassifier', 'GradientBoostingRegressor'
        ]

        if model_type in tree_models:
            try:
                self.explainer = shap.TreeExplainer(self.model)
                self.explainer_type = "TreeExplainer"
                return
            except Exception as e:
                print(f"TreeExplainer failed: {e}. Trying fallback...")

        # Try LinearExplainer for linear models
        linear_models = [
            'LinearRegression', 'Ridge', 'Lasso', 'ElasticNet',
            'LogisticRegression', 'SGDClassifier', 'SGDRegressor'
        ]

        if model_type in linear_models:
            try:
                self.explainer = shap.LinearExplainer(self.model, self.X_background)
                self.explainer_type = "LinearExplainer"
                return
            except Exception as e:
                print(f"LinearExplainer failed: {e}. Trying fallback...")

        # Fallback to KernelExplainer (slower but works for any model)
        try:
            # For KernelExplainer, we need a prediction function
            if hasattr(self.model, 'predict_proba'):
                # Classification: use probabilities
                predict_fn = lambda x: self.model.predict_proba(x)
            else:
                # Regression: use predictions
                predict_fn = lambda x: self.model.predict(x)

            # Use a subset of background data for speed
            background_sample = shap.sample(self.X_background, min(100, len(self.X_background)))

            self.explainer = shap.KernelExplainer(predict_fn, background_sample)
            self.explainer_type = "KernelExplainer"
        except Exception as e:
            raise RuntimeError(f"Failed to initialize any SHAP explainer: {e}")

    def explain_instance(
        self,
        X: np.ndarray,
        return_dict: bool = True
    ) -> Union[Dict[str, Any], Any]:  # Returns shap.Explanation if return_dict=False
        """
        Generate local explanation for a single instance.

        Args:
            X: Single instance to explain (1D array or 2D array with 1 row)
            return_dict: If True, return dictionary; if False, return SHAP Explanation object

        Returns:
            Dictionary containing:
            - shap_values: SHAP values for each feature
            - base_value: Baseline prediction
            - prediction: Model prediction
            - feature_contributions: DataFrame of features and their contributions
            - top_features: Top contributing features (positive and negative)

        Example:
            >>> explanation = explainer.explain_instance(X_test[0])
            >>> print(explanation['prediction'])
            >>> print(explanation['feature_contributions'])
        """
        # Ensure X is 2D
        if X.ndim == 1:
            X = X.reshape(1, -1)

        # Get SHAP values
        shap_values = self.explainer.shap_values(X)

        # Handle different SHAP output formats
        if isinstance(shap_values, list):
            # Multiclass classification: list of arrays (one per class)
            # For simplicity, use the values for the predicted class
            prediction = self.model.predict(X)[0]
            shap_vals_for_class = shap_values[int(prediction)]
            # Ensure 1D
            if shap_vals_for_class.ndim > 1:
                shap_vals_for_class = shap_vals_for_class[0]
            shap_values = shap_vals_for_class
        else:
            # Binary classification or regression: single array
            if shap_values.ndim > 1:
                shap_values = shap_values[0]
            # Ensure it's 1D
            if shap_values.ndim > 1:
                shap_values = shap_values.flatten()

            # For binary classification with TreeExplainer, we might get values for both classes
            # Check if length is double the number of features
            if len(shap_values) == 2 * X.shape[1]:
                # Take only the first half (class 0 values) or second half (class 1 values)
                # Use positive class (second half)
                shap_values = shap_values[X.shape[1]:]

        # Get base value (expected value)
        if hasattr(self.explainer, 'expected_value'):
            base_value = self.explainer.expected_value
            if isinstance(base_value, (list, np.ndarray)):
                prediction = self.model.predict(X)[0]
                base_value = base_value[int(prediction)]
        else:
            base_value = np.mean(self.model.predict(self.X_background))

        # Get model prediction
        prediction = self.model.predict(X)[0]

        if not return_dict:
            # Return raw SHAP explanation object
            return shap.Explanation(
                values=shap_values,
                base_values=base_value,
                data=X[0],
                feature_names=self.feature_names
            )

        # Create feature contributions DataFrame
        # Ensure all arrays are 1D and same length
        feature_values = X[0] if X[0].ndim == 1 else X[0].flatten()
        shap_vals_flat = shap_values.flatten() if shap_values.ndim > 1 else shap_values

        contributions = pd.DataFrame({
            'feature': self.feature_names,
            'shap_value': shap_vals_flat,
            'abs_shap_value': np.abs(shap_vals_flat),
            'feature_value': feature_values
        }).sort_values('abs_shap_value', ascending=False)

        # Get top positive and negative contributors
        top_positive = contributions[contributions['shap_value'] > 0].head(5)
        top_negative = contributions[contributions['shap_value'] < 0].head(5)

        return {
            'shap_values': shap_values,
            'base_value': base_value,
            'prediction': prediction,
            'feature_contributions': contributions,
            'top_positive_contributors': top_positive,
            'top_negative_contributors': top_negative,
            'explanation_text': self._generate_explanation_text(
                contributions, base_value, prediction
            )
        }

    def explain_global(
        self,
        X: np.ndarray,
        max_samples: int = 1000
    ) -> Dict[str, Any]:
        """
        Generate global explanations across a dataset.

        Args:
            X: Dataset to explain (2D array)
            max_samples: Maximum samples to use (for speed)

        Returns:
            Dictionary containing:
            - mean_abs_shap: Mean absolute SHAP values (global importance)
            - feature_importance: DataFrame of features ranked by importance
            - shap_values: Full SHAP values matrix
            - base_value: Baseline prediction

        Example:
            >>> global_exp = explainer.explain_global(X_test)
            >>> print(global_exp['feature_importance'])
        """
        # Sample data if too large
        if len(X) > max_samples:
            indices = np.random.choice(len(X), max_samples, replace=False)
            X_sample = X[indices]
        else:
            X_sample = X

        # Get SHAP values
        shap_values = self.explainer.shap_values(X_sample)

        # Handle different output formats
        if isinstance(shap_values, list):
            # Multiclass: average across classes
            shap_values = np.mean([np.abs(sv) for sv in shap_values], axis=0)
        else:
            # Check if binary classification with doubled features
            if shap_values.ndim == 2 and shap_values.shape[1] == 2 * X_sample.shape[1]:
                # Take only positive class values (second half)
                shap_values = shap_values[:, X_sample.shape[1]:]
            shap_values = np.abs(shap_values)

        # Calculate mean absolute SHAP values (global importance)
        if shap_values.ndim > 1:
            mean_abs_shap = np.mean(shap_values, axis=0)
        else:
            mean_abs_shap = shap_values

        # Ensure mean_abs_shap is 1D
        if mean_abs_shap.ndim > 1:
            mean_abs_shap = mean_abs_shap.flatten()

        # Debug: check if lengths match
        if len(self.feature_names) != len(mean_abs_shap):
            print(f"Feature mismatch in global: features={len(self.feature_names)}, importance={len(mean_abs_shap)}")
            # Take matching length
            min_len = min(len(self.feature_names), len(mean_abs_shap))
            feature_importance = pd.DataFrame({
                'feature': self.feature_names[:min_len],
                'importance': mean_abs_shap[:min_len]
            }).sort_values('importance', ascending=False)
        else:
            # Create feature importance DataFrame
            feature_importance = pd.DataFrame({
                'feature': self.feature_names,
                'importance': mean_abs_shap
            }).sort_values('importance', ascending=False)

        # Get base value
        if hasattr(self.explainer, 'expected_value'):
            base_value = self.explainer.expected_value
            if isinstance(base_value, (list, np.ndarray)):
                base_value = np.mean(base_value)
        else:
            base_value = np.mean(self.model.predict(self.X_background))

        return {
            'mean_abs_shap': mean_abs_shap,
            'feature_importance': feature_importance,
            'shap_values': shap_values,
            'base_value': base_value,
            'n_samples_explained': len(X_sample)
        }

    def get_feature_importance(
        self,
        X: Optional[np.ndarray] = None,
        top_n: int = 10
    ) -> pd.DataFrame:
        """
        Get feature importance ranking.

        Args:
            X: Optional dataset to compute importance on (uses background if None)
            top_n: Number of top features to return

        Returns:
            DataFrame with features ranked by importance

        Example:
            >>> importance = explainer.get_feature_importance(X_test, top_n=5)
            >>> print(importance)
        """
        if X is None:
            X = self.X_background

        global_exp = self.explain_global(X)
        return global_exp['feature_importance'].head(top_n)

    def _generate_explanation_text(
        self,
        contributions: pd.DataFrame,
        base_value: float,
        prediction: float
    ) -> str:
        """
        Generate human-readable explanation text.

        Args:
            contributions: DataFrame of feature contributions
            base_value: Baseline prediction
            prediction: Final prediction

        Returns:
            Human-readable explanation string
        """
        lines = []
        lines.append(f"Prediction: {prediction:.4f}")
        lines.append(f"Base value: {base_value:.4f}")
        lines.append(f"\nTop positive contributors:")

        top_pos = contributions[contributions['shap_value'] > 0].head(3)
        for _, row in top_pos.iterrows():
            lines.append(f"  {row['feature']}: +{row['shap_value']:.4f} (value={row['feature_value']:.4f})")

        lines.append(f"\nTop negative contributors:")
        top_neg = contributions[contributions['shap_value'] < 0].head(3)
        for _, row in top_neg.iterrows():
            lines.append(f"  {row['feature']}: {row['shap_value']:.4f} (value={row['feature_value']:.4f})")

        return "\n".join(lines)

    def summary(self) -> str:
        """
        Get a summary of the explainer.

        Returns:
            Summary string
        """
        lines = []
        lines.append("=" * 60)
        lines.append("ModelExplainer Summary")
        lines.append("=" * 60)
        lines.append(f"Model: {type(self.model).__name__}")
        lines.append(f"Explainer type: {self.explainer_type}")
        lines.append(f"Number of features: {len(self.feature_names)}")
        lines.append(f"Background data size: {self.X_background.shape}")
        lines.append("=" * 60)
        return "\n".join(lines)


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def explain_model(
    model,
    X_train: np.ndarray,
    X_test: np.ndarray,
    feature_names: Optional[List[str]] = None,
    n_global_samples: int = 1000
) -> Dict[str, Any]:
    """
    Convenience function for one-line model explanation.

    Args:
        model: Trained model
        X_train: Training data (used as background)
        X_test: Test data to explain
        feature_names: Optional feature names
        n_global_samples: Max samples for global explanation

    Returns:
        Dictionary with global and local explanations

    Example:
        >>> explanations = explain_model(model, X_train, X_test)
        >>> print(explanations['feature_importance'])
    """
    if not SHAP_AVAILABLE:
        raise ImportError("SHAP is not installed. Install with: pip install shap")

    # Use subset of training data as background (for speed)
    background_size = min(100, len(X_train))
    background_indices = np.random.choice(len(X_train), background_size, replace=False)
    X_background = X_train[background_indices]

    # Initialize explainer
    explainer = ModelExplainer(model, X_background, feature_names)

    # Global explanation
    global_exp = explainer.explain_global(X_test, max_samples=n_global_samples)

    # Local explanation for first test sample
    local_exp = explainer.explain_instance(X_test[0])

    return {
        'explainer': explainer,
        'global_explanation': global_exp,
        'local_explanation_sample': local_exp,
        'feature_importance': global_exp['feature_importance']
    }


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    from sklearn.datasets import make_classification
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split

    if not SHAP_AVAILABLE:
        print("SHAP not available. Skipping tests.")
        exit(0)

    print("=" * 60)
    print("AutoML_test Explainer Test")
    print("=" * 60)

    # Create dataset
    X, y = make_classification(
        n_samples=500,
        n_features=10,
        n_informative=7,
        n_redundant=3,
        random_state=42
    )
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42
    )

    feature_names = [f"feat_{i}" for i in range(10)]

    # Train model
    print("\n1. Training model...")
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    print("   ✓ Model trained")

    # Initialize explainer
    print("\n2. Initializing explainer...")
    explainer = ModelExplainer(model, X_train[:100], feature_names)
    print("   ✓ Explainer initialized")

    # Local explanation
    print("\n3. Testing local explanation...")
    local_exp = explainer.explain_instance(X_test[0])
    print("   ✓ Local explanation generated")
    print(f"   Prediction: {local_exp['prediction']}")
    print(f"   Top features:\n{local_exp['feature_contributions'].head(3)}")

    # Global explanation
    print("\n4. Testing global explanation...")
    global_exp = explainer.explain_global(X_test, max_samples=100)
    print("   ✓ Global explanation generated")
    print(f"   Feature importance:\n{global_exp['feature_importance'].head(5)}")

    # Feature importance
    print("\n5. Testing feature importance...")
    importance = explainer.get_feature_importance(X_test, top_n=5)
    print("   ✓ Feature importance calculated")
    print(f"\n{importance}")

    print("\n" + "=" * 60)
    print("Explainer working correctly!")
    print("=" * 60)
