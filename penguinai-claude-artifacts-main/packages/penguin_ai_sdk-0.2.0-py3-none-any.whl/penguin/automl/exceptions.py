"""
Custom Exceptions for AutoML Library
=====================================

Provides a hierarchy of custom exceptions for better error handling
and debugging throughout the AutoML pipeline.

Exception Hierarchy:
    AutoMLError (base)
    ├── ConfigurationError
    │   ├── InvalidTaskTypeError
    │   ├── InvalidMetricError
    │   └── InvalidModelError
    ├── DataError
    │   ├── InvalidDataShapeError
    │   ├── InvalidDataTypeError
    │   ├── MissingDataError
    │   ├── InsufficientDataError
    │   └── DataValidationError
    ├── PreprocessingError
    │   ├── ImputationError
    │   ├── EncodingError
    │   └── ScalingError
    ├── FeatureSelectionError
    ├── TrainingError
    │   ├── OptimizationError
    │   ├── ModelFitError
    │   └── CrossValidationError
    ├── EvaluationError
    ├── ExplanationError
    └── RegistryError
        ├── ModelNotFoundError
        ├── ModelSaveError
        └── ModelLoadError
"""

from typing import Optional, Any


class AutoMLError(Exception):
    """
    Base exception for all AutoML errors.

    All custom exceptions inherit from this class, making it easy
    to catch any AutoML-related error.

    Attributes:
        message: Error message
        details: Additional error details
        original_error: Original exception if this wraps another error
    """

    def __init__(
        self,
        message: str,
        details: Optional[dict] = None,
        original_error: Optional[Exception] = None
    ):
        self.message = message
        self.details = details or {}
        self.original_error = original_error

        # Build full error message
        full_message = f"{self.__class__.__name__}: {message}"

        if details:
            details_str = ", ".join(f"{k}={v}" for k, v in details.items())
            full_message += f" ({details_str})"

        if original_error:
            full_message += f" | Caused by: {type(original_error).__name__}: {str(original_error)}"

        super().__init__(full_message)


# ============================================================================
# Configuration Errors
# ============================================================================

class ConfigurationError(AutoMLError):
    """Raised when configuration is invalid."""
    pass


class InvalidTaskTypeError(ConfigurationError):
    """Raised when task type is not 'classification' or 'regression'."""
    pass


class InvalidMetricError(ConfigurationError):
    """Raised when specified metric is not supported for the task type."""
    pass


class InvalidModelError(ConfigurationError):
    """Raised when specified model is not available or invalid."""
    pass


# ============================================================================
# Data Errors
# ============================================================================

class DataError(AutoMLError):
    """Base class for data-related errors."""
    pass


class InvalidDataShapeError(DataError):
    """Raised when data has invalid shape."""

    def __init__(self, expected_shape: str, actual_shape: tuple, **kwargs):
        super().__init__(
            f"Invalid data shape. Expected {expected_shape}, got {actual_shape}",
            details={"expected": expected_shape, "actual": actual_shape},
            **kwargs
        )


class InvalidDataTypeError(DataError):
    """Raised when data has invalid type."""

    def __init__(self, expected_type: str, actual_type: type, **kwargs):
        super().__init__(
            f"Invalid data type. Expected {expected_type}, got {actual_type}",
            details={"expected": expected_type, "actual": str(actual_type)},
            **kwargs
        )


class MissingDataError(DataError):
    """Raised when required data is missing."""
    pass


class InsufficientDataError(DataError):
    """Raised when there's not enough data to train."""

    def __init__(self, min_samples: int, actual_samples: int, **kwargs):
        super().__init__(
            f"Insufficient data. Need at least {min_samples} samples, got {actual_samples}",
            details={"min_required": min_samples, "actual": actual_samples},
            **kwargs
        )


class DataValidationError(DataError):
    """Raised when data fails validation checks."""
    pass


# ============================================================================
# Preprocessing Errors
# ============================================================================

class PreprocessingError(AutoMLError):
    """Base class for preprocessing errors."""
    pass


class ImputationError(PreprocessingError):
    """Raised when missing value imputation fails."""
    pass


class EncodingError(PreprocessingError):
    """Raised when categorical encoding fails."""
    pass


class ScalingError(PreprocessingError):
    """Raised when feature scaling fails."""
    pass


# ============================================================================
# Feature Selection Errors
# ============================================================================

class FeatureSelectionError(AutoMLError):
    """Raised when feature selection fails."""
    pass


# ============================================================================
# Training Errors
# ============================================================================

class TrainingError(AutoMLError):
    """Base class for training-related errors."""
    pass


class OptimizationError(TrainingError):
    """Raised when hyperparameter optimization fails."""
    pass


class ModelFitError(TrainingError):
    """Raised when model fitting fails."""

    def __init__(self, model_name: str, message: str, **kwargs):
        super().__init__(
            f"Failed to fit {model_name}: {message}",
            details={"model": model_name},
            **kwargs
        )


class CrossValidationError(TrainingError):
    """Raised when cross-validation fails."""
    pass


# ============================================================================
# Evaluation Errors
# ============================================================================

class EvaluationError(AutoMLError):
    """Raised when model evaluation fails."""
    pass


# ============================================================================
# Explanation Errors
# ============================================================================

class ExplanationError(AutoMLError):
    """Raised when model explanation generation fails."""
    pass


# ============================================================================
# Registry Errors
# ============================================================================

class RegistryError(AutoMLError):
    """Base class for model registry errors."""
    pass


class ModelNotFoundError(RegistryError):
    """Raised when a model cannot be found in the registry."""

    def __init__(self, model_id: str, **kwargs):
        super().__init__(
            f"Model not found in registry: {model_id}",
            details={"model_id": model_id},
            **kwargs
        )


class ModelSaveError(RegistryError):
    """Raised when model save operation fails."""
    pass


class ModelLoadError(RegistryError):
    """Raised when model load operation fails."""

    def __init__(self, model_id: str, reason: str, **kwargs):
        super().__init__(
            f"Failed to load model {model_id}: {reason}",
            details={"model_id": model_id, "reason": reason},
            **kwargs
        )


# ============================================================================
# Model Not Trained Error
# ============================================================================

class ModelNotTrainedError(AutoMLError):
    """Raised when attempting to use a model that hasn't been trained."""

    def __init__(self, operation: str = "operation", **kwargs):
        super().__init__(
            f"Cannot perform {operation}: model has not been trained. Call fit() first.",
            details={"operation": operation},
            **kwargs
        )


# ============================================================================
# Utility Functions
# ============================================================================

def wrap_exception(
    original: Exception,
    new_exception_class: type,
    message: str,
    **kwargs
) -> AutoMLError:
    """
    Wrap an exception in a custom AutoML exception.

    Args:
        original: The original exception
        new_exception_class: The new exception class to wrap with
        message: Custom error message
        **kwargs: Additional arguments for the new exception

    Returns:
        Instance of new_exception_class

    Example:
        >>> try:
        ...     model.fit(X, y)
        ... except Exception as e:
        ...     raise wrap_exception(e, ModelFitError, "XGBoost fitting failed", model_name="xgboost")
    """
    return new_exception_class(
        message=message,
        original_error=original,
        **kwargs
    )


def validate_and_raise(
    condition: bool,
    exception_class: type,
    message: str,
    **kwargs
) -> None:
    """
    Validate a condition and raise exception if False.

    Args:
        condition: Condition to check
        exception_class: Exception to raise if condition is False
        message: Error message
        **kwargs: Additional arguments for exception

    Raises:
        exception_class: If condition is False

    Example:
        >>> validate_and_raise(
        ...     len(X) > 0,
        ...     InsufficientDataError,
        ...     "Cannot train with empty dataset",
        ...     min_samples=1,
        ...     actual_samples=0
        ... )
    """
    if not condition:
        raise exception_class(message, **kwargs)


# ============================================================================
# Exception Context Manager
# ============================================================================

from contextlib import contextmanager
from typing import Type


@contextmanager
def handle_errors(
    operation: str,
    exception_mapping: Optional[dict] = None,
    reraise: bool = True
):
    """
    Context manager for consistent error handling.

    Args:
        operation: Name of the operation being performed
        exception_mapping: Dict mapping exception types to custom exceptions
        reraise: Whether to re-raise the exception after handling

    Example:
        >>> with handle_errors("data preprocessing", {ValueError: PreprocessingError}):
        ...     X = scaler.fit_transform(X)
    """
    try:
        yield
    except Exception as e:
        # Check if we should map this exception
        if exception_mapping:
            for exc_type, custom_exc in exception_mapping.items():
                if isinstance(e, exc_type):
                    raise wrap_exception(
                        e, custom_exc, f"Failed during {operation}"
                    ) from e

        # If not mapped or mapping not provided, wrap in generic AutoMLError
        if not isinstance(e, AutoMLError):
            raise AutoMLError(
                f"Unexpected error during {operation}",
                original_error=e
            ) from e

        # If already an AutoMLError, just re-raise
        if reraise:
            raise


# ============================================================================
# Error Recovery Utilities
# ============================================================================

class ErrorRecovery:
    """Utilities for error recovery and fallback strategies."""

    @staticmethod
    def with_fallback(
        primary_func,
        fallback_func,
        exception_types: tuple = (Exception,),
        log_func=None
    ):
        """
        Try primary function, fall back to secondary on error.

        Args:
            primary_func: Primary function to try
            fallback_func: Fallback function if primary fails
            exception_types: Tuple of exceptions to catch
            log_func: Optional logging function

        Returns:
            Result from primary or fallback function

        Example:
            >>> result = ErrorRecovery.with_fallback(
            ...     lambda: expensive_operation(),
            ...     lambda: simple_fallback(),
            ...     exception_types=(TimeoutError, MemoryError)
            ... )
        """
        try:
            return primary_func()
        except exception_types as e:
            if log_func:
                log_func(f"Primary function failed: {e}. Using fallback.")
            return fallback_func()

    @staticmethod
    def retry(
        func,
        max_attempts: int = 3,
        exception_types: tuple = (Exception,),
        delay: float = 1.0,
        log_func=None
    ):
        """
        Retry a function on failure.

        Args:
            func: Function to retry
            max_attempts: Maximum number of attempts
            exception_types: Exceptions to catch and retry
            delay: Delay between attempts (seconds)
            log_func: Optional logging function

        Returns:
            Result from successful attempt

        Raises:
            Last exception if all attempts fail
        """
        import time

        last_exception = None
        for attempt in range(1, max_attempts + 1):
            try:
                return func()
            except exception_types as e:
                last_exception = e
                if log_func:
                    log_func(f"Attempt {attempt}/{max_attempts} failed: {e}")
                if attempt < max_attempts:
                    time.sleep(delay)

        raise last_exception


# ============================================================================
# Export All
# ============================================================================

__all__ = [
    # Base
    'AutoMLError',

    # Configuration
    'ConfigurationError',
    'InvalidTaskTypeError',
    'InvalidMetricError',
    'InvalidModelError',

    # Data
    'DataError',
    'InvalidDataShapeError',
    'InvalidDataTypeError',
    'MissingDataError',
    'InsufficientDataError',
    'DataValidationError',

    # Preprocessing
    'PreprocessingError',
    'ImputationError',
    'EncodingError',
    'ScalingError',

    # Feature Selection
    'FeatureSelectionError',

    # Training
    'TrainingError',
    'OptimizationError',
    'ModelFitError',
    'CrossValidationError',

    # Evaluation
    'EvaluationError',

    # Explanation
    'ExplanationError',

    # Registry
    'RegistryError',
    'ModelNotFoundError',
    'ModelSaveError',
    'ModelLoadError',

    # Other
    'ModelNotTrainedError',

    # Utilities
    'wrap_exception',
    'validate_and_raise',
    'handle_errors',
    'ErrorRecovery',
]
