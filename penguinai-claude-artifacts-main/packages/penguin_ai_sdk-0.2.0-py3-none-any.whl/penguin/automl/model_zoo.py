"""
Model Zoo for AutoML_test
==========================

This module implements a factory pattern for managing ML models.
It provides a centralized registry of models with their hyperparameter
search spaces for Optuna optimization.

Key Components:
- ModelInfo: Dataclass storing model classes and search space functions
- MODEL_REGISTRY: Dictionary mapping model names to ModelInfo
- get_model(): Factory function to create model instances
- get_search_space(): Returns Optuna search space for a model

Supported Models:
- Tree-based: Random Forest, XGBoost, LightGBM, CatBoost, Decision Tree
- Linear: Linear/Logistic Regression, Ridge, Lasso
- SVM: Support Vector Machines
- Other: K-Nearest Neighbors
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any, Callable
import optuna

# Scikit-learn models
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.linear_model import (
    LinearRegression, LogisticRegression,
    Ridge, Lasso
)
from sklearn.svm import SVC, SVR
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor

# Gradient boosting libraries
try:
    from xgboost import XGBClassifier, XGBRegressor
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

try:
    from lightgbm import LGBMClassifier, LGBMRegressor
    LIGHTGBM_AVAILABLE = True
except ImportError:
    LIGHTGBM_AVAILABLE = False

try:
    from catboost import CatBoostClassifier, CatBoostRegressor
    CATBOOST_AVAILABLE = True
except ImportError:
    CATBOOST_AVAILABLE = False


@dataclass
class ModelInfo:
    """
    Container for model information.

    Attributes:
        classifier_class: Sklearn-compatible classifier class
        regressor_class: Sklearn-compatible regressor class
        search_space_func: Function that returns Optuna hyperparameter space
        requires_scaling: Whether features should be scaled (for linear models)
    """
    classifier_class: Optional[type]
    regressor_class: Optional[type]
    search_space_func: Callable
    requires_scaling: bool = False


# ============================================================================
# HYPERPARAMETER SEARCH SPACES
# ============================================================================

def random_forest_search_space(trial: optuna.Trial) -> Dict[str, Any]:
    """
    Hyperparameter search space for Random Forest.

    Tuned parameters:
    - n_estimators: Number of trees (50-500)
    - max_depth: Maximum tree depth (3-30, or None)
    - min_samples_split: Minimum samples to split (2-20)
    - min_samples_leaf: Minimum samples in leaf (1-10)
    - max_features: Features to consider for split
    - bootstrap: Whether to use bootstrap samples
    """
    max_depth = trial.suggest_int('max_depth', 3, 30)

    return {
        'n_estimators': trial.suggest_int('n_estimators', 50, 500),
        'max_depth': None if max_depth == 30 else max_depth,
        'min_samples_split': trial.suggest_int('min_samples_split', 2, 20),
        'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 10),
        'max_features': trial.suggest_categorical('max_features', ['sqrt', 'log2', None]),
        'bootstrap': trial.suggest_categorical('bootstrap', [True, False]),
        'random_state': 42,
        'n_jobs': -1
    }


def xgboost_search_space(trial: optuna.Trial) -> Dict[str, Any]:
    """
    Hyperparameter search space for XGBoost.

    Tuned parameters:
    - n_estimators: Number of boosting rounds (50-500)
    - learning_rate: Step size shrinkage (0.01-0.3)
    - max_depth: Maximum tree depth (3-15)
    - min_child_weight: Minimum sum of instance weight in leaf (1-10)
    - subsample: Fraction of samples for training (0.5-1.0)
    - colsample_bytree: Fraction of features per tree (0.5-1.0)
    - gamma: Minimum loss reduction for split (0.0-5.0)
    - reg_alpha: L1 regularization (0.0-1.0)
    - reg_lambda: L2 regularization (0.0-1.0)
    """
    return {
        'n_estimators': trial.suggest_int('n_estimators', 50, 500),
        'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3, log=True),
        'max_depth': trial.suggest_int('max_depth', 3, 15),
        'min_child_weight': trial.suggest_int('min_child_weight', 1, 10),
        'subsample': trial.suggest_float('subsample', 0.5, 1.0),
        'colsample_bytree': trial.suggest_float('colsample_bytree', 0.5, 1.0),
        'gamma': trial.suggest_float('gamma', 0.0, 5.0),
        'reg_alpha': trial.suggest_float('reg_alpha', 0.0, 1.0),
        'reg_lambda': trial.suggest_float('reg_lambda', 0.0, 1.0),
        'random_state': 42,
        'n_jobs': -1,
        'verbosity': 0
    }


def lightgbm_search_space(trial: optuna.Trial) -> Dict[str, Any]:
    """
    Hyperparameter search space for LightGBM.

    Tuned parameters:
    - n_estimators: Number of boosting rounds (50-500)
    - learning_rate: Step size shrinkage (0.01-0.3)
    - max_depth: Maximum tree depth (3-15, -1 for no limit)
    - num_leaves: Maximum number of leaves (20-150)
    - min_child_samples: Minimum samples in leaf (5-100)
    - subsample: Fraction of samples for training (0.5-1.0)
    - colsample_bytree: Fraction of features per tree (0.5-1.0)
    - reg_alpha: L1 regularization (0.0-1.0)
    - reg_lambda: L2 regularization (0.0-1.0)
    """
    return {
        'n_estimators': trial.suggest_int('n_estimators', 50, 500),
        'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3, log=True),
        'max_depth': trial.suggest_int('max_depth', 3, 15),
        'num_leaves': trial.suggest_int('num_leaves', 20, 150),
        'min_child_samples': trial.suggest_int('min_child_samples', 5, 100),
        'subsample': trial.suggest_float('subsample', 0.5, 1.0),
        'colsample_bytree': trial.suggest_float('colsample_bytree', 0.5, 1.0),
        'reg_alpha': trial.suggest_float('reg_alpha', 0.0, 1.0),
        'reg_lambda': trial.suggest_float('reg_lambda', 0.0, 1.0),
        'random_state': 42,
        'n_jobs': -1,
        'verbosity': -1
    }


def catboost_search_space(trial: optuna.Trial) -> Dict[str, Any]:
    """
    Hyperparameter search space for CatBoost.

    Tuned parameters:
    - iterations: Number of boosting rounds (50-500)
    - learning_rate: Step size shrinkage (0.01-0.3)
    - depth: Maximum tree depth (3-10)
    - l2_leaf_reg: L2 regularization (1-10)
    - border_count: Number of splits for numerical features (32-255)
    - bagging_temperature: Controls intensity of Bayesian bagging (0.0-1.0)
    """
    return {
        'iterations': trial.suggest_int('iterations', 50, 500),
        'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3, log=True),
        'depth': trial.suggest_int('depth', 3, 10),
        'l2_leaf_reg': trial.suggest_float('l2_leaf_reg', 1.0, 10.0),
        'border_count': trial.suggest_int('border_count', 32, 255),
        'bagging_temperature': trial.suggest_float('bagging_temperature', 0.0, 1.0),
        'random_state': 42,
        'verbose': False
    }


def decision_tree_search_space(trial: optuna.Trial) -> Dict[str, Any]:
    """
    Hyperparameter search space for Decision Tree.

    Tuned parameters:
    - max_depth: Maximum tree depth (3-30, or None)
    - min_samples_split: Minimum samples to split (2-20)
    - min_samples_leaf: Minimum samples in leaf (1-10)
    - max_features: Features to consider for split
    - criterion: Split quality measure (gini/entropy for classification, mse/mae for regression)
    """
    max_depth = trial.suggest_int('max_depth', 3, 30)

    return {
        'max_depth': None if max_depth == 30 else max_depth,
        'min_samples_split': trial.suggest_int('min_samples_split', 2, 20),
        'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 10),
        'max_features': trial.suggest_categorical('max_features', ['sqrt', 'log2', None]),
        'random_state': 42
    }


def logistic_regression_search_space(trial: optuna.Trial) -> Dict[str, Any]:
    """
    Hyperparameter search space for Logistic Regression.

    Tuned parameters:
    - C: Inverse regularization strength (0.001-100)
    - penalty: Type of regularization (l1, l2, elasticnet)
    - solver: Optimization algorithm
    - max_iter: Maximum iterations (100-1000)
    """
    penalty = trial.suggest_categorical('penalty', ['l1', 'l2', 'elasticnet', 'none'])

    # Solver depends on penalty
    if penalty == 'l1':
        solver = 'saga'
    elif penalty == 'elasticnet':
        solver = 'saga'
    elif penalty == 'none':
        solver = trial.suggest_categorical('solver', ['newton-cg', 'lbfgs', 'sag', 'saga'])
    else:  # l2
        solver = trial.suggest_categorical('solver', ['newton-cg', 'lbfgs', 'liblinear', 'sag', 'saga'])

    params = {
        'C': trial.suggest_float('C', 0.001, 100, log=True),
        'penalty': penalty,
        'solver': solver,
        'max_iter': trial.suggest_int('max_iter', 100, 1000),
        'random_state': 42
    }

    # Add l1_ratio for elasticnet
    if penalty == 'elasticnet':
        params['l1_ratio'] = trial.suggest_float('l1_ratio', 0.0, 1.0)

    return params


def ridge_search_space(trial: optuna.Trial) -> Dict[str, Any]:
    """
    Hyperparameter search space for Ridge Regression.

    Tuned parameters:
    - alpha: Regularization strength (0.001-100)
    - solver: Optimization algorithm
    """
    return {
        'alpha': trial.suggest_float('alpha', 0.001, 100, log=True),
        'solver': trial.suggest_categorical('solver', ['auto', 'svd', 'cholesky', 'lsqr', 'sag', 'saga']),
        'random_state': 42
    }


def lasso_search_space(trial: optuna.Trial) -> Dict[str, Any]:
    """
    Hyperparameter search space for Lasso Regression.

    Tuned parameters:
    - alpha: Regularization strength (0.001-100)
    - max_iter: Maximum iterations (100-10000)
    """
    return {
        'alpha': trial.suggest_float('alpha', 0.001, 100, log=True),
        'max_iter': trial.suggest_int('max_iter', 100, 10000),
        'random_state': 42
    }


def linear_regression_search_space(trial: optuna.Trial) -> Dict[str, Any]:
    """
    Hyperparameter search space for Linear Regression.

    Linear regression has minimal hyperparameters.
    We tune fit_intercept only.
    """
    return {
        'fit_intercept': trial.suggest_categorical('fit_intercept', [True, False])
    }


def svm_search_space(trial: optuna.Trial) -> Dict[str, Any]:
    """
    Hyperparameter search space for Support Vector Machines.

    Tuned parameters:
    - C: Regularization parameter (0.1-100)
    - kernel: Kernel type (linear, poly, rbf, sigmoid)
    - gamma: Kernel coefficient (0.001-1.0)
    - degree: Polynomial degree (2-5, only for poly kernel)
    """
    kernel = trial.suggest_categorical('kernel', ['linear', 'poly', 'rbf', 'sigmoid'])

    params = {
        'C': trial.suggest_float('C', 0.1, 100, log=True),
        'kernel': kernel,
        'random_state': 42
    }

    if kernel in ['poly', 'rbf', 'sigmoid']:
        params['gamma'] = trial.suggest_categorical('gamma', ['scale', 'auto'])

    if kernel == 'poly':
        params['degree'] = trial.suggest_int('degree', 2, 5)

    return params


def knn_search_space(trial: optuna.Trial) -> Dict[str, Any]:
    """
    Hyperparameter search space for K-Nearest Neighbors.

    Tuned parameters:
    - n_neighbors: Number of neighbors (3-50)
    - weights: Weight function (uniform, distance)
    - algorithm: Algorithm to compute nearest neighbors
    - leaf_size: Leaf size for tree algorithms (10-50)
    - p: Power parameter for Minkowski metric (1=Manhattan, 2=Euclidean)
    """
    return {
        'n_neighbors': trial.suggest_int('n_neighbors', 3, 50),
        'weights': trial.suggest_categorical('weights', ['uniform', 'distance']),
        'algorithm': trial.suggest_categorical('algorithm', ['auto', 'ball_tree', 'kd_tree', 'brute']),
        'leaf_size': trial.suggest_int('leaf_size', 10, 50),
        'p': trial.suggest_int('p', 1, 2),
        'n_jobs': -1
    }


# ============================================================================
# MODEL REGISTRY
# ============================================================================

MODEL_REGISTRY: Dict[str, ModelInfo] = {
    'random_forest': ModelInfo(
        classifier_class=RandomForestClassifier,
        regressor_class=RandomForestRegressor,
        search_space_func=random_forest_search_space,
        requires_scaling=False
    ),
    'decision_tree': ModelInfo(
        classifier_class=DecisionTreeClassifier,
        regressor_class=DecisionTreeRegressor,
        search_space_func=decision_tree_search_space,
        requires_scaling=False
    ),
    'logistic_regression': ModelInfo(
        classifier_class=LogisticRegression,
        regressor_class=None,
        search_space_func=logistic_regression_search_space,
        requires_scaling=True
    ),
    'linear_regression': ModelInfo(
        classifier_class=None,
        regressor_class=LinearRegression,
        search_space_func=linear_regression_search_space,
        requires_scaling=True
    ),
    'ridge': ModelInfo(
        classifier_class=None,
        regressor_class=Ridge,
        search_space_func=ridge_search_space,
        requires_scaling=True
    ),
    'lasso': ModelInfo(
        classifier_class=None,
        regressor_class=Lasso,
        search_space_func=lasso_search_space,
        requires_scaling=True
    ),
    'svm': ModelInfo(
        classifier_class=SVC,
        regressor_class=SVR,
        search_space_func=svm_search_space,
        requires_scaling=True
    ),
    'knn': ModelInfo(
        classifier_class=KNeighborsClassifier,
        regressor_class=KNeighborsRegressor,
        search_space_func=knn_search_space,
        requires_scaling=True
    ),
}

# Add XGBoost if available
if XGBOOST_AVAILABLE:
    MODEL_REGISTRY['xgboost'] = ModelInfo(
        classifier_class=XGBClassifier,
        regressor_class=XGBRegressor,
        search_space_func=xgboost_search_space,
        requires_scaling=False
    )

# Add LightGBM if available
if LIGHTGBM_AVAILABLE:
    MODEL_REGISTRY['lightgbm'] = ModelInfo(
        classifier_class=LGBMClassifier,
        regressor_class=LGBMRegressor,
        search_space_func=lightgbm_search_space,
        requires_scaling=False
    )

# Add CatBoost if available
if CATBOOST_AVAILABLE:
    MODEL_REGISTRY['catboost'] = ModelInfo(
        classifier_class=CatBoostClassifier,
        regressor_class=CatBoostRegressor,
        search_space_func=catboost_search_space,
        requires_scaling=False
    )


# ============================================================================
# FACTORY FUNCTIONS
# ============================================================================

def get_available_models() -> list:
    """
    Returns list of available model names.

    Returns:
        List of model names that can be used
    """
    return list(MODEL_REGISTRY.keys())


def is_model_available(model_name: str) -> bool:
    """
    Check if a model is available.

    Args:
        model_name: Name of the model

    Returns:
        True if model is available, False otherwise
    """
    return model_name in MODEL_REGISTRY


def get_model_class(model_name: str, task_type: str):
    """
    Get the model class for a given model name and task type.

    Args:
        model_name: Name of the model (e.g., 'random_forest')
        task_type: 'classification' or 'regression'

    Returns:
        Model class (e.g., RandomForestClassifier)

    Raises:
        ValueError: If model is not available or not suitable for task
    """
    if model_name not in MODEL_REGISTRY:
        available = ', '.join(get_available_models())
        raise ValueError(
            f"Model '{model_name}' not available. "
            f"Available models: {available}"
        )

    model_info = MODEL_REGISTRY[model_name]

    if task_type == 'classification':
        if model_info.classifier_class is None:
            raise ValueError(f"Model '{model_name}' does not support classification")
        return model_info.classifier_class
    elif task_type == 'regression':
        if model_info.regressor_class is None:
            raise ValueError(f"Model '{model_name}' does not support regression")
        return model_info.regressor_class
    else:
        raise ValueError(f"Invalid task_type: {task_type}. Must be 'classification' or 'regression'")


def get_search_space(model_name: str, trial: optuna.Trial) -> Dict[str, Any]:
    """
    Get the Optuna search space for a model.

    Args:
        model_name: Name of the model
        trial: Optuna trial object

    Returns:
        Dictionary of hyperparameters

    Raises:
        ValueError: If model is not available
    """
    if model_name not in MODEL_REGISTRY:
        available = ', '.join(get_available_models())
        raise ValueError(
            f"Model '{model_name}' not available. "
            f"Available models: {available}"
        )

    model_info = MODEL_REGISTRY[model_name]
    return model_info.search_space_func(trial)


def requires_scaling(model_name: str) -> bool:
    """
    Check if a model requires feature scaling.

    Args:
        model_name: Name of the model

    Returns:
        True if model requires scaling (e.g., linear models, SVM)
        False otherwise (e.g., tree-based models)

    Raises:
        ValueError: If model is not available
    """
    if model_name not in MODEL_REGISTRY:
        available = ', '.join(get_available_models())
        raise ValueError(
            f"Model '{model_name}' not available. "
            f"Available models: {available}"
        )

    return MODEL_REGISTRY[model_name].requires_scaling


def get_model(model_name: str, task_type: str, trial: optuna.Trial):
    """
    Factory function to create a model instance with Optuna hyperparameters.

    This is the main entry point for creating models in the AutoML pipeline.

    Args:
        model_name: Name of the model (e.g., 'random_forest')
        task_type: 'classification' or 'regression'
        trial: Optuna trial object for suggesting hyperparameters

    Returns:
        Instantiated model with hyperparameters from Optuna

    Example:
        >>> trial = optuna.trial.FixedTrial({'n_estimators': 100, 'max_depth': 10})
        >>> model = get_model('random_forest', 'classification', trial)
        >>> type(model)
        <class 'sklearn.ensemble.RandomForestClassifier'>

    Raises:
        ValueError: If model or task type is invalid
    """
    # Get the model class
    model_class = get_model_class(model_name, task_type)

    # Get hyperparameters from Optuna
    params = get_search_space(model_name, trial)

    # Instantiate and return the model
    return model_class(**params)


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("AutoML_test Model Zoo")
    print("=" * 60)

    # List available models
    print("\n1. Available Models:")
    for model_name in get_available_models():
        scaling = "Requires scaling" if requires_scaling(model_name) else "No scaling needed"
        print(f"   - {model_name:20s} ({scaling})")

    # Test model creation with a dummy trial
    print("\n2. Testing Model Creation:")

    # Create a dummy trial with fixed parameters
    study = optuna.create_study()
    trial = study.ask()

    # Test Random Forest
    print("\n   Random Forest (Classification):")
    rf_clf = get_model('random_forest', 'classification', trial)
    print(f"   ✓ Created: {type(rf_clf).__name__}")

    # Test XGBoost if available
    if is_model_available('xgboost'):
        print("\n   XGBoost (Regression):")
        xgb_reg = get_model('xgboost', 'regression', trial)
        print(f"   ✓ Created: {type(xgb_reg).__name__}")

    # Test error handling
    print("\n3. Error Handling:")
    try:
        get_model('invalid_model', 'classification', trial)
    except ValueError as e:
        print(f"   ✓ Caught error: {str(e)[:60]}...")

    try:
        get_model('linear_regression', 'classification', trial)
    except ValueError as e:
        print(f"   ✓ Caught error: {str(e)[:60]}...")

    print("\n" + "=" * 60)
    print("Model Zoo working correctly!")
    print("=" * 60)
