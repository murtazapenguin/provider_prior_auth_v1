"""
Model Registry for AutoML_test
================================

This module provides model persistence and lifecycle management.
It handles saving, loading, versioning, and tracking of trained models.

Key Components:
- ModelRegistry: Main registry class for model management
- save_model: Serialize model with metadata
- load_model: Deserialize model by ID
- list_models: Enumerate all saved models
- Model versioning and metadata tracking

Storage Structure:
    registry_path/
    ├── models/          # Serialized model files (.joblib)
    ├── metadata/        # Model metadata (.json)
    └── index.json       # Master index of all models
"""

import os
import json
import joblib
from datetime import datetime
from typing import Dict, Any, Optional, List
from pathlib import Path
import shutil
from .exceptions import (
    RegistryError,
    ModelNotFoundError,
    ModelSaveError,
    ModelLoadError,
    validate_and_raise,
    wrap_exception,
    handle_errors
)


class ModelRegistry:
    """
    Model registry for persisting and managing trained models.

    This class provides a centralized system for:
    - Saving models with metadata
    - Loading models by ID or version
    - Listing and searching saved models
    - Version control and rollback
    - Metadata tracking

    Attributes:
        registry_path: Root directory for model storage
        models_dir: Directory for model files
        metadata_dir: Directory for metadata files
        index_file: Path to registry index file
        index: In-memory registry index

    Example:
        >>> registry = ModelRegistry('./model_registry')
        >>> model_id = registry.save_model(trained_model, metadata)
        >>> loaded_model = registry.load_model(model_id)
        >>> models = registry.list_models()
    """

    def __init__(self, registry_path: str = "./model_registry"):
        """
        Initialize the model registry.

        Args:
            registry_path: Root directory for model storage

        Creates directory structure if it doesn't exist:
            registry_path/
            ├── models/
            ├── metadata/
            └── index.json
        """
        self.registry_path = Path(registry_path)
        self.models_dir = self.registry_path / "models"
        self.metadata_dir = self.registry_path / "metadata"
        self.index_file = self.registry_path / "index.json"

        # Create directories
        self.registry_path.mkdir(parents=True, exist_ok=True)
        self.models_dir.mkdir(exist_ok=True)
        self.metadata_dir.mkdir(exist_ok=True)

        # Load or create index
        self.index = self._load_index()

        print(f"ModelRegistry initialized at: {self.registry_path}")

    def _load_index(self) -> Dict[str, Any]:
        """
        Load the registry index from disk.

        Returns:
            Registry index dictionary

        Creates empty index if file doesn't exist.
        """
        if self.index_file.exists():
            with open(self.index_file, 'r') as f:
                return json.load(f)
        else:
            return {
                "models": {},
                "created_at": datetime.now().isoformat(),
                "last_updated": datetime.now().isoformat()
            }

    def _save_index(self):
        """Save the registry index to disk."""
        self.index["last_updated"] = datetime.now().isoformat()
        with open(self.index_file, 'w') as f:
            json.dump(self.index, f, indent=2)

    def _generate_model_id(self, model_name: str) -> str:
        """
        Generate unique model ID.

        Args:
            model_name: Base name for the model

        Returns:
            Unique model ID with timestamp

        Format: {model_name}_{YYYYMMDD}_{HHMMSS}
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"{model_name}_{timestamp}"

    def save_model(
        self,
        model,
        metadata: Dict[str, Any],
        model_name: Optional[str] = None
    ) -> str:
        """
        Save a trained model with metadata.

        Args:
            model: Trained sklearn-compatible model
            metadata: Dictionary of model metadata
            model_name: Optional custom model name (uses metadata['model_name'] if None)

        Returns:
            model_id: Unique identifier for the saved model

        Metadata should include:
        - model_name: Type of model (e.g., 'random_forest')
        - task_type: 'classification' or 'regression'
        - hyperparameters: Model hyperparameters
        - metrics: Performance metrics
        - feature_names: List of feature names (optional)

        Example:
            >>> metadata = {
            ...     'model_name': 'random_forest',
            ...     'task_type': 'classification',
            ...     'hyperparameters': {'n_estimators': 100},
            ...     'metrics': {'accuracy': 0.92}
            ... }
            >>> model_id = registry.save_model(model, metadata)
        """
        # Generate model ID
        if model_name is None:
            model_name = metadata.get('model_name', 'model')
        model_id = self._generate_model_id(model_name)

        # Add system metadata
        metadata['model_id'] = model_id
        metadata['saved_at'] = datetime.now().isoformat()
        metadata['library_version'] = '0.1.0'  # AutoML_test version

        # Save model file
        model_path = self.models_dir / f"{model_id}.joblib"
        joblib.dump(model, model_path)

        # Save metadata file
        metadata_path = self.metadata_dir / f"{model_id}.json"
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)

        # Update index
        self.index["models"][model_id] = {
            "model_name": model_name,
            "model_path": str(model_path),
            "metadata_path": str(metadata_path),
            "saved_at": metadata['saved_at'],
            "task_type": metadata.get('task_type'),
            "primary_metric": metadata.get('metrics', {})
        }
        self._save_index()

        print(f"Model saved successfully!")
        print(f"  Model ID: {model_id}")
        print(f"  Location: {model_path}")

        return model_id

    def load_model(self, model_id: str):
        """
        Load a saved model by ID.

        Args:
            model_id: Unique model identifier

        Returns:
            Loaded model object

        Raises:
            ModelNotFoundError: If model_id not found
            ModelLoadError: If model file cannot be loaded

        Example:
            >>> model = registry.load_model('random_forest_20240115_123456')
            >>> predictions = model.predict(X_test)
        """
        if model_id not in self.index["models"]:
            raise ModelNotFoundError(
                model_id,
                details={"available_models": list(self.index["models"].keys())}
            )

        model_info = self.index["models"][model_id]
        model_path = Path(model_info["model_path"])

        if not model_path.exists():
            raise ModelLoadError(
                model_id=model_id,
                reason=f"Model file not found: {model_path}"
            )

        with handle_errors("model loading", {IOError: ModelLoadError, OSError: ModelLoadError}):
            model = joblib.load(model_path)

        print(f"Model loaded: {model_id}")

        return model

    def load_latest_model(self, model_name: Optional[str] = None):
        """
        Load the most recently saved model.

        Args:
            model_name: Optional filter by model name (e.g., 'random_forest')

        Returns:
            Tuple of (model, model_id)

        Raises:
            ModelNotFoundError: If no models found

        Example:
            >>> model, model_id = registry.load_latest_model()
            >>> model, model_id = registry.load_latest_model('random_forest')
        """
        models = self.list_models(model_name=model_name)

        if not models:
            if model_name:
                raise ModelNotFoundError(
                    f"model_name_{model_name}",
                    details={"model_name": model_name, "reason": "No models with this name"}
                )
            else:
                raise RegistryError(
                    "No models found in registry",
                    details={"operation": "load_latest_model"}
                )

        # Sort by saved_at timestamp
        latest_id = max(models, key=lambda m: models[m]["saved_at"])
        model = self.load_model(latest_id)

        return model, latest_id

    def get_model_metadata(self, model_id: str) -> Dict[str, Any]:
        """
        Load metadata for a model without loading the model itself.

        Args:
            model_id: Unique model identifier

        Returns:
            Dictionary of model metadata

        Raises:
            ModelNotFoundError: If model_id not found
            ModelLoadError: If metadata file not found

        Example:
            >>> metadata = registry.get_model_metadata('random_forest_20240115_123456')
            >>> print(metadata['metrics'])
        """
        if model_id not in self.index["models"]:
            raise ModelNotFoundError(
                model_id,
                details={"available_models": list(self.index["models"].keys())}
            )

        model_info = self.index["models"][model_id]
        metadata_path = Path(model_info["metadata_path"])

        if not metadata_path.exists():
            raise ModelLoadError(
                model_id=model_id,
                reason=f"Metadata file not found: {metadata_path}"
            )

        with open(metadata_path, 'r') as f:
            metadata = json.load(f)

        return metadata

    def list_models(
        self,
        model_name: Optional[str] = None,
        task_type: Optional[str] = None
    ) -> Dict[str, Dict[str, Any]]:
        """
        List all saved models with optional filtering.

        Args:
            model_name: Optional filter by model name
            task_type: Optional filter by task type ('classification' or 'regression')

        Returns:
            Dictionary of model_id -> model_info

        Example:
            >>> models = registry.list_models()
            >>> for model_id, info in models.items():
            ...     print(f"{model_id}: {info['saved_at']}")

            >>> rf_models = registry.list_models(model_name='random_forest')
        """
        models = self.index["models"]

        # Apply filters
        if model_name:
            models = {k: v for k, v in models.items() if v["model_name"] == model_name}

        if task_type:
            models = {k: v for k, v in models.items() if v.get("task_type") == task_type}

        return models

    def delete_model(self, model_id: str) -> bool:
        """
        Delete a model and its metadata.

        Args:
            model_id: Unique model identifier

        Returns:
            True if successful

        Raises:
            ModelNotFoundError: If model_id not found

        Example:
            >>> registry.delete_model('random_forest_20240115_123456')
        """
        if model_id not in self.index["models"]:
            raise ModelNotFoundError(
                model_id,
                details={"available_models": list(self.index["models"].keys())}
            )

        model_info = self.index["models"][model_id]

        # Delete model file
        model_path = Path(model_info["model_path"])
        if model_path.exists():
            model_path.unlink()

        # Delete metadata file
        metadata_path = Path(model_info["metadata_path"])
        if metadata_path.exists():
            metadata_path.unlink()

        # Remove from index
        del self.index["models"][model_id]
        self._save_index()

        print(f"Model deleted: {model_id}")
        return True

    def export_model(self, model_id: str, export_path: str) -> str:
        """
        Export a model to a specified location.

        Args:
            model_id: Unique model identifier
            export_path: Destination path for export

        Returns:
            Path to exported model

        Example:
            >>> registry.export_model('random_forest_20240115_123456', './production/model.joblib')
        """
        if model_id not in self.index["models"]:
            available = list(self.index["models"].keys())
            raise ValueError(
                f"Model '{model_id}' not found. "
                f"Available models: {available}"
            )

        model_info = self.index["models"][model_id]
        model_path = Path(model_info["model_path"])
        export_path = Path(export_path)

        # Create export directory if needed
        export_path.parent.mkdir(parents=True, exist_ok=True)

        # Copy model file
        shutil.copy2(model_path, export_path)

        # Also export metadata
        metadata_path = Path(model_info["metadata_path"])
        metadata_export = export_path.parent / f"{export_path.stem}_metadata.json"
        shutil.copy2(metadata_path, metadata_export)

        print(f"Model exported to: {export_path}")
        print(f"Metadata exported to: {metadata_export}")

        return str(export_path)

    def get_best_model(
        self,
        metric_name: str,
        maximize: bool = True,
        model_name: Optional[str] = None
    ):
        """
        Get the best model based on a specific metric.

        Args:
            metric_name: Name of metric to optimize (e.g., 'accuracy', 'mse')
            maximize: True to maximize metric, False to minimize
            model_name: Optional filter by model name

        Returns:
            Tuple of (model, model_id, metric_value)

        Raises:
            ValueError: If no models found or metric not available

        Example:
            >>> model, model_id, accuracy = registry.get_best_model('accuracy', maximize=True)
            >>> print(f"Best model: {model_id} with accuracy: {accuracy}")
        """
        models = self.list_models(model_name=model_name)

        validate_and_raise(
            len(models) > 0,
            RegistryError,
            "No models found in registry",
            details={"operation": "get_best_model", "model_name": model_name}
        )

        # Find best model
        best_id = None
        best_value = float('-inf') if maximize else float('inf')

        for model_id, info in models.items():
            metrics = info.get("primary_metric", {})
            if metric_name in metrics:
                value = metrics[metric_name]
                if maximize:
                    if value > best_value:
                        best_value = value
                        best_id = model_id
                else:
                    if value < best_value:
                        best_value = value
                        best_id = model_id

        validate_and_raise(
            best_id is not None,
            RegistryError,
            f"Metric '{metric_name}' not found in any model",
            details={"metric_name": metric_name, "available_models": list(models.keys())}
        )

        model = self.load_model(best_id)
        return model, best_id, best_value

    def summary(self) -> str:
        """
        Get a summary of the registry.

        Returns:
            Formatted summary string

        Example:
            >>> print(registry.summary())
        """
        lines = []
        lines.append("=" * 60)
        lines.append("Model Registry Summary")
        lines.append("=" * 60)
        lines.append(f"Registry path: {self.registry_path}")
        lines.append(f"Total models: {len(self.index['models'])}")

        if self.index['models']:
            lines.append(f"\nSaved models:")
            for model_id, info in list(self.index['models'].items())[:10]:  # Show first 10
                lines.append(f"  - {model_id}")
                lines.append(f"    Type: {info.get('model_name')}")
                lines.append(f"    Saved: {info.get('saved_at')}")

            if len(self.index['models']) > 10:
                lines.append(f"  ... and {len(self.index['models']) - 10} more")

        lines.append("=" * 60)
        return "\n".join(lines)

    def save_artifact(self, model_id: str, artifact_name: str, artifact: Any) -> None:
        """
        Save an additional artifact (preprocessor, feature selector, etc.) for a model.

        Args:
            model_id: ID of the model
            artifact_name: Name of the artifact (e.g., 'preprocessor', 'feature_selector')
            artifact: The artifact object to save

        Raises:
            ModelSaveError: If artifact cannot be saved

        Example:
            >>> registry.save_artifact(model_id, 'preprocessor', preprocessor_object)
        """
        with handle_errors("artifact saving", {IOError: ModelSaveError, OSError: ModelSaveError}):
            # Create artifacts directory for this model
            model_dir = self.models_dir / model_id
            artifacts_dir = model_dir / 'artifacts'
            artifacts_dir.mkdir(parents=True, exist_ok=True)

            # Save artifact
            artifact_path = artifacts_dir / f"{artifact_name}.joblib"
            joblib.dump(artifact, artifact_path)

    def load_artifact(self, model_id: str, artifact_name: str) -> Any:
        """
        Load an additional artifact for a model.

        Args:
            model_id: ID of the model
            artifact_name: Name of the artifact to load

        Returns:
            The loaded artifact object

        Raises:
            ModelLoadError: If artifact doesn't exist or cannot be loaded

        Example:
            >>> preprocessor = registry.load_artifact(model_id, 'preprocessor')
        """
        artifact_path = self.models_dir / model_id / 'artifacts' / f"{artifact_name}.joblib"

        if not artifact_path.exists():
            raise ModelLoadError(
                model_id=model_id,
                reason=f"Artifact '{artifact_name}' not found"
            )

        with handle_errors("artifact loading", {IOError: ModelLoadError, OSError: ModelLoadError}):
            return joblib.load(artifact_path)


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def save_model_quick(
    model,
    model_name: str,
    metrics: Dict[str, float],
    hyperparameters: Dict[str, Any],
    task_type: str,
    registry_path: str = "./model_registry"
) -> str:
    """
    Quick function to save a model with minimal boilerplate.

    Args:
        model: Trained model
        model_name: Name of model type
        metrics: Dictionary of metrics
        hyperparameters: Dictionary of hyperparameters
        task_type: 'classification' or 'regression'
        registry_path: Path to registry

    Returns:
        model_id: Unique identifier

    Example:
        >>> model_id = save_model_quick(
        ...     model=trained_model,
        ...     model_name='random_forest',
        ...     metrics={'accuracy': 0.92},
        ...     hyperparameters={'n_estimators': 100},
        ...     task_type='classification'
        ... )
    """
    registry = ModelRegistry(registry_path)

    metadata = {
        'model_name': model_name,
        'task_type': task_type,
        'hyperparameters': hyperparameters,
        'metrics': metrics
    }

    return registry.save_model(model, metadata)


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.datasets import make_classification

    print("=" * 60)
    print("AutoML_test Registry Test")
    print("=" * 60)

    # Create a dummy model
    X, y = make_classification(n_samples=100, n_features=10, random_state=42)
    model = RandomForestClassifier(n_estimators=50, random_state=42)
    model.fit(X, y)

    # Initialize registry
    print("\n1. Initializing registry...")
    registry = ModelRegistry("./test_registry")

    # Save model
    print("\n2. Saving model...")
    metadata = {
        'model_name': 'random_forest',
        'task_type': 'classification',
        'hyperparameters': {'n_estimators': 50, 'max_depth': None},
        'metrics': {'accuracy': 0.92, 'f1': 0.89}
    }
    model_id = registry.save_model(model, metadata)

    # Load model
    print("\n3. Loading model...")
    loaded_model = registry.load_model(model_id)
    print(f"   ✓ Model loaded: {type(loaded_model).__name__}")

    # Get metadata
    print("\n4. Getting metadata...")
    loaded_metadata = registry.get_model_metadata(model_id)
    print(f"   ✓ Metrics: {loaded_metadata['metrics']}")

    # List models
    print("\n5. Listing models...")
    models = registry.list_models()
    print(f"   ✓ Found {len(models)} model(s)")

    # Load latest
    print("\n6. Loading latest model...")
    latest_model, latest_id = registry.load_latest_model()
    print(f"   ✓ Latest model ID: {latest_id}")

    # Summary
    print("\n7. Registry summary:")
    print(registry.summary())

    # Cleanup
    print("\n8. Cleaning up...")
    import shutil
    shutil.rmtree("./test_registry")
    print("   ✓ Test registry deleted")

    print("\n" + "=" * 60)
    print("Registry working correctly!")
    print("=" * 60)
