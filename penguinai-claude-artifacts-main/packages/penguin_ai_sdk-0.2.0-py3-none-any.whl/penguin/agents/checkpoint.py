"""
Agent checkpointing for state persistence and crash recovery.

Provides checkpoint management for long-running agent workflows:
- Save agent state after each iteration
- Resume crashed/interrupted runs
- Tool validation on resume

Example:
    from penguin.agents import Agent

    # Enable checkpointing
    agent = Agent(client=client, tools=[...], enable_checkpointing=True)
    result = await agent.run("Complex multi-step task")

    # Resume after crash
    result = await agent.resume("abc-123-run-id")

    # List resumable runs
    for run in agent.list_resumable():
        print(f"{run.agent_run_id}: {run.original_prompt[:50]}...")
"""

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from penguin.llm.base import BaseChatCompletionClient
    from penguin.tools import ToolExecutor

logger = logging.getLogger(__name__)


class CheckpointStatus(str, Enum):
    """Status of an agent checkpoint."""
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class CheckpointToolMismatchError(Exception):
    """
    Raised when resuming a checkpoint with different tools than originally registered.

    Attributes:
        message: Human-readable error description
        expected_tools: Tools registered in the checkpoint
        actual_tools: Tools provided for resume
    """

    def __init__(
        self,
        message: str,
        expected_tools: List[str],
        actual_tools: List[str],
    ):
        self.message = message
        self.expected_tools = expected_tools
        self.actual_tools = actual_tools
        super().__init__(message)


class AgentCheckpoint(BaseModel):
    """
    Persisted state of an agent execution.

    Captures all state needed to resume a crashed/interrupted agent run:
    - Conversation messages
    - Tool execution history
    - Token usage and iteration progress

    Attributes:
        checkpoint_id: Unique identifier for this specific checkpoint
        agent_run_id: Identifier for the overall agent run (stays same across updates)
        iteration: Current iteration number (0-indexed)
        status: Current status (running, completed, failed)
        messages: Serialized message list
        tool_calls_log: History of tool executions
        registered_tools: Tool names for validation on resume
        original_prompt: The initial user prompt
        system_prompt: System prompt if provided
        model: Model identifier
        provider: Provider name
        max_iterations: Maximum iterations configured
        total_tokens: Cumulative token usage
        created_at: Checkpoint creation time
        updated_at: Last update time
        metadata: Additional metadata
        error: Error message if status is FAILED
    """

    checkpoint_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    agent_run_id: str
    iteration: int = 0
    status: CheckpointStatus = CheckpointStatus.RUNNING
    messages: List[Dict[str, Any]] = Field(default_factory=list)
    tool_calls_log: List[Dict[str, Any]] = Field(default_factory=list)
    registered_tools: List[str] = Field(default_factory=list)
    original_prompt: str
    system_prompt: Optional[str] = None
    model: str
    provider: str
    max_iterations: int = 10
    total_tokens: int = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: Dict[str, Any] = Field(default_factory=dict)
    error: Optional[str] = None

    class Config:
        use_enum_values = True


class CheckpointSummary(BaseModel):
    """
    Lightweight checkpoint summary for listing.

    Contains essential info without full message history.
    """

    agent_run_id: str
    status: CheckpointStatus
    iteration: int
    original_prompt: str  # Truncated to 200 chars
    model: str
    provider: str
    created_at: datetime
    updated_at: datetime

    class Config:
        use_enum_values = True


class CheckpointRegistry:
    """
    File-based storage for agent checkpoints.

    Stores checkpoints as JSON files at ~/.penguin/checkpoints/{agent_run_id}.json

    Example:
        registry = CheckpointRegistry()
        registry.save(checkpoint)
        loaded = registry.load("agent-run-id")
        registry.delete("agent-run-id")
    """

    def __init__(self, base_path: Optional[str] = None):
        """
        Initialize the checkpoint registry.

        Args:
            base_path: Custom storage path. Defaults to ~/.penguin/checkpoints/
        """
        if base_path:
            self.base_path = Path(base_path)
        else:
            self.base_path = Path.home() / ".penguin" / "checkpoints"

        # Ensure directory exists
        self.base_path.mkdir(parents=True, exist_ok=True)

    def _get_path(self, agent_run_id: str) -> Path:
        """Get the file path for a checkpoint."""
        return self.base_path / f"{agent_run_id}.json"

    def save(self, checkpoint: AgentCheckpoint) -> str:
        """
        Save a checkpoint to disk.

        Args:
            checkpoint: The checkpoint to save

        Returns:
            The agent_run_id of the saved checkpoint
        """
        checkpoint.updated_at = datetime.now(timezone.utc)
        path = self._get_path(checkpoint.agent_run_id)

        # Serialize with datetime handling
        data = checkpoint.model_dump(mode="json")

        with open(path, "w") as f:
            json.dump(data, f, indent=2, default=str)

        logger.debug(f"Saved checkpoint {checkpoint.agent_run_id} at iteration {checkpoint.iteration}")
        return checkpoint.agent_run_id

    def load(self, agent_run_id: str) -> Optional[AgentCheckpoint]:
        """
        Load a checkpoint from disk.

        Args:
            agent_run_id: The run ID to load

        Returns:
            The checkpoint if found, None otherwise
        """
        path = self._get_path(agent_run_id)

        if not path.exists():
            return None

        with open(path) as f:
            data = json.load(f)

        return AgentCheckpoint.model_validate(data)

    def delete(self, agent_run_id: str) -> bool:
        """
        Delete a checkpoint.

        Args:
            agent_run_id: The run ID to delete

        Returns:
            True if deleted, False if not found
        """
        path = self._get_path(agent_run_id)

        if path.exists():
            path.unlink()
            logger.debug(f"Deleted checkpoint {agent_run_id}")
            return True
        return False

    def list_all(self) -> List[CheckpointSummary]:
        """
        List all checkpoints.

        Returns:
            List of checkpoint summaries
        """
        summaries = []

        for path in self.base_path.glob("*.json"):
            try:
                with open(path) as f:
                    data = json.load(f)

                summaries.append(CheckpointSummary(
                    agent_run_id=data["agent_run_id"],
                    status=data["status"],
                    iteration=data["iteration"],
                    original_prompt=data["original_prompt"][:200],
                    model=data["model"],
                    provider=data["provider"],
                    created_at=data["created_at"],
                    updated_at=data["updated_at"],
                ))
            except (json.JSONDecodeError, KeyError) as e:
                logger.warning(f"Failed to parse checkpoint {path}: {e}")
                continue

        # Sort by updated_at descending (most recent first)
        summaries.sort(key=lambda s: s.updated_at, reverse=True)
        return summaries

    def list_active(self) -> List[CheckpointSummary]:
        """
        List only active (running/failed) checkpoints that can be resumed.

        Returns:
            List of resumable checkpoint summaries
        """
        return [
            s for s in self.list_all()
            if s.status in (CheckpointStatus.RUNNING, CheckpointStatus.FAILED)
        ]

    def cleanup(self, max_age_hours: int = 24, include_completed: bool = True) -> int:
        """
        Remove old checkpoints.

        Args:
            max_age_hours: Delete checkpoints older than this
            include_completed: If True, delete completed checkpoints regardless of age

        Returns:
            Number of checkpoints deleted
        """
        deleted = 0
        cutoff = datetime.now(timezone.utc)

        for path in self.base_path.glob("*.json"):
            try:
                with open(path) as f:
                    data = json.load(f)

                status = data.get("status", "")
                updated = datetime.fromisoformat(data.get("updated_at", "").replace("Z", "+00:00"))

                # Calculate age in hours
                age_hours = (cutoff - updated).total_seconds() / 3600

                should_delete = False

                # Delete completed checkpoints if requested
                if include_completed and status == CheckpointStatus.COMPLETED:
                    should_delete = True

                # Delete old checkpoints
                if age_hours > max_age_hours:
                    should_delete = True

                if should_delete:
                    path.unlink()
                    deleted += 1
                    logger.debug(f"Cleaned up checkpoint {data.get('agent_run_id')}")

            except Exception as e:
                logger.warning(f"Failed to process checkpoint {path} during cleanup: {e}")

        return deleted


class CheckpointManager:
    """
    High-level API for checkpoint operations.

    Manages checkpoint lifecycle:
    - Create new checkpoints
    - Update after each iteration
    - Mark as completed/failed
    - Load and validate for resume

    Example:
        manager = CheckpointManager()

        # Create checkpoint for new run
        checkpoint = manager.create(
            prompt="Analyze sales data",
            client=client,
            executor=executor,
            max_iterations=10
        )

        # Update after each iteration
        manager.update_iteration(checkpoint, messages, tool_log, iteration=2)

        # Mark completed
        manager.complete(checkpoint)

        # Resume from checkpoint
        checkpoint = manager.load_for_resume("agent-run-id", executor)
        messages = manager.restore_messages(checkpoint)
    """

    def __init__(self, registry: Optional[CheckpointRegistry] = None):
        """
        Initialize the checkpoint manager.

        Args:
            registry: Custom registry instance. Creates default if not provided.
        """
        self.registry = registry or CheckpointRegistry()

    def create(
        self,
        prompt: str,
        client: "BaseChatCompletionClient",
        executor: "ToolExecutor",
        system_prompt: Optional[str] = None,
        max_iterations: int = 10,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AgentCheckpoint:
        """
        Create a new checkpoint for an agent run.

        Args:
            prompt: The user's prompt
            client: LLM client (used for model/provider info)
            executor: Tool executor (used for tool list)
            system_prompt: Optional system prompt
            max_iterations: Max iterations configured
            metadata: Optional additional metadata

        Returns:
            A new AgentCheckpoint instance (already saved to disk)
        """
        from penguin.llm import SystemMessage, UserMessage

        # Build initial messages
        initial_messages = []
        if system_prompt:
            initial_messages.append(SystemMessage(system_prompt).model_dump())
        initial_messages.append(UserMessage(prompt).model_dump())

        checkpoint = AgentCheckpoint(
            agent_run_id=str(uuid.uuid4()),
            original_prompt=prompt,
            system_prompt=system_prompt,
            model=client.model,
            provider=client.provider_name,
            max_iterations=max_iterations,
            registered_tools=executor.list_names(),
            messages=initial_messages,
            metadata=metadata or {},
        )

        self.registry.save(checkpoint)
        logger.info(f"Created checkpoint {checkpoint.agent_run_id}")
        return checkpoint

    def update_iteration(
        self,
        checkpoint: AgentCheckpoint,
        messages: List[Any],
        tool_calls_log: List[Dict[str, Any]],
        iteration: int,
        total_tokens: int,
    ) -> None:
        """
        Update checkpoint after an iteration completes.

        Args:
            checkpoint: The checkpoint to update
            messages: Current message list (will be serialized)
            tool_calls_log: Current tool calls history
            iteration: Current iteration number
            total_tokens: Cumulative token usage
        """
        # Serialize messages
        serialized_messages = []
        for msg in messages:
            if hasattr(msg, "model_dump"):
                serialized_messages.append(msg.model_dump())
            elif isinstance(msg, dict):
                serialized_messages.append(msg)
            else:
                # Fallback - try to convert
                serialized_messages.append({
                    "role": getattr(msg, "role", "unknown"),
                    "content": getattr(msg, "content", str(msg)),
                })

        checkpoint.messages = serialized_messages
        checkpoint.tool_calls_log = tool_calls_log
        checkpoint.iteration = iteration
        checkpoint.total_tokens = total_tokens
        checkpoint.checkpoint_id = str(uuid.uuid4())  # New checkpoint ID for this update

        self.registry.save(checkpoint)
        logger.debug(f"Updated checkpoint {checkpoint.agent_run_id} at iteration {iteration}")

    def complete(self, checkpoint: AgentCheckpoint) -> None:
        """
        Mark a checkpoint as completed.

        Args:
            checkpoint: The checkpoint to mark complete
        """
        checkpoint.status = CheckpointStatus.COMPLETED
        self.registry.save(checkpoint)
        logger.info(f"Completed checkpoint {checkpoint.agent_run_id}")

    def fail(self, checkpoint: AgentCheckpoint, error: str) -> None:
        """
        Mark a checkpoint as failed.

        Args:
            checkpoint: The checkpoint to mark failed
            error: Error message describing the failure
        """
        checkpoint.status = CheckpointStatus.FAILED
        checkpoint.error = error
        self.registry.save(checkpoint)
        logger.warning(f"Failed checkpoint {checkpoint.agent_run_id}: {error}")

    def load_for_resume(
        self,
        agent_run_id: str,
        executor: "ToolExecutor",
        strict_tool_match: bool = True,
    ) -> AgentCheckpoint:
        """
        Load a checkpoint for resuming.

        Validates that the tools match the original run.

        Args:
            agent_run_id: The run ID to resume
            executor: Tool executor with tools for the resumed run
            strict_tool_match: If True, raise error if tools don't match exactly

        Returns:
            The loaded checkpoint

        Raises:
            CheckpointToolMismatchError: If tools don't match
            ValueError: If checkpoint not found
        """
        checkpoint = self.registry.load(agent_run_id)

        if checkpoint is None:
            raise ValueError(f"Checkpoint not found: {agent_run_id}")

        # Validate tools match
        current_tools = set(executor.list_names())
        checkpoint_tools = set(checkpoint.registered_tools)

        if strict_tool_match and current_tools != checkpoint_tools:
            missing = checkpoint_tools - current_tools
            extra = current_tools - checkpoint_tools

            raise CheckpointToolMismatchError(
                message=(
                    f"Tool mismatch on resume. "
                    f"Missing: {missing or 'none'}. "
                    f"Extra: {extra or 'none'}."
                ),
                expected_tools=list(checkpoint_tools),
                actual_tools=list(current_tools),
            )

        # Mark as running again
        checkpoint.status = CheckpointStatus.RUNNING
        checkpoint.error = None
        self.registry.save(checkpoint)

        logger.info(f"Loaded checkpoint {agent_run_id} for resume at iteration {checkpoint.iteration}")
        return checkpoint

    def restore_messages(self, checkpoint: AgentCheckpoint) -> List[Any]:
        """
        Restore messages from a checkpoint.

        Converts serialized message dicts back to Message objects.

        Args:
            checkpoint: The checkpoint containing serialized messages

        Returns:
            List of Message objects
        """
        from penguin.llm import (
            SystemMessage, UserMessage, AssistantMessage, ToolMessage,
            MessageRole
        )
        from penguin.llm.messages import ToolCall

        messages = []

        for msg_data in checkpoint.messages:
            role = msg_data.get("role", "")
            content = msg_data.get("content")

            if role == MessageRole.SYSTEM:
                messages.append(SystemMessage(content=content))

            elif role == MessageRole.USER:
                messages.append(UserMessage(content=content))

            elif role == MessageRole.ASSISTANT:
                # Restore tool calls if present
                tool_calls = None
                if msg_data.get("tool_calls"):
                    tool_calls = [
                        ToolCall.model_validate(tc)
                        for tc in msg_data["tool_calls"]
                    ]
                messages.append(AssistantMessage(
                    content=content,
                    tool_calls=tool_calls,
                    thinking=msg_data.get("thinking"),
                ))

            elif role == MessageRole.TOOL:
                messages.append(ToolMessage(
                    tool_call_id=msg_data.get("tool_call_id", ""),
                    tool_name=msg_data.get("tool_name", ""),
                    content=content or "",
                    is_error=msg_data.get("is_error", False),
                ))

        return messages

    def list_resumable(self) -> List[CheckpointSummary]:
        """
        List checkpoints that can be resumed.

        Returns:
            List of resumable checkpoint summaries
        """
        return self.registry.list_active()

    def cleanup(self, max_age_hours: int = 24) -> int:
        """
        Clean up old and completed checkpoints.

        Args:
            max_age_hours: Delete checkpoints older than this

        Returns:
            Number of checkpoints deleted
        """
        return self.registry.cleanup(max_age_hours=max_age_hours)


# Convenience functions for module-level access

def list_resumable_runs() -> List[CheckpointSummary]:
    """
    List agent runs that can be resumed.

    Returns:
        List of checkpoint summaries for resumable runs
    """
    return CheckpointManager().list_resumable()


def cleanup_old_checkpoints(max_age_hours: int = 24) -> int:
    """
    Clean up old and completed checkpoints.

    Args:
        max_age_hours: Delete checkpoints older than this

    Returns:
        Number of checkpoints deleted
    """
    return CheckpointManager().cleanup(max_age_hours=max_age_hours)
