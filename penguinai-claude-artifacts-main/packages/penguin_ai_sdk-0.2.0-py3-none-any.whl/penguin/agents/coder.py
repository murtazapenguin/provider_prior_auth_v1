# START OF FILE: penguin/agents/coder.py ---
"""
Penguin Code Generator Agent

Generates executable Python code from workflow descriptions.
"""

import re
import ast
import os
import sys
import asyncio
import tempfile
import logging
from pathlib import Path
from typing import Dict, Any, Optional, List
from ..llm.base import BaseChatCompletionClient
from ..llm.messages import UserMessage, SystemMessage
from ..observability.context import get_current_trace_id
from ..observability.setup import is_tracing_enabled

logger = logging.getLogger("penguin.agents.coder")

# =============================================================================
# PROMPT TEMPLATES
# =============================================================================

CODE_GENERATION_SYSTEM_PROMPT = """You are an expert Python developer specializing in AI/LLM applications.

Your task is to generate clean, working Python code that implements the given workflow using the Penguin AI Library.

## CODE STRUCTURE GUIDELINES

Choose the structure that best fits the workflow complexity:

**Simple Workflows** (few number of steps, straightforward logic):
- Sequential code in a single main() function
- No need for separate classes or complex abstractions

**Multi-Step Workflows** (multiple steps, clear data passing, some requirement of tools and agents):
- Separate async functions for each logical step
- Clear function signatures showing data flow
- Use Pydantic models where data structure validation helps

**Complex Workflows** (branching logic, multiple tools, agentic behavior):
- Consider using the Agent class with tools
- Use structured output (output_format) for reliable data extraction
- Implement proper error handling and retries

## CRITICAL RULES

1. **Environment Variables**: ALWAYS load environment variables at the start
   - Add `from dotenv import load_dotenv` to imports
   - Call `load_dotenv()` BEFORE any other code runs
   - This ensures API keys and configs are available

2. **Penguin Library Only**: Use ONLY the Penguin AI Library for all LLM operations
   - DO NOT use: requests, urllib, openai, anthropic directly
   - DO use: penguin.llm.create_client(), UserMessage, SystemMessage

3. **Async/Await**: All LLM calls are async
   - Every function calling LLM must be `async def`
   - Every LLM call must use `await`

4. **Error Handling**: Include try/except for:
   - LLM calls (network errors, rate limits)
   - JSON parsing (use json_repair.loads for LLM-generated JSON)
   - File operations if applicable

5. **Executable Code**: The code must run!
   - Include all imports at the top
   - Include `if __name__ == "__main__":` block
   - Use `asyncio.run(main(...))` to execute async code

6. **Data Consistency**: When using structured output:
   - Define Pydantic models clearly
   - Validate data between steps
   - Use type hints throughout

## TASK CLASSIFICATION: LLM vs CODE

Before writing code, classify each subtask:

**SEMANTIC TASKS** → Use LLM with output_format:
- Parsing natural language to structured data
- Extracting meaning/intent/concepts
- Classification and categorization
- Understanding hierarchies and relationships
- Finding logical boundaries in text

**MECHANICAL TASKS** → Use code/regex:
- Pattern matching with known formats
- Data format conversions (structured → structured)
- Calculations and aggregations
- File operations and API calls
- String transformations with clear rules

**Example - Processing a document:**
```python
# WRONG: Using code for semantic task
lines = document.split('\\n')
items = [line for line in lines if line.strip()]  # ❌ Wrong

# RIGHT: Using LLM for semantic understanding
result = await client.create(
    [UserMessage(f"Extract the logical items from this document:\\n{document}")],
    output_format=ItemList  # ✅ Correct
)
items = result.content["items"]
```

**KEY INSIGHT**: If you're tempted to use split(), regex, or string matching
to extract *meaning* from text, you should probably use LLM instead.

## OUTPUT FORMAT

Return ONLY Python code in a ```python code block.
Do not include explanations outside the code block.
Add comments within the code to explain complex logic.
"""

CODE_GENERATION_USER_PROMPT = """## PENGUIN LIBRARY API REFERENCE
{library_docs}

## TASK
{task}

## WORKFLOW TO IMPLEMENT
{workflow}

## IMPLEMENTATION HINTS
{implementation_hints}

## ADDITIONAL CONTEXT
{additional_context}

Generate complete, executable Python code that implements this workflow.

Requirements:
1. Follow the workflow steps in order
2. Apply the implementation hints
3. Use appropriate Penguin library features
4. Make the code production-ready
5. Include a main() function that can process input data
"""

CODE_FIX_PROMPT = """The generated code failed during test execution.

## ERROR ENCOUNTERED
{error_message}

## TEST INPUT USED
{test_input}

## ORIGINAL CODE
```python
{original_code}
```

## YOUR TASK

Fix the code to handle this error. Common issues:
- Import errors: Make sure all imports are correct and available
- Async errors: Ensure all async calls use await
- Type errors: Check data types match expected formats
- API errors: Verify Penguin library usage is correct

Return ONLY the corrected Python code in a ```python code block.
Do not explain the changes - just provide working code.
"""


def _get_tracer():
    """Get OTel tracer if available."""
    try:
        from opentelemetry import trace
        return trace.get_tracer("penguin.agents.coder")
    except ImportError:
        return None


class CodeValidator:
    """
    Validates generated code by executing it with test data.

    Executes code in a subprocess with:
    - Environment variables loaded from .env
    - Timeout protection
    - Output capture
    """

    def __init__(
        self,
        env_file_path: Optional[Path] = None,
        timeout_seconds: int = 60
    ):
        """
        Initialize the code validator.

        Args:
            env_file_path: Path to .env file (default: .env in current directory)
            timeout_seconds: Max execution time (default: 60)
        """
        self.env_path = env_file_path or Path(".env")
        self.timeout = timeout_seconds

    def _load_env(self) -> Dict[str, str]:
        """Load environment variables from .env file."""
        try:
            from dotenv import dotenv_values
            if self.env_path.exists():
                return dict(dotenv_values(self.env_path))
        except ImportError:
            logger.warning("python-dotenv not installed, skipping .env loading")
        return {}

    def _create_test_script(self, code: str, test_input: Any) -> str:
        """
        Wrap code with test harness that injects test data and captures output.

        Args:
            code: The generated Python code
            test_input: Test data to pass to main()

        Returns:
            Complete test script as string
        """
        import json
        test_input_json = json.dumps(test_input) if test_input is not None else "None"

        test_harness = f'''
# Test harness - injected by CodeValidator
import json
import asyncio

# Test input
_TEST_INPUT = {test_input_json}

{code}

# Run the test
if __name__ == "__main__":
    try:
        # Try to call main() with test input
        if asyncio.iscoroutinefunction(main):
            if _TEST_INPUT is not None:
                result = asyncio.run(main(_TEST_INPUT))
            else:
                result = asyncio.run(main())
        else:
            if _TEST_INPUT is not None:
                result = main(_TEST_INPUT)
            else:
                result = main()

        # Output result as JSON
        if result is not None:
            if hasattr(result, 'model_dump'):
                print("__RESULT__:" + json.dumps(result.model_dump()))
            elif hasattr(result, '__dict__'):
                print("__RESULT__:" + json.dumps(result.__dict__))
            else:
                print("__RESULT__:" + json.dumps(result))
        else:
            print("__RESULT__:null")
        print("__SUCCESS__")
    except Exception as e:
        print(f"__ERROR__:{{type(e).__name__}}: {{str(e)}}")
'''
        return test_harness

    def _validate_syntax(self, code: str) -> tuple[bool, Optional[str]]:
        """Validate Python syntax. Returns (is_valid, error_message)."""
        try:
            ast.parse(code)
            return True, None
        except SyntaxError as e:
            return False, f"Line {e.lineno}: {e.msg}"

    async def validate(
        self,
        code: str,
        test_input: Any = None
    ) -> Dict[str, Any]:
        """
        Execute code with test data and validate output.

        Args:
            code: Python code to validate
            test_input: Test data to pass to main()

        Returns:
            Dict with success, output, error fields
        """
        # 1. Syntax check
        syntax_valid, syntax_error = self._validate_syntax(code)
        if not syntax_valid:
            return {
                "success": False,
                "syntax_valid": False,
                "output": None,
                "error": f"Syntax error: {syntax_error}"
            }

        # 2. Create test script
        test_script = self._create_test_script(code, test_input)

        # 3. Write to temp file and execute
        with tempfile.NamedTemporaryFile(
            mode='w',
            suffix='.py',
            delete=False
        ) as f:
            f.write(test_script)
            script_path = f.name

        try:
            # Load env and merge with current environment
            env = {**os.environ, **self._load_env()}

            # Execute in subprocess
            proc = await asyncio.create_subprocess_exec(
                sys.executable, script_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(),
                    timeout=self.timeout
                )
            except asyncio.TimeoutError:
                proc.kill()
                return {
                    "success": False,
                    "syntax_valid": True,
                    "output": None,
                    "error": f"Execution timed out after {self.timeout}s"
                }

            stdout_str = stdout.decode()
            stderr_str = stderr.decode()

            # Parse output
            if "__SUCCESS__" in stdout_str:
                # Extract result
                output = None
                for line in stdout_str.split('\n'):
                    if line.startswith("__RESULT__:"):
                        try:
                            import json
                            output = json.loads(line[11:])
                        except:
                            output = line[11:]
                        break

                return {
                    "success": True,
                    "syntax_valid": True,
                    "output": output,
                    "error": None
                }
            elif "__ERROR__:" in stdout_str:
                # Extract error
                error = None
                for line in stdout_str.split('\n'):
                    if line.startswith("__ERROR__:"):
                        error = line[10:]
                        break

                return {
                    "success": False,
                    "syntax_valid": True,
                    "output": None,
                    "error": error or "Unknown execution error"
                }
            else:
                # Unexpected output
                return {
                    "success": False,
                    "syntax_valid": True,
                    "output": None,
                    "error": f"Execution failed: {stderr_str or stdout_str or 'No output'}"
                }

        finally:
            # Clean up temp file
            try:
                os.unlink(script_path)
            except:
                pass


class CodeGeneratorAgent:
    """
    Agent that generates Python code from workflow descriptions.

    Takes a workflow/strategy description and generates executable Python code
    that implements the described logic using Penguin library components.

    Example:
        ```python
        from penguin.llm import create_client
        from penguin.agents import CodeGeneratorAgent

        client = create_client("bedrock", model="claude-sonnet-4-5")
        coder = CodeGeneratorAgent(client)

        code = await coder.generate(
            task="Extract diagnosis codes from medical PDFs",
            workflow="1. OCR the PDF 2. Use LLM to extract ICD-10 codes"
        )
        print(code)
        ```
    """

    def __init__(
        self,
        llm_provider: BaseChatCompletionClient,
        verbose: bool = True,
        env_file_path: Optional[Path] = None,
        validation_timeout: int = 60
    ):
        """
        Initialize the code generator agent.

        Args:
            llm_provider: LLM client for code generation
            verbose: Whether to print progress (default: True)
            env_file_path: Path to .env file for validation (default: .env)
            validation_timeout: Timeout for code validation in seconds (default: 60)
        """
        self.llm = llm_provider
        self.verbose = verbose
        self.validator = CodeValidator(
            env_file_path=env_file_path,
            timeout_seconds=validation_timeout
        )

    def _get_library_docs(self) -> str:
        """Returns documentation for Penguin library APIs."""
        return """
===============================================================================
PENGUIN AI LIBRARY - COMPLETE API REFERENCE
===============================================================================

CRITICAL: Use ONLY Penguin library for all AI/LLM operations.
DO NOT use: requests, urllib, openai, anthropic, boto3 directly.

Load the env variables always with load_env()

===============================================================================
1. LLM MODULE - Core Text Generation API
===============================================================================
Import: from penguin.llm import create_client, UserMessage, SystemMessage, AssistantMessage, ToolMessage

CREATING CLIENTS
----------------
# Supported providers: "bedrock", "gemini", "openai", "azure_openai"
client = create_client("bedrock", model="claude-sonnet-4-5")
client = create_client("gemini", model="gemini-2.5-pro")
client = create_client("azure_openai", model="gpt-4o")


# With tracing enabled
client = create_client("bedrock", model="claude-sonnet-4-5", enable_tracing=True)

AVAILABLE MODELS (use exact model IDs)
--------------------------------------
Bedrock: "claude-sonnet-4-5", "claude-sonnet-4", "claude-3-5-sonnet"
Gemini:  "gemini-3-pro-preview", "gemini-3-flash-preview", "gemini-2.5-pro"
OpenAI:  "gpt-4o"

BASIC GENERATION
----------------
# Simple text generation
result = await client.create([UserMessage("Your prompt here")])
text = result.content  # str

# With system message
result = await client.create([
    SystemMessage("You are a helpful assistant"),
    UserMessage("Your prompt")
])

STRUCTURED OUTPUT (Pydantic or JSON Schema)
-------------------------------------------
from pydantic import BaseModel
from typing import List, Optional

class DiagnosisResult(BaseModel):
    diagnosis: str
    icd_codes: List[str]
    confidence: float
    notes: Optional[str] = None

result = await client.create(
    [UserMessage("Analyze this patient case...")],
    output_format=DiagnosisResult
)
data = result.content  # dict matching the schema
# Access: data["diagnosis"], data["icd_codes"], etc.

EXTENDED THINKING (Complex Reasoning)
-------------------------------------
# For tasks requiring step-by-step reasoning
result = await client.create(
    [UserMessage("Solve this complex problem...")],
    thinking=True,
    max_thinking_tokens=5000  # Optional limit, use this as per the requirement
)
print(result.thinking)  # The reasoning chain
print(result.content)   # The final answer

STREAMING RESPONSES
-------------------
async for chunk in await client.create_stream([UserMessage("Tell me a story")]):
    print(chunk.delta_content, end="")  # Print as it arrives

RESPONSE OBJECT (ChatCompletionResult)
--------------------------------------
result.content        # str or dict (if structured output)
result.thinking       # str or None (if thinking=True)
result.tool_calls     # List[ToolCall] or None
result.finish_reason  # "stop", "tool_calls", "length"
result.usage.prompt_tokens
result.usage.completion_tokens
result.usage.total_tokens

# Convert result to message for multi-turn
assistant_msg = result.to_assistant_message()

MESSAGE TYPES FOR MULTI-TURN WITH TOOLS
---------------------------------------
from penguin.llm import UserMessage, SystemMessage, AssistantMessage, ToolMessage, ToolCall

# Build conversation with tool calls
messages = [
    SystemMessage("You are helpful."),
    UserMessage("Calculate BMI for 70kg, 1.75m"),
    AssistantMessage(content="", tool_calls=[
        ToolCall(name="calculate_bmi", arguments={"weight": 70, "height": 1.75})
    ]),
    ToolMessage(tool_call_id="call_123", tool_name="calculate_bmi", content="22.86")
]

MODEL REGISTRY
--------------
from penguin.llm import list_models, get_model, get_vision_models, get_thinking_models

all_models = list_models()                    # All available models
bedrock_models = list_models("bedrock")       # Provider-specific
model_info = get_model("claude-sonnet-4-5")   # Model capabilities
vision_models = get_vision_models()           # Models with vision support
thinking_models = get_thinking_models()       # Models with extended thinking

===============================================================================
2. TOOLS MODULE - Custom Function Calling
===============================================================================
Import: from penguin.tools import tool, ToolExecutor, ToolRegistry, FunctionTool

DEFINING TOOLS WITH @tool DECORATOR
------------------------------------
@tool
def calculate_bmi(weight_kg: float, height_m: float) -> float:
    \"\"\"Calculate BMI from weight and height.

    Args:
        weight_kg: Weight in kilograms
        height_m: Height in meters

    Returns:
        BMI value as float
    \"\"\"
    return weight_kg / (height_m ** 2)

@tool
async def fetch_patient_data(patient_id: str) -> dict:
    \"\"\"Fetch patient data from database.\"\"\"
    # Async tools are supported
    return {"id": patient_id, "name": "John Doe"}

TOOL EXECUTOR (In-Memory)
-------------------------
from penguin.tools import ToolExecutor

# Create executor with tools
executor = ToolExecutor([calculate_bmi, fetch_patient_data])

# Or register later
executor = ToolExecutor()
executor.register(calculate_bmi)

# List tools
executor.list_names()  # ["calculate_bmi", "fetch_patient_data"]
executor.list_tools()  # List of tool objects

# NOTE: When using Agent or chat_with_tools, just pass the executor directly.
# The library handles provider format conversion internally.
# You do NOT need to call to_provider_format() manually.

TOOL REGISTRY (Persistent Storage)
----------------------------------
from penguin.tools import ToolRegistry

# Registry persists tools to ~/.penguin/tools/
registry = ToolRegistry()
registry.add(calculate_bmi)

# Create tool from code string (fully persistent)
registry.create_from_code(
    name="extract_codes",
    description="Extract medical codes from text",
    code='''
def extract_codes(text: str) -> list:
    import re
    return re.findall(r"[A-Z]\\d{2}\\.\\d+", text)
    '''
)

# Get executor from registry
executor = registry.get_executor()

===============================================================================
3. AGENTS MODULE - Agentic Loops with Tools
===============================================================================
Import: from penguin.agents import Agent, chat_with_tools, AgentResponse

OPTION 1: AGENT CLASS (Reusable, Recommended)
---------------------------------------------
from penguin.agents import Agent
from penguin.llm import create_client
from penguin.tools import tool

@tool
def get_weather(city: str) -> str:
    \"\"\"Get current weather for a city.\"\"\"
    return f"Weather in {city}: Sunny, 72°F"

@tool
def calculate_bmi(weight_kg: float, height_m: float) -> float:
    \"\"\"Calculate BMI.\"\"\"
    return weight_kg / (height_m ** 2)

# Create reusable agent
client = create_client("bedrock", model="claude-sonnet-4-5")
agent = Agent(
    client=client,
    tools=[get_weather, calculate_bmi],
    system_prompt="You are a helpful assistant.",
    max_iterations=10,    # Max tool call rounds
    max_tokens=4096,      # Response limit
    temperature=0.7       # Creativity
)

# Run the agent
result = await agent.run("What's the weather in NYC?", verbose=True)
print(result.answer)

# Add tools dynamically
@tool
def search_database(query: str) -> str:
    return "Results..."

agent.add_tool(search_database)

# Check available tools
print(agent.tools)  # ["get_weather", "calculate_bmi", "search_database"]

OPTION 2: CHAT_WITH_TOOLS FUNCTION (One-off Usage)
--------------------------------------------------
from penguin.agents import chat_with_tools

result = await chat_with_tools(
    prompt="Calculate BMI for a 70kg person who is 1.75m tall",
    client=client,
    executor=executor,  # ToolExecutor instance
    system_prompt="You are a medical assistant.",
    max_iterations=10,
    max_tokens=4096,
    temperature=0.7,
    verbose=True
)

AGENTRESPONSE OBJECT
--------------------
result.answer       # str - Final text answer
result.tool_calls   # List[ToolCall] - All tool calls made
result.iterations   # int - Number of LLM rounds
result.total_tokens # int - Total token usage

===============================================================================
4. CHAT SESSION - Multi-Turn Conversations and persistance
===============================================================================
Import: from penguin.llm import ChatSession, create_client

BASIC MULTI-TURN
----------------
client = create_client("bedrock", model="claude-sonnet-4-5")
session = ChatSession(client, system_instruction="You are a medical coding expert.")

# Conversation with automatic history management
response1 = await session.send("What is the ICD-10 code for Type 2 diabetes?")
print(response1.content)

response2 = await session.send("What about with complications?")  # Remembers context
print(response2.content)

# With structured output
response = await session.send("Extract all codes mentioned", output_format=CodeList)

# With extended thinking
response = await session.send("Analyze this complex case...", thinking=True)

# Session management
print(session.message_count)   # Number of messages
history = session.get_history() # List of message dicts
session.clear_history()        # Start fresh

PERSISTING SESSIONS
-------------------
from penguin.llm import ConversationRegistry, list_sessions, get_session

# Option 1: Using registry
registry = ConversationRegistry(backend="file")  # Stores in ~/.penguin/conversations/
registry.save(session)
restored = registry.load(session.session_id, client)

# Option 2: Convenience functions
from penguin.llm import list_sessions, get_session, delete_session

sessions = list_sessions()  # List all saved sessions
session = get_session("session_id_here", client)  # Load by ID
delete_session("session_id_here")  # Delete

===============================================================================
5. COMPLIANCE MODULE - Rule-Based Evaluation
===============================================================================
Import: from penguin.compliance import ComplianceRunner

runner = ComplianceRunner(client, max_concurrency=5)

report = await runner.evaluate(
    df=dataframe,  # DataFrame with 'input' and 'output' columns
    rules=[
        "All outputs must include ICD-10 codes",
        "Dates must be in YYYY-MM-DD format",
        "Patient names must be redacted"
    ],
    task_name="Medical Coding Compliance"
)

# Report fields
print(report.overall_pass_rate)  # 0.0 to 1.0
print(report.trace_id)           # For debugging
for rule_summary in report.rule_summaries:
    print(f"{rule_summary.rule}: {rule_summary.pass_rate}")

===============================================================================
6. EVALS MODULE - Criteria-Based Quality Evaluation
===============================================================================
Import: from penguin.evals import EvalRunner

runner = EvalRunner(client, max_concurrency=5)

report = await runner.evaluate(
    df=dataframe,  # DataFrame with 'input' and 'output' columns
    criteria=[
        "Accuracy: Output matches expected medical codes",
        "Completeness: All relevant codes are captured",
        "Clinical validity: Codes are clinically appropriate"
    ],
    task_name="Output Quality Evaluation"
)

print(report.overall_pass_rate)
for criteria_summary in report.criteria_summaries:
    print(f"{criteria_summary.criteria}: {criteria_summary.pass_rate}")

===============================================================================
7. EMBEDDINGS MODULE - Text Embeddings
===============================================================================
Import: from penguin.embeddings import create_embedding_client

# Create embedding client
embedder = create_embedding_client("bedrock")  # Uses Titan embeddings

# Single text embedding
result = await embedder.embed("This is a clinical note about diabetes.")
vector = result.embedding  # List[float]
print(result.dimensions)   # 1024 or similar

# Batch embedding
results = await embedder.embed_batch([
    "Patient has Type 2 diabetes",
    "Hypertension noted in records",
    "Normal blood glucose levels"
])
vectors = [r.embedding for r in results]

===============================================================================
8. VECTOR_DB MODULE - Vector Search
===============================================================================
Import: from penguin.vector_db import create_vector_client

# Create vector database client (S3 Vectors)
vector_db = create_vector_client("s3_vectors", bucket_name="my-vectors-bucket")

# Create an index
await vector_db.create_index("medical_codes", dimension=1024)

# Store vectors with metadata
from penguin.vector_db import VectorRecord
records = [
    VectorRecord(id="E11.9", vector=embedding1, metadata={"description": "Type 2 diabetes"}),
    VectorRecord(id="I10", vector=embedding2, metadata={"description": "Hypertension"})
]
await vector_db.put_vectors("medical_codes", records)

# Query for similar vectors
results = await vector_db.query_vectors(
    index_name="medical_codes",
    query_vector=query_embedding,
    top_k=5
)
for match in results.matches:
    print(f"{match.id}: {match.score}")

===============================================================================
9. DATA ASSETS MODULE - Reference Datasets
===============================================================================
Import: from penguin.data_assets import load_asset, list_assets

# List available data assets
assets = list_assets()
for asset in assets:
    print(f"{asset['name']}: {asset['description']}")

# Load a data asset
icd10_df = load_asset("icd10")  # Returns pandas DataFrame
print(icd10_df.head())

===============================================================================
10. BLUEPRINTS MODULE - Reusable Workflow Patterns
===============================================================================
Import: from penguin.blueprints import Blueprint, BlueprintRegistry

# Define a blueprint
blueprint = Blueprint(
    name="hcc_extraction",
    description="Extract HCC codes from clinical notes",
    workflow="Step 1: OCR the document\\nStep 2: Extract codes...",
    code="async def process(text): ...",
    tags=["medical", "coding", "hcc"]
)

# Use registry
registry = BlueprintRegistry()
registry.add_blueprint(blueprint)

# Search blueprints
results = registry.search_blueprints("medical coding")
results = registry.search_by_tags(["medical", "coding"])

# Semantic search (LLM-based)
relevant = await registry.find_relevant_blueprint("I need to extract diagnosis codes")

===============================================================================
11. OBSERVABILITY MODULE - Tracing & Debugging
===============================================================================
Import: from penguin.observability import setup_tracing, observe, get_current_trace_id

ENABLE TRACING
--------------
# Option 1: Environment variable
# export PENGUIN_ENABLE_TRACING=true

# Option 2: When creating client
client = create_client("bedrock", enable_tracing=True)

# Option 3: Explicit setup
from penguin.observability import setup_tracing
setup_tracing()  # Traces written to penguin_traces.jsonl

TRACE CUSTOM FUNCTIONS
----------------------
@observe(type="tool")
def extract_codes(text: str) -> list:
    \"\"\"Extract medical codes.\"\"\"
    return ["E11.9", "I10"]

@observe(type="chain", name="process_pipeline")
async def process_document(doc: str) -> dict:
    \"\"\"Full processing pipeline.\"\"\"
    result = await client.create([UserMessage(doc)])
    return {"output": result.content}

# Trace types: "llm", "tool", "chain", "ocr", "vlm"

# Access current trace ID
trace_id = get_current_trace_id()

===============================================================================
12. OCR MODULE - Document Text Extraction
===============================================================================
Import: from penguin.ocr import AzureOCRProvider, AWSTextractProvider

# Azure Document Intelligence
ocr = AzureOCRProvider()
result = await ocr.extract_text(image_bytes)
text = result.text
lines = result.lines  # List of OCRLine with bounding boxes

# AWS Textract
ocr = AWSTextractProvider()
result = await ocr.extract_text(image_bytes)

===============================================================================
13. REDACTION MODULE - PII Detection & Masking
===============================================================================
Import: from penguin.redaction import PenguinPIIRedactor

redactor = PenguinPIIRedactor()

# Simple redaction
redacted_text = redactor.redact("John Smith was born on 01/15/1980")
# Output: "[PERSON] was born on [DATE]"

# Detailed results
result = redactor.redact_with_details(text)
print(result.redacted_text)
for entity in result.entities:
    print(f"{entity.type}: {entity.original} -> {entity.replacement}")

===============================================================================
CODE GENERATION RULES - MUST FOLLOW
===============================================================================

1. ENVIRONMENT VARIABLES: ALWAYS load at the start
   from dotenv import load_dotenv
   load_dotenv()  # Call BEFORE any other code

2. ASYNC/AWAIT: All LLM calls are async
   - Use `async def` for any function calling LLM
   - Use `await` for every LLM call

3. ERROR HANDLING: Always wrap LLM calls
   try:
       result = await client.create(messages)
   except Exception as e:
       logger.error(f"LLM call failed: {e}")
       raise

4. STRUCTURED OUTPUT: When using Pydantic models
   - result.content is a dict, not the model instance
   - Access fields: result.content["field_name"]

5. JSON PARSING: Use json_repair for LLM-generated JSON
   import json_repair
   data = json_repair.loads(result.content)  # Handles malformed JSON

6. ENTRY POINT: Always include runnable main
   from dotenv import load_dotenv
   load_dotenv()

   async def main():
       # Your code here
       pass

   if __name__ == "__main__":
       import asyncio
       asyncio.run(main())

7. IMPORTS: Group at top of file
   - Standard library
   - Third-party (pydantic, json_repair, dotenv)
   - Penguin imports

8. TYPE HINTS: Use throughout for clarity
   from typing import List, Dict, Optional, Any
"""

    def _extract_code(self, response: str) -> str:
        """Extract Python code from LLM response."""
        # Try to find code in markdown code blocks
        patterns = [
            r'```python\n(.*?)```',
            r'```py\n(.*?)```',
            r'```\n(.*?)```',
        ]

        for pattern in patterns:
            matches = re.findall(pattern, response, re.DOTALL)
            if matches:
                # Return the longest match (most complete code)
                return max(matches, key=len).strip()

        # If no code blocks, try to find code-like content
        lines = response.split('\n')
        code_lines = []
        in_code = False

        for line in lines:
            # Detect start of code
            if line.strip().startswith(('import ', 'from ', 'def ', 'async def ', 'class ')):
                in_code = True

            if in_code:
                code_lines.append(line)

        if code_lines:
            return '\n'.join(code_lines).strip()

        # Fallback: return the whole response
        return response.strip()

    def _validate_syntax(self, code: str) -> tuple[bool, Optional[str]]:
        """Validate Python syntax. Returns (is_valid, error_message)."""
        try:
            ast.parse(code)
            return True, None
        except SyntaxError as e:
            return False, f"Line {e.lineno}: {e.msg}"

    async def generate(
        self,
        task: str,
        workflow: str,
        additional_context: str = "",
        implementation_hints: Optional[List[str]] = None,
        test_input: Any = None,
        max_retries: int = 3
    ) -> Dict[str, Any]:
        """
        Generate Python code from a workflow description.

        Args:
            task: Description of the task to accomplish
            workflow: Step-by-step workflow/strategy to implement
            additional_context: Optional extra context (e.g., sample data format)
            implementation_hints: List of implementation hints from workflow agent
            test_input: Optional test data to validate generated code
            max_retries: Number of retries if code has syntax errors (default: 3)

        Returns:
            Dict with:
                - code: The generated Python code
                - valid: Whether the code has valid syntax
                - error: Syntax error message if invalid
                - trace_id: Trace ID for observability
                - test_output: Output from test execution (if test_input provided)
        """
        # Wrap in parent span if tracing is enabled
        tracer = _get_tracer() if is_tracing_enabled() else None

        if tracer:
            # Use start_as_current_span to create parent span
            # All LLM calls inside will become children of this span
            with tracer.start_as_current_span("code_generation") as span:
                span.set_attribute("penguin.coder.task", task[:200])  # Truncate task
                span.set_attribute("penguin.coder.max_retries", max_retries)
                span.set_attribute("penguin.coder.has_test_input", test_input is not None)

                if test_input is not None:
                    result = await self._generate_with_test(
                        task, workflow, additional_context,
                        implementation_hints, test_input, max_retries
                    )
                else:
                    result = await self._generate_internal(
                        task, workflow, additional_context,
                        implementation_hints, max_retries
                    )

                # Get trace_id from the parent span
                span_context = span.get_span_context()
                if span_context.is_valid:
                    result["trace_id"] = format(span_context.trace_id, '032x')

                return result
        else:
            if test_input is not None:
                return await self._generate_with_test(
                    task, workflow, additional_context,
                    implementation_hints, test_input, max_retries
                )
            else:
                return await self._generate_internal(
                    task, workflow, additional_context,
                    implementation_hints, max_retries
                )

    async def _generate_internal(
        self,
        task: str,
        workflow: str,
        additional_context: str,
        implementation_hints: Optional[List[str]],
        max_retries: int
    ) -> Dict[str, Any]:
        """Internal generate implementation (may be wrapped in span)."""
        if self.verbose:
            print(f"[CODE] Generating code for: {task[:50]}...")

        # Format implementation hints
        hints_str = "None provided"
        if implementation_hints:
            hints_str = "\n".join(f"- {hint}" for hint in implementation_hints)
            if self.verbose:
                print(f"[CODE] Using {len(implementation_hints)} implementation hints")

        # Use new structured prompt templates
        user_prompt = CODE_GENERATION_USER_PROMPT.format(
            library_docs=self._get_library_docs(),
            task=task,
            workflow=workflow,
            implementation_hints=hints_str,
            additional_context=additional_context if additional_context else "None"
        )

        code = None
        error = None

        for attempt in range(max_retries + 1):
            if attempt > 0 and self.verbose:
                print(f"[CODE] Retry {attempt}/{max_retries} - fixing syntax errors...")

            if attempt == 0:
                # First attempt - use new system prompt
                result = await self.llm.create([
                    SystemMessage(CODE_GENERATION_SYSTEM_PROMPT),
                    UserMessage(user_prompt)
                ], thinking=True, max_tokens=30000)
            else:
                # Retry with error feedback using CODE_FIX_PROMPT
                fix_prompt = CODE_FIX_PROMPT.format(
                    error_message=error,
                    test_input="N/A (syntax error)",
                    original_code=code
                )
                result = await self.llm.create([
                    SystemMessage(CODE_GENERATION_SYSTEM_PROMPT),
                    UserMessage(fix_prompt)
                ], max_tokens=30000)

            code = self._extract_code(result.content)
            is_valid, error = self._validate_syntax(code)

            if is_valid:
                # Prefer client.last_trace_id, fallback to context
                trace_id = getattr(self.llm, 'last_trace_id', None) or get_current_trace_id()
                if self.verbose:
                    print(f"[CODE] Generated {len(code.splitlines())} lines of valid Python code")
                    if trace_id:
                        print(f"[TRACE] {trace_id}")
                return {
                    "code": code,
                    "valid": True,
                    "error": None,
                    "trace_id": trace_id
                }

        # All retries exhausted
        trace_id = getattr(self.llm, 'last_trace_id', None) or get_current_trace_id()
        if self.verbose:
            print(f"[CODE] Warning: Generated code has syntax errors: {error}")
            if trace_id:
                print(f"[TRACE] {trace_id}")

        return {
            "code": code,
            "valid": False,
            "error": error,
            "trace_id": trace_id
        }

    async def _generate_with_test(
        self,
        task: str,
        workflow: str,
        additional_context: str,
        implementation_hints: Optional[List[str]],
        test_input: Any,
        max_retries: int
    ) -> Dict[str, Any]:
        """
        Generate code with test execution validation.

        Generate -> Test -> Fix loop until success or max iterations.

        Args:
            task: Task description
            workflow: Workflow to implement
            additional_context: Extra context
            implementation_hints: Implementation hints
            test_input: Test data for validation
            max_retries: Max fix iterations

        Returns:
            Dict with code, valid, error, test_output fields
        """
        if self.verbose:
            print(f"[CODE] Generating code with test validation...")

        code = None
        error_message = None
        import json as json_module

        for iteration in range(max_retries + 1):
            if iteration == 0:
                # Initial generation
                result = await self._generate_internal(
                    task, workflow, additional_context,
                    implementation_hints, max_retries=0  # No internal retries
                )
                code = result.get("code")
                if not result.get("valid"):
                    error_message = result.get("error")
                    if self.verbose:
                        print(f"[CODE] Generation failed with syntax error: {error_message}")
                    continue
            else:
                # Fix based on execution error
                if self.verbose:
                    print(f"[CODE] Fix attempt {iteration}/{max_retries}...")

                fix_prompt = CODE_FIX_PROMPT.format(
                    error_message=error_message,
                    test_input=json_module.dumps(test_input)[:1000] if test_input else "None",
                    original_code=code
                )
                result = await self.llm.create([
                    SystemMessage(CODE_GENERATION_SYSTEM_PROMPT),
                    UserMessage(fix_prompt)
                ], max_tokens=30000)

                code = self._extract_code(result.content)

                # Check syntax
                is_valid, syntax_error = self._validate_syntax(code)
                if not is_valid:
                    error_message = f"Syntax error: {syntax_error}"
                    if self.verbose:
                        print(f"[CODE] Fix produced syntax error: {syntax_error}")
                    continue

            # Validate by executing with test data
            if self.verbose:
                print(f"[CODE] Running test validation...")

            validation_result = await self.validator.validate(code, test_input)

            if validation_result.get("success"):
                trace_id = getattr(self.llm, 'last_trace_id', None) or get_current_trace_id()
                if self.verbose:
                    print(f"[CODE] Test validation passed!")
                    print(f"[CODE] Generated {len(code.splitlines())} lines of working code")
                    if trace_id:
                        print(f"[TRACE] {trace_id}")

                return {
                    "code": code,
                    "valid": True,
                    "error": None,
                    "test_output": validation_result.get("output"),
                    "trace_id": trace_id
                }
            else:
                error_message = validation_result.get("error", "Unknown error")
                if self.verbose:
                    print(f"[CODE] Test validation failed: {error_message}")

        # All iterations exhausted
        trace_id = getattr(self.llm, 'last_trace_id', None) or get_current_trace_id()
        if self.verbose:
            print(f"[CODE] Warning: Could not generate working code after {max_retries + 1} attempts")
            print(f"[CODE] Last error: {error_message}")
            if trace_id:
                print(f"[TRACE] {trace_id}")

        return {
            "code": code,
            "valid": False,
            "error": error_message,
            "test_output": None,
            "trace_id": trace_id
        }

    async def generate_from_workflow_result(
        self,
        workflow_result: Dict[str, Any],
        task: str,
        test_input: Any = None,
        max_retries: int = 2
    ) -> Dict[str, Any]:
        """
        Generate code directly from WorkflowSuggestionAgent output.

        This method extracts implementation hints, tools, and assets from
        the workflow result and uses them to generate better code.

        Args:
            workflow_result: Output from WorkflowSuggestionAgent.run()
                Expected fields:
                - generalized_workflow: The workflow to implement
                - implementation_hints: List of hints for code generation
                - tools_to_use: List of tool names to use
                - assets_to_use: List of data asset names
                - blueprint_relevance: Analysis of blueprint applicability
            task: The original task description
            test_input: Optional test data for validation
            max_retries: Maximum retry attempts if test validation fails

        Returns:
            Dict with code, valid, error, test_output, and trace_id fields
        """
        workflow = workflow_result.get("generalized_workflow", "")

        # Extract implementation hints from workflow result
        implementation_hints = workflow_result.get("implementation_hints", [])

        # Build additional context from workflow result
        additional_context_parts = []

        if workflow_result.get("tools_to_use"):
            additional_context_parts.append(
                f"Tools to use: {', '.join(workflow_result['tools_to_use'])}"
            )

        if workflow_result.get("assets_to_use"):
            additional_context_parts.append(
                f"Data assets: {', '.join(workflow_result['assets_to_use'])}"
            )

        # Include blueprint relevance info if available
        blueprint_relevance = workflow_result.get("blueprint_relevance")
        if blueprint_relevance:
            # Add applicable patterns as context
            applicable = blueprint_relevance.get("applicable_patterns", [])
            if applicable:
                patterns_text = "\n".join(
                    f"  - {p.get('step', 'N/A')}: {p.get('adaptation') or 'Use as-is'}"
                    for p in applicable
                )
                additional_context_parts.append(
                    f"Applicable patterns from reference blueprint:\n{patterns_text}"
                )

            # Add new patterns needed
            new_patterns = blueprint_relevance.get("new_patterns_needed", [])
            if new_patterns:
                new_text = "\n".join(
                    f"  - {p.get('pattern', 'N/A')}: {p.get('description', '')}"
                    for p in new_patterns
                )
                additional_context_parts.append(
                    f"New patterns to implement:\n{new_text}"
                )

        additional_context = "\n\n".join(additional_context_parts)

        return await self.generate(
            task=task,
            workflow=workflow,
            additional_context=additional_context,
            implementation_hints=implementation_hints,
            test_input=test_input,
            max_retries=max_retries
        )


# Backwards compatibility alias
PenguinCoderAgent = CodeGeneratorAgent
# END OF FILE: penguin/agents/coder.py ---
