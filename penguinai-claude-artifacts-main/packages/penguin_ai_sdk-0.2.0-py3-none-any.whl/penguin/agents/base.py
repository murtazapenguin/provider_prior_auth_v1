"""
Penguin Agent Module

Provides agentic loop functionality - binding LLM calls with tool execution.
Supports agent-level middleware for business rules and guardrails.
Supports checkpointing for crash recovery in long-running workflows.
"""

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, TYPE_CHECKING, Union

from penguin.llm import UserMessage, AssistantMessage, ToolMessage
from penguin.llm.base import BaseChatCompletionClient
from penguin.tools import ToolExecutor

# Tracing support
from penguin.observability.config import is_tracing_enabled, should_capture_content, get_tracer
from penguin.observability.attributes import GenAIAttributes, GenAISpanKind

# Middleware support - import lazily to avoid circular imports
if TYPE_CHECKING:
    from penguin.middleware import MiddlewareChain, MiddlewareContext, BaseMiddleware
    from penguin.agents.checkpoint import CheckpointManager, CheckpointSummary

logger = logging.getLogger(__name__)


@dataclass
class AgentResponse:
    """Response from an agent run."""
    answer: str
    tool_calls: List[Dict[str, Any]] = field(default_factory=list)
    iterations: int = 0
    total_tokens: int = 0


async def chat_with_tools(
    prompt: str,
    client: BaseChatCompletionClient,
    executor: ToolExecutor,
    system_prompt: Optional[str] = None,
    max_iterations: int = 10,
    max_tokens: int = 4096,
    temperature: float = 0.7,
    verbose: bool = False,
    middleware: Optional["MiddlewareChain"] = None,
    checkpoint_manager: Optional["CheckpointManager"] = None,
    resume_from: Optional[str] = None,
) -> AgentResponse:
    """
    Execute an agentic loop: LLM decides when to use tools, executes them,
    and provides a final answer.

    Args:
        prompt: User's question/request
        client: LLM client (from create_client)
        executor: ToolExecutor with registered tools
        system_prompt: Optional system prompt
        max_iterations: Maximum tool-call rounds before giving up
        max_tokens: Max tokens per LLM call
        temperature: LLM temperature
        verbose: Print debug information
        middleware: Optional agent-level middleware chain for business rules
        checkpoint_manager: Optional manager for state persistence and crash recovery
        resume_from: Optional agent_run_id to resume from a previous checkpoint

    Returns:
        AgentResponse with final answer and tool call log

    Example:
        from penguin.llm import create_client
        from penguin.tools import tool, ToolExecutor
        from penguin.agents import chat_with_tools

        @tool
        def get_weather(city: str) -> str:
            return f"Weather in {city}: Sunny"

        client = create_client("bedrock", model="claude-sonnet-4-5")
        executor = ToolExecutor([get_weather])

        result = await chat_with_tools(
            "What's the weather in NYC?",
            client,
            executor
        )
        print(result.answer)

    Example with middleware:
        from penguin.middleware import GuardrailMiddleware

        result = await chat_with_tools(
            "Process claim CLM-123",
            client,
            executor,
            middleware=MiddlewareChain().add(GuardrailMiddleware(max_input_length=5000))
        )

    Example with checkpointing:
        from penguin.agents import CheckpointManager

        manager = CheckpointManager()
        result = await chat_with_tools(
            "Complex multi-step task",
            client,
            executor,
            checkpoint_manager=manager
        )

        # Later, resume if crashed:
        result = await chat_with_tools(
            "",  # Prompt ignored on resume
            client,
            executor,
            checkpoint_manager=manager,
            resume_from="previous-run-id"
        )
    """
    # Execute with tracing if enabled
    if is_tracing_enabled():
        return await _chat_with_tools_traced(
            prompt, client, executor, system_prompt,
            max_iterations, max_tokens, temperature, verbose, middleware,
            checkpoint_manager, resume_from
        )
    else:
        return await _chat_with_tools_impl(
            prompt, client, executor, system_prompt,
            max_iterations, max_tokens, temperature, verbose, middleware,
            checkpoint_manager, resume_from
        )


async def _chat_with_tools_traced(
    prompt: str,
    client: BaseChatCompletionClient,
    executor: ToolExecutor,
    system_prompt: Optional[str],
    max_iterations: int,
    max_tokens: int,
    temperature: float,
    verbose: bool,
    middleware: Optional["MiddlewareChain"] = None,
    checkpoint_manager: Optional["CheckpointManager"] = None,
    resume_from: Optional[str] = None,
) -> AgentResponse:
    """Execute chat_with_tools with OpenTelemetry tracing."""
    tracer = get_tracer("penguin.agent")

    with tracer.start_as_current_span("agent.run") as span:
        # Set agent attributes
        span.set_attribute(GenAIAttributes.SPAN_TYPE, "agent")
        span.set_attribute(GenAIAttributes.REQUEST_MODEL, client.model)
        span.set_attribute(GenAIAttributes.SYSTEM, client.provider_name)
        span.set_attribute("gen_ai.agent.max_iterations", max_iterations)
        span.set_attribute("gen_ai.agent.tools", executor.list_names())
        span.set_attribute("gen_ai.agent.has_middleware", middleware is not None and len(middleware) > 0)
        span.set_attribute("gen_ai.agent.checkpointing", checkpoint_manager is not None)
        span.set_attribute("gen_ai.agent.is_resume", resume_from is not None)

        # Capture prompt if enabled
        if should_capture_content():
            span.set_attribute(GenAIAttributes.PROMPT, prompt[:10000])
            if system_prompt:
                span.set_attribute("gen_ai.system_prompt", system_prompt[:5000])

        try:
            result = await _chat_with_tools_impl(
                prompt, client, executor, system_prompt,
                max_iterations, max_tokens, temperature, verbose, middleware,
                checkpoint_manager, resume_from
            )

            # Record completion attributes
            span.set_attribute("gen_ai.agent.iterations", result.iterations)
            span.set_attribute("gen_ai.agent.total_tokens", result.total_tokens)
            span.set_attribute("gen_ai.agent.tool_call_count", len(result.tool_calls))

            # Capture answer if enabled
            if should_capture_content() and result.answer:
                span.set_attribute(GenAIAttributes.COMPLETION, result.answer[:10000])

            return result

        except Exception as e:
            span.record_exception(e)
            raise


async def _chat_with_tools_impl(
    prompt: str,
    client: BaseChatCompletionClient,
    executor: ToolExecutor,
    system_prompt: Optional[str],
    max_iterations: int,
    max_tokens: int,
    temperature: float,
    verbose: bool,
    middleware: Optional["MiddlewareChain"] = None,
    checkpoint_manager: Optional["CheckpointManager"] = None,
    resume_from: Optional[str] = None,
) -> AgentResponse:
    """Core implementation of chat_with_tools (without tracing wrapper)."""
    # Convert tools to provider format
    tools = executor.to_provider_format(client.provider_name)

    # Initialize checkpoint tracking
    checkpoint = None
    start_iteration = 0

    # Handle resume from checkpoint
    if resume_from and checkpoint_manager:
        checkpoint = checkpoint_manager.load_for_resume(resume_from, executor)
        messages = checkpoint_manager.restore_messages(checkpoint)
        tool_calls_log = list(checkpoint.tool_calls_log)
        total_tokens = checkpoint.total_tokens
        start_iteration = checkpoint.iteration + 1
        max_iterations = checkpoint.max_iterations

        if verbose:
            logger.info(f"Resuming from checkpoint at iteration {start_iteration}")
    else:
        # Build initial messages for fresh start
        messages = []
        if system_prompt:
            from penguin.llm import SystemMessage
            messages.append(SystemMessage(system_prompt))
        messages.append(UserMessage(prompt))

        tool_calls_log = []
        total_tokens = 0

        # Create checkpoint if manager provided
        if checkpoint_manager:
            checkpoint = checkpoint_manager.create(
                prompt=prompt,
                client=client,
                executor=executor,
                system_prompt=system_prompt,
                max_iterations=max_iterations,
            )

    # Get tracer for LLM call spans (will be no-op if tracing disabled)
    tracer = get_tracer("penguin.llm")

    try:
        for iteration in range(start_iteration, max_iterations):
            if verbose:
                logger.info(f"Agent iteration {iteration + 1}")

            # Apply agent-level middleware pre-processing (if configured)
            current_messages = messages
            ctx = None
            if middleware and len(middleware) > 0:
                from penguin.middleware import MiddlewareContext
                ctx = MiddlewareContext(
                    operation="agent_iteration",
                    messages=list(messages),
                    client_name=client.provider_name,
                    agent_name="chat_with_tools",
                    iteration=iteration,
                    metadata={
                        "model": client.model,
                        "max_tokens": max_tokens,
                        "temperature": temperature,
                    }
                )
                ctx = await middleware.process_request(ctx)
                current_messages = ctx.messages

            # Call LLM with optional tracing
            with tracer.start_as_current_span(f"llm.create") as llm_span:
                llm_span.set_attribute(GenAIAttributes.SPAN_TYPE, GenAISpanKind.LLM)
                llm_span.set_attribute(GenAIAttributes.REQUEST_MODEL, client.model)
                llm_span.set_attribute(GenAIAttributes.SYSTEM, client.provider_name)
                llm_span.set_attribute(GenAIAttributes.REQUEST_MAX_TOKENS, max_tokens)
                llm_span.set_attribute(GenAIAttributes.REQUEST_TEMPERATURE, temperature)
                llm_span.set_attribute("gen_ai.agent.iteration", iteration + 1)

                result = await client.create(
                    current_messages,
                    tools=tools,
                    max_tokens=max_tokens,
                    temperature=temperature
                )

                # Record token usage
                if result.usage:
                    total_tokens += result.usage.total_tokens
                    llm_span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, result.usage.prompt_tokens)
                    llm_span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, result.usage.completion_tokens)
                    llm_span.set_attribute(GenAIAttributes.USAGE_TOTAL_TOKENS, result.usage.total_tokens)

                llm_span.set_attribute("gen_ai.response.finish_reason", result.finish_reason or "unknown")
                llm_span.set_attribute("gen_ai.response.tool_calls", len(result.tool_calls or []))

            # Apply agent-level middleware post-processing (if configured)
            if middleware and len(middleware) > 0 and ctx:
                result = await middleware.process_response(ctx, result)

            if verbose:
                logger.info(f"LLM response: content={result.content is not None}, "
                           f"tool_calls={len(result.tool_calls or [])}, "
                           f"finish_reason={result.finish_reason}")

            # Check if LLM wants to use tools
            if result.tool_calls:
                # Add assistant message with tool calls
                messages.append(AssistantMessage(
                    content=result.content or "",
                    tool_calls=result.tool_calls
                ))

                # Execute each tool call (tracing is handled in executor.execute())
                for tc in result.tool_calls:
                    if verbose:
                        logger.info(f"Executing tool: {tc.tool_name}({tc.parameters})")

                    tool_result = await executor.execute(tc)

                    if verbose:
                        logger.info(f"Tool result: {tool_result.content}")

                    tool_calls_log.append({
                        "tool": tc.tool_name,
                        "input": tc.parameters,
                        "output": tool_result.content,
                        "success": tool_result.success,
                        "error": tool_result.error
                    })

                    # Add tool result to messages
                    messages.append(ToolMessage(
                        tool_call_id=tc.call_id,
                        tool_name=tc.tool_name,
                        content=tool_result.to_message_content(),
                        is_error=not tool_result.success
                    ))

                # Save checkpoint after tool execution (before next iteration)
                if checkpoint_manager and checkpoint:
                    checkpoint_manager.update_iteration(
                        checkpoint, messages, tool_calls_log, iteration, total_tokens
                    )

                # Continue loop to get LLM's response to tool results
                continue

            else:
                # No tool calls - LLM has final answer
                response = AgentResponse(
                    answer=result.content or "",
                    tool_calls=tool_calls_log,
                    iterations=iteration + 1,
                    total_tokens=total_tokens
                )

                # Mark checkpoint as completed
                if checkpoint_manager and checkpoint:
                    checkpoint_manager.complete(checkpoint)

                return response

        # Max iterations reached
        logger.warning(f"Max iterations ({max_iterations}) reached without final answer")
        response = AgentResponse(
            answer="I wasn't able to complete the task within the allowed iterations.",
            tool_calls=tool_calls_log,
            iterations=max_iterations,
            total_tokens=total_tokens
        )

        # Mark checkpoint as completed (even on max iterations)
        if checkpoint_manager and checkpoint:
            checkpoint_manager.complete(checkpoint)

        return response

    except Exception as e:
        # Mark checkpoint as failed on exception
        if checkpoint_manager and checkpoint:
            checkpoint_manager.fail(checkpoint, str(e))
        raise


class Agent:
    """
    Reusable agent with pre-configured LLM and tools.

    Supports middleware for agent-level business rules and guardrails.
    Supports checkpointing for crash recovery in long-running workflows.

    Example:
        agent = Agent(
            client=create_client("bedrock", model="claude-sonnet-4-5"),
            tools=[get_weather, calculate],
            system_prompt="You are a helpful assistant."
        )

        result = await agent.run("What's the weather in NYC?")
        print(result.answer)

    Example with middleware:
        from penguin.middleware import GuardrailMiddleware, ToolBlockingMiddleware

        agent = (
            Agent(client=client, tools=[claim_tools])
            .use(GuardrailMiddleware(max_input_length=5000))
            .use(ToolBlockingMiddleware(blocked_tools=["delete_file"]))
        )

    Example with checkpointing:
        # Enable checkpointing for crash recovery
        agent = Agent(
            client=client,
            tools=[analyze_data, generate_report],
            enable_checkpointing=True
        )

        # Run with automatic checkpointing after each iteration
        result = await agent.run("Analyze sales data and create report")

        # If crashed, resume later:
        for run in agent.list_resumable():
            print(f"{run.agent_run_id}: {run.original_prompt[:50]}...")

        result = await agent.resume("abc-123-run-id")
    """

    def __init__(
        self,
        client: BaseChatCompletionClient,
        tools: List[Any],
        system_prompt: Optional[str] = None,
        max_iterations: int = 10,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        middleware: Optional["MiddlewareChain"] = None,
        enable_checkpointing: bool = False,
    ):
        """
        Initialize an agent.

        Args:
            client: LLM client
            tools: List of tools (decorated with @tool or BaseTool instances)
            system_prompt: Optional system prompt
            max_iterations: Max tool-call rounds
            max_tokens: Max tokens per LLM call
            temperature: LLM temperature
            middleware: Optional pre-configured middleware chain
            enable_checkpointing: If True, persist state after each iteration for crash recovery
        """
        self.client = client
        self.executor = ToolExecutor(tools)
        self.system_prompt = system_prompt
        self.max_iterations = max_iterations
        self.max_tokens = max_tokens
        self.temperature = temperature
        self._middleware: Optional["MiddlewareChain"] = middleware
        self.enable_checkpointing = enable_checkpointing
        self._checkpoint_manager: Optional["CheckpointManager"] = None

        # Initialize checkpoint manager if enabled
        if enable_checkpointing:
            from penguin.agents.checkpoint import CheckpointManager
            self._checkpoint_manager = CheckpointManager()

    def use(self, middleware: Union["BaseMiddleware", List["BaseMiddleware"]]) -> "Agent":
        """
        Add middleware to this agent.

        Middleware is executed in the order added for requests,
        and in reverse order for responses.

        Args:
            middleware: Single middleware instance OR list of middlewares to add

        Returns:
            Self for method chaining

        Example:
            # Chain calls
            agent = (
                Agent(client=client, tools=[...])
                .use(GuardrailMiddleware(max_input_length=5000))
                .use(ToolBlockingMiddleware(blocked_tools=["dangerous_tool"]))
            )

            # Pass a list
            agent.use([
                GuardrailMiddleware(max_input_length=5000),
                ToolBlockingMiddleware(blocked_tools=["dangerous_tool"])
            ])
        """
        if self._middleware is None:
            from penguin.middleware import MiddlewareChain
            self._middleware = MiddlewareChain()

        # Handle list of middlewares
        if isinstance(middleware, list):
            for mw in middleware:
                self._middleware.add(mw)
        else:
            self._middleware.add(middleware)
        return self

    @property
    def middleware(self) -> Optional["MiddlewareChain"]:
        """Get the middleware chain (may be None if no middleware added)."""
        return self._middleware

    @property
    def has_middleware(self) -> bool:
        """Check if any middleware is configured."""
        return self._middleware is not None and len(self._middleware) > 0

    async def run(self, prompt: str, verbose: bool = False) -> AgentResponse:
        """
        Run the agent with a prompt.

        Args:
            prompt: User's question/request
            verbose: Print debug info

        Returns:
            AgentResponse with answer and tool call log
        """
        return await chat_with_tools(
            prompt=prompt,
            client=self.client,
            executor=self.executor,
            system_prompt=self.system_prompt,
            max_iterations=self.max_iterations,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
            verbose=verbose,
            middleware=self._middleware,
            checkpoint_manager=self._checkpoint_manager,
        )

    async def resume(self, agent_run_id: str, verbose: bool = False) -> AgentResponse:
        """
        Resume a previous run from its checkpoint.

        Args:
            agent_run_id: The ID of the run to resume
            verbose: Print debug info

        Returns:
            AgentResponse with answer and tool call log

        Raises:
            ValueError: If checkpointing is not enabled or checkpoint not found
            CheckpointToolMismatchError: If tools don't match the original run
        """
        if not self._checkpoint_manager:
            raise ValueError(
                "Checkpointing not enabled. Create agent with enable_checkpointing=True"
            )

        return await chat_with_tools(
            prompt="",  # Ignored on resume, uses checkpoint's original prompt
            client=self.client,
            executor=self.executor,
            system_prompt=self.system_prompt,
            max_iterations=self.max_iterations,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
            verbose=verbose,
            middleware=self._middleware,
            checkpoint_manager=self._checkpoint_manager,
            resume_from=agent_run_id,
        )

    def list_resumable(self) -> List["CheckpointSummary"]:
        """
        List runs that can be resumed.

        Returns:
            List of checkpoint summaries for resumable runs

        Raises:
            ValueError: If checkpointing is not enabled
        """
        if not self._checkpoint_manager:
            raise ValueError(
                "Checkpointing not enabled. Create agent with enable_checkpointing=True"
            )

        return self._checkpoint_manager.list_resumable()

    def add_tool(self, tool) -> None:
        """Add a tool to the agent."""
        self.executor.register(tool)

    @property
    def tools(self) -> List[str]:
        """List tool names."""
        return [t.name for t in self.executor.list_tools()]

    @property
    def checkpoint_manager(self) -> Optional["CheckpointManager"]:
        """Get the checkpoint manager (may be None if checkpointing not enabled)."""
        return self._checkpoint_manager
