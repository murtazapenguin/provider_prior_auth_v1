"""
Penguin Agents Module (DEPRECATED)

.. deprecated:: 0.2.0
    Use ``penguin.core.agents`` for new code. The ``create_penguin_agent``
    and ``run_agent`` functions replace the old ``Agent`` class and
    ``chat_with_tools`` function.

New Usage:
    from penguin.core import create_model, create_agent, run_agent, tool

    model = create_model(provider="bedrock", model="claude-sonnet-4-5")

    @tool
    def get_weather(city: str) -> str:
        \"\"\"Get weather.\"\"\"
        return "72F"

    agent = create_agent(model, tools=[get_weather])
    result = await run_agent(agent, "What's the weather?")
"""

import warnings as _warnings

_warnings.warn(
    "penguin.agents is deprecated since v0.2.0. Use penguin.core.agents instead.",
    DeprecationWarning,
    stacklevel=2,
)

# New LangGraph-based agent API
from penguin.core.agents import (
    create_penguin_agent,
    run_agent,
    AgentResponse,
    AgentState,
    get_memory_checkpointer,
    get_postgres_checkpointer,
)

# Legacy submodules (still functional)
from .base import Agent, chat_with_tools
from .tool_generator import ToolGeneratorService, GeneratedTool
from .coder import CodeGeneratorAgent, PenguinCoderAgent
from .workflow import WorkflowSuggestionAgent
from .checkpoint import (
    CheckpointManager,
    CheckpointRegistry,
    AgentCheckpoint,
    CheckpointSummary,
    CheckpointStatus,
    CheckpointToolMismatchError,
    list_resumable_runs,
    cleanup_old_checkpoints,
)

__all__ = [
    # New (preferred)
    "create_penguin_agent",
    "run_agent",
    "AgentResponse",
    "AgentState",
    "get_memory_checkpointer",
    "get_postgres_checkpointer",
    # Legacy
    "Agent",
    "chat_with_tools",
    "ToolGeneratorService",
    "GeneratedTool",
    "CodeGeneratorAgent",
    "PenguinCoderAgent",
    "WorkflowSuggestionAgent",
    "CheckpointManager",
    "CheckpointRegistry",
    "AgentCheckpoint",
    "CheckpointSummary",
    "CheckpointStatus",
    "CheckpointToolMismatchError",
    "list_resumable_runs",
    "cleanup_old_checkpoints",
]
