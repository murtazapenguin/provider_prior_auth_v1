# START OF FILE: penguin/agents/workflow.py ---
import asyncio
import logging
import os
from math import ceil
from typing import List, Dict, Any, Optional

import pandas as pd

from ..llm.base import BaseChatCompletionClient
from ..llm.messages import UserMessage
from ..blueprints.registry import BlueprintRegistry
from ..tools.registry import ToolRegistry
from ..data_assets.registry import DataAssetRegistry
from ..observability.context import get_current_trace_id
from ..observability.setup import is_tracing_enabled

logger = logging.getLogger("penguin.agents.workflow")

# =============================================================================
# PROMPT TEMPLATES
# =============================================================================

BLUEPRINT_ANALYSIS_PROMPT = """You are a Workflow Analyst. Your task is to analyze a REFERENCE WORKFLOW and determine which parts are applicable to a NEW TASK.

## REFERENCE WORKFLOW
Name: {blueprint_name}
Description: {blueprint_description}
Workflow:
{blueprint_workflow}

## NEW TASK
Task Description: {task}

Sample Input:
{sample_input}

Expected Output:
{sample_output}

## YOUR ANALYSIS

Analyze the reference workflow step by step and determine:

1. **APPLICABLE PATTERNS** - Steps/patterns from the reference that CAN be used for the new task:
   - List each applicable step
   - Explain WHY it applies to the new task
   - Note any ADAPTATIONS needed (e.g., "change ICD-10 to CPT codes")

2. **SKIP PATTERNS** - Steps/patterns that should NOT be used:
   - List each step to skip
   - Explain WHY it doesn't apply (e.g., "HCC hierarchy rules don't apply to HH coding")

3. **NEW PATTERNS NEEDED** - Steps the new task requires that aren't in the reference:
   - List what's missing
   - Briefly describe what each new pattern should do

Be specific and practical. The goal is to transfer useful knowledge while avoiding forcing irrelevant patterns onto the new task.

Respond in this JSON format:
{{
    "applicable_patterns": [
        {{"step": "...", "reason": "...", "adaptation": null}}
    ],
    "skip_patterns": [
        {{"step": "...", "reason": "..."}}
    ],
    "new_patterns_needed": [
        {{"pattern": "...", "description": "..."}}
    ],
    "overall_transferability": "high",
    "summary": "Summary of how to use this blueprint for the new task"
}}
"""

IMPLEMENTATION_HINTS_PROMPT = """You are a Technical Advisor helping translate a workflow into code implementation hints.

## TASK
{task}

## WORKFLOW TO IMPLEMENT
{generalized_workflow}

## AVAILABLE PENGUIN LIBRARY CAPABILITIES
- LLM calls: `create_client()`, `UserMessage`, `SystemMessage`
- Structured output: `output_format=PydanticModel` for typed responses
- Extended thinking: `thinking=True` for complex reasoning
- Tools: `@tool` decorator, `ToolRegistry`, `Agent` class
- Async: All LLM calls are async, use `await`

## CRITICAL RULES - MUST INCLUDE IN HINTS

1. **NEVER TRUNCATE INPUT DATA**: The code must process ALL input text completely.
   - DO NOT skip, sample, or abbreviate input data
   - ALWAYS iterate over and process ALL items
   - This is CRITICAL for OCR text - every character matters

## CRITICAL: WHEN TO USE LLM vs CODE LOGIC

When generating hints, guide the code generator on choosing the right tool for each subtask:

### USE LLM (with output_format) FOR:
- **Semantic understanding**: Extracting meaning, intent, or concepts from text
- **Natural language parsing**: Converting unstructured text to structured data
- **Classification/categorization**: Deciding what type/category something belongs to
- **Hierarchical extraction**: Understanding parent-child relationships in content
- **Boundary detection**: Finding where logical units begin/end (not visual/formatting boundaries)
- **Content summarization**: Condensing or extracting key points

### USE CODE/REGEX FOR:
- **Pattern matching**: Finding dates, IDs, codes, emails, URLs with known formats
- **Data transformation**: Converting between structured formats (JSON→JSON, CSV→JSON)
- **Calculations**: Math operations, aggregations, statistics
- **Validation**: Checking if data matches known rules/schemas
- **Simple string operations**: Trimming, case changes, concatenation
- **File I/O**: Reading/writing files, API calls

### COMMON MISTAKES TO AVOID:
❌ Using `text.split('\\n')` to extract logical items (newlines ≠ semantic boundaries)
❌ Using regex to parse natural language sentences
❌ Using string matching for classification tasks
❌ Assuming visual formatting reflects logical structure

### CORRECT APPROACH:
✅ Use LLM with structured output (output_format) for semantic extraction
✅ Use Pydantic models to define expected output structure
✅ Let LLM understand content meaning, then code processes the structured result

## YOUR TASK

Generate a list of **implementation hints** - practical notes that will help the code generator create working Python code.

Focus on:
1. **Data Flow**: Where should structured output (Pydantic) be used vs plain text?
2. **Parallelization**: Which steps can run in parallel vs must be sequential?
3. **Error Handling**: What errors might occur and how to handle them?
4. **LLM Usage**: Should new tools be created to solve the task? What should the tool do?
5. **Edge Cases**: What edge cases from the workflow need special code handling?
6. **Complete Processing**: Ensure ALL input data is processed without truncation

DO NOT:
- Write actual code
- Be too vague ("handle errors properly")
- Repeat what's obvious from the workflow
- Suggest truncating, sampling, or limiting input data

DO:
- Be specific and actionable
- Reference specific steps from the workflow
- Mention specific Penguin library features to use
- Emphasize processing ALL data completely

Respond with a JSON array of hint strings (practical hints):
["hint1", "hint2", ...]
"""

INDIVIDUAL_WORKFLOW_PROMPT = """You are a Workflow Architect designing step-by-step processes.

## TASK
{task}

## REFERENCE PATTERNS (from similar workflows)
{reference_context}

## PLATFORM CAPABILITIES
{platform_context}

## EXAMPLE TO ANALYZE

INPUT:
{input_text}

EXPECTED OUTPUT:
{output_text}

## CRITICAL RULES - MUST FOLLOW

1. **NEVER TRUNCATE INPUT DATA**: The workflow must process ALL input text completely.
   - DO NOT skip sections, paragraphs, or parts of the input
   - DO NOT summarize or abbreviate the input
   - DO NOT limit processing to "first N items" or "sample of the data"
   - ALWAYS process the COMPLETE input from start to finish
   - This is especially critical for OCR text - every character matters

2. **PRESERVE ALL INFORMATION**: When extracting or transforming data:
   - Extract ALL relevant items, not just examples
   - Process EVERY section of the input
   - Do not assume any part is "less important"

## YOUR TASK

Design a step-by-step workflow that transforms the INPUT into the exact EXPECTED OUTPUT.

For each step, specify:
1. **What** - What action to take
2. **Why** - Why this step is needed
3. **How** - Key details on implementation (but not code)

Focus on:
- Information extraction priorities
- How to handle conflicting or ambiguous information
- Decision logic for edge cases in this example
- Which reference patterns apply (with any needed adaptations)

Be specific to THIS example - we'll generalize across examples later.

Provide the workflow in clear, numbered steps.
"""

GENERALIZATION_PROMPT_INITIAL = """You are a Workflow Architect creating a generalized workflow from specific examples.

## TASK
{task}

## REFERENCE PATTERNS
{reference_context}

## INDIVIDUAL WORKFLOWS (from {num_workflows} examples)
{formatted_workflows}

## CRITICAL RULES - MUST FOLLOW

1. **NEVER TRUNCATE INPUT DATA**: The workflow must process ALL input text completely.
   - DO NOT design steps that skip, sample, or abbreviate input data
   - DO NOT limit processing to "first N items" or partial data
   - ALWAYS process the COMPLETE input from start to finish
   - This is CRITICAL for OCR text - every character matters for accuracy

2. **PRESERVE ALL INFORMATION**: The workflow must extract/transform ALL data:
   - Process EVERY section, paragraph, and item in the input
   - Do not assume any part of the input is "less important"
   - Design steps that iterate over ALL items, not just examples

## YOUR TASK

Synthesize these individual workflows into ONE generalized workflow that handles ALL cases.

Your generalized workflow must:
1. **Identify Common Patterns**: What steps appear in most/all examples?
2. **Handle Variations**: How do steps differ? Create decision logic for variations.
3. **Cover Edge Cases**: Include handling for unusual cases seen in examples.
4. **Be Complete**: Every example should be solvable using this workflow.
5. **Be Clear**: Each step should be unambiguous and actionable.
6. **Process Completely**: Never truncate, sample, or skip input data.

Structure your workflow as:
- Numbered steps (Step 1, Step 2, etc.)
- Decision points where logic branches (IF/THEN/ELSE)
- Clear criteria for each decision
- Notes on edge cases

Focus on the LOGIC and REASONING, not code. This workflow will be translated to code later.
"""

GENERALIZATION_PROMPT_ENHANCE = """You are a Workflow Architect enhancing an existing workflow with new patterns.

## TASK
{task}

## CURRENT GENERALIZED WORKFLOW
{current_workflow}

## NEW EXAMPLES TO INTEGRATE ({num_new} workflows)
{new_workflows}

## CRITICAL RULES - MUST FOLLOW

1. **NEVER TRUNCATE INPUT DATA**: The workflow must process ALL input text completely.
   - DO NOT design steps that skip, sample, or abbreviate input data
   - ALWAYS process the COMPLETE input from start to finish
   - This is CRITICAL for OCR text - every character matters

2. **PRESERVE ALL INFORMATION**: Process EVERY section and item in the input.

## YOUR TASK

Enhance the current workflow by integrating patterns from these new examples.

Rules:
1. **PRESERVE** all existing steps and patterns that still apply
2. **ADD** new patterns/edge cases discovered in these examples
3. **REFINE** decision logic if new examples reveal better criteria
4. **REMOVE** nothing unless it's clearly wrong based on new evidence
5. **NEVER ADD TRUNCATION**: Do not add steps that limit, sample, or skip data

For each change:
- If adding a step: Note which example(s) required it
- If modifying a step: Explain what changed and why
- If adding an edge case: Describe the trigger condition

Return the COMPLETE updated workflow (not just the changes).
"""


def _get_tracer():
    """Get OTel tracer if available."""
    try:
        from opentelemetry import trace
        return trace.get_tracer("penguin.agents.workflow")
    except ImportError:
        return None


class WorkflowSuggestionAgent:
    """
    Agent that generates generalized workflows from input-output examples.

    Uses a MAP-REDUCE pattern:
    1. MAP: Generate individual workflows for each example (concurrent)
    2. REDUCE: Synthesize a generalized workflow using iterative batch enhancement

    The batch generalization approach prevents token explosion when processing
    many examples (200+) by iteratively enhancing the workflow with batches of 10.
    """

    def __init__(
        self,
        llm_provider: BaseChatCompletionClient,
        blueprint_registry: Optional[BlueprintRegistry] = None,
        tool_registry: Optional[ToolRegistry] = None,
        asset_registry: Optional[DataAssetRegistry] = None,
        max_concurrency: int = 5,
        batch_size: int = 10,
        batch_delay: float = 5.0,
        verbose: bool = True
    ):
        """
        Initialize the workflow suggestion agent.

        Args:
            llm_provider: LLM client for generating workflows
            blueprint_registry: Registry of reusable workflow blueprints
            tool_registry: Registry of available tools
            asset_registry: Registry of available data assets
            max_concurrency: Maximum concurrent LLM calls for MAP phase (default: 5)
            batch_size: Number of workflows per batch in REDUCE phase (default: 10)
            batch_delay: Delay between batches in seconds for rate limiting (default: 5.0)
            verbose: Whether to print progress to stdout (default: True)
        """
        self.llm = llm_provider
        self.blueprints = blueprint_registry
        self.tools = tool_registry
        self.assets = asset_registry
        self.semaphore = asyncio.Semaphore(max_concurrency)
        self.batch_size = batch_size
        self.batch_delay = batch_delay
        self.verbose = verbose

        # System prompt - focused on workflow logic, not code
        self.system_prompt = """You are a Workflow Architect. Your task is to design the optimal workflow to achieve a given objective.
Focus on figuring the right workflow to solve complex problems.
At this stage, code is not needed - the goal is to optimize for the right way to break down a complex problem into solvable steps.
This means figuring out the right prompts, reasoning steps, and sequence of operations.
The workflow suggestion should generalize and produce the exact output present in the golden data.
Workflow suggestions must be STRICTLY based on the input and corresponding output presented.
There might be instances when inputs can be misleading - for example, misleading sentences that require workarounds.
As more examples are processed, enhance the generalized workflow to account for as many edge cases as possible."""

    def _format_suggestions(self, suggestions: List[str]) -> str:
        """Format suggestions for prompt (matching bcbs_infer style)."""
        formatted = []
        for i, suggestion in enumerate(suggestions, 1):
            formatted.append(f"=== SUGGESTION {i} ===\n{suggestion}\n")
        return "\n".join(formatted)

    def _get_platform_context(self) -> str:
        """Helper to combine assets and tools into a single context block."""
        from ..data_assets import list_assets as list_bundled_assets

        context = "--- PENGUIN PLATFORM CAPABILITIES ---\n"

        # User-registered assets
        if self.assets:
            context += "AVAILABLE DATA ASSETS:\n"
            for a in self.assets.list_assets():
                context += f"- {a['name']}: {a['description']} [user]\n"

        # Bundled and remote assets from penguin.data_assets
        bundled_assets = list_bundled_assets()
        if bundled_assets:
            if not self.assets:
                context += "AVAILABLE DATA ASSETS:\n"
            for a in bundled_assets:
                asset_type = a.get('type', 'bundled')
                context += f"- {a['name']}: {a['description']} [{asset_type}]\n"

        # Usage hint
        if self.assets or bundled_assets:
            context += "\nUsage: from penguin.data_assets import load_asset\n"
            context += "       df = load_asset(\"asset_name\")  # Returns pandas DataFrame\n"

        # Tools
        if self.tools:
            context += "\nAVAILABLE TOOLS:\n"
            for t in self.tools.list_tools():
                context += f"- {t['name']}: {t['description']}\n"

        return context

    def _get_blueprint_context(self, blueprint_names: List[str]) -> tuple[str, List[str]]:
        """
        Fetch workflows from named blueprints and format as reference context.

        Args:
            blueprint_names: List of blueprint names to fetch

        Returns:
            Tuple of (formatted context string, list of blueprints that were found)
        """
        if not self.blueprints or not blueprint_names:
            return "", []

        context_parts = []
        found_blueprints = []

        for name in blueprint_names:
            bp = self.blueprints.get_blueprint(name)
            if bp:
                found_blueprints.append(name)
                context_parts.append(f"""--- REFERENCE: {bp.name} ---
Description: {bp.description}
Workflow:
{bp.workflow}
""")
            else:
                logger.warning(f"Blueprint '{name}' not found in registry")

        if context_parts:
            header = "--- REFERENCE WORKFLOWS (use as inspiration) ---\n"
            return header + "\n".join(context_parts), found_blueprints

        return "", found_blueprints

    async def _analyze_blueprint_relevance(
        self,
        blueprint_name: str,
        task: str,
        sample_input: str,
        sample_output: str
    ) -> Dict[str, Any]:
        """
        Analyze which steps from a blueprint are transferable to the new task.

        Args:
            blueprint_name: Name of the blueprint to analyze
            task: The new task description
            sample_input: Sample input from the new task
            sample_output: Expected output for the sample

        Returns:
            Dict with applicable_patterns, skip_patterns, new_patterns_needed,
            overall_transferability, and summary
        """
        if not self.blueprints:
            return {}

        bp = self.blueprints.get_blueprint(blueprint_name)
        if not bp:
            logger.warning(f"Blueprint '{blueprint_name}' not found for analysis")
            return {}

        prompt = BLUEPRINT_ANALYSIS_PROMPT.format(
            blueprint_name=bp.name,
            blueprint_description=bp.description,
            blueprint_workflow=bp.workflow,
            task=task,
            sample_input=sample_input[:2000],  # Truncate for token limits
            sample_output=sample_output[:2000]
        )

        try:
            result = await self.llm.create([UserMessage(prompt)], thinking=False, max_tokens=4000)
            # Parse JSON response
            import json
            import json_repair
            analysis = json_repair.loads(result.content)
            return analysis
        except Exception as e:
            logger.warning(f"Failed to analyze blueprint relevance: {e}")
            return {}

    async def _get_blueprint_context_with_analysis(
        self,
        blueprint_names: List[str],
        task: str,
        sample_input: str,
        sample_output: str
    ) -> tuple[str, List[str], Dict[str, Any]]:
        """
        Analyze blueprints and return only applicable patterns.

        Args:
            blueprint_names: List of blueprint names to analyze
            task: The new task description
            sample_input: Sample input from the new task
            sample_output: Expected output for the sample

        Returns:
            Tuple of (filtered_context, found_blueprints, relevance_analysis)
        """
        if not self.blueprints or not blueprint_names:
            return "", [], {}

        found_blueprints = []
        all_analyses = {}
        context_parts = []

        for name in blueprint_names:
            bp = self.blueprints.get_blueprint(name)
            if not bp:
                logger.warning(f"Blueprint '{name}' not found in registry")
                continue

            found_blueprints.append(name)

            # Analyze relevance
            analysis = await self._analyze_blueprint_relevance(
                name, task, sample_input, sample_output
            )
            all_analyses[name] = analysis

            # Build filtered context from analysis
            if analysis and analysis.get("applicable_patterns"):
                context_parts.append(f"--- APPLICABLE PATTERNS FROM: {bp.name} ---")
                context_parts.append(f"(Original: {bp.description})")
                context_parts.append(f"Summary: {analysis.get('summary', 'N/A')}\n")

                for pattern in analysis["applicable_patterns"]:
                    step = pattern.get("step", "")
                    reason = pattern.get("reason", "")
                    adaptation = pattern.get("adaptation")

                    context_parts.append(f"- {step}")
                    context_parts.append(f"  Why: {reason}")
                    if adaptation:
                        context_parts.append(f"  Adapt: {adaptation}")
                    context_parts.append("")

                # Include new patterns needed
                if analysis.get("new_patterns_needed"):
                    context_parts.append("NEW PATTERNS TO ADD:")
                    for new_pattern in analysis["new_patterns_needed"]:
                        context_parts.append(f"- {new_pattern.get('pattern', '')}: {new_pattern.get('description', '')}")
                    context_parts.append("")

        if context_parts:
            header = "--- REFERENCE PATTERNS (analyzed for relevance) ---\n"
            return header + "\n".join(context_parts), found_blueprints, all_analyses

        return "", found_blueprints, all_analyses

    async def _generate_implementation_hints(
        self,
        generalized_workflow: str,
        task: str
    ) -> List[str]:
        """
        Generate implementation hints to guide code generation.

        Args:
            generalized_workflow: The generalized workflow text
            task: The task description

        Returns:
            List of implementation hint strings
        """
        prompt = IMPLEMENTATION_HINTS_PROMPT.format(
            task=task,
            generalized_workflow=generalized_workflow[:8000]  # Truncate for token limits
        )

        try:
            result = await self.llm.create([UserMessage(prompt)], thinking=False, max_tokens=2000)
            # Parse JSON array response
            import json
            import json_repair
            hints = json_repair.loads(result.content)
            if isinstance(hints, list):
                return hints
            return []
        except Exception as e:
            logger.warning(f"Failed to generate implementation hints: {e}")
            return []

    async def _generate_individual_workflow(
        self,
        task: str,
        input_text: str,
        output_text: str,
        platform_context: str,
        reference_context: str = ""
    ) -> str:
        """
        STAGE 1 (MAP): Look at one data point and create a
        specific workflow just for this example.

        Args:
            task: The task description
            input_text: The input data for this example
            output_text: The expected output for this example
            platform_context: Available tools and assets
            reference_context: Reference blueprints and human context (optional)
        """
        # Use the new structured prompt template
        prompt = INDIVIDUAL_WORKFLOW_PROMPT.format(
            task=task,
            reference_context=reference_context if reference_context else "None provided",
            platform_context=platform_context,
            input_text=input_text,
            output_text=output_text
        )

        async with self.semaphore:
            # thinking=True enables extended reasoning for complex logic
            result = await self.llm.create([UserMessage(prompt)], thinking=True, max_tokens=30000)
            return result.content

    async def _generalize_in_batches(
        self,
        individual_workflows: List[str],
        task: str,
        reference_context: str = ""
    ) -> str:
        """
        STAGE 2 (REDUCE): Iteratively synthesize a generalized workflow from batches.

        Instead of concatenating ALL workflows into a single prompt (token explosion),
        this method processes workflows in batches:
        - Batch 0: Create initial generalized workflow from first batch
        - Batch 1-N: Enhance the existing workflow with patterns from new batches

        Args:
            individual_workflows: List of workflow strings from MAP phase
            task: The task description
            reference_context: Reference blueprints and human context (optional)

        Returns:
            The final generalized workflow string
        """
        num_batches = ceil(len(individual_workflows) / self.batch_size)
        generalized_workflow = None

        if self.verbose:
            print(f"[REDUCE] Generalizing {len(individual_workflows)} workflows in {num_batches} batches")

        for i in range(num_batches):
            batch_start = i * self.batch_size
            batch_end = min((i + 1) * self.batch_size, len(individual_workflows))
            batch = individual_workflows[batch_start:batch_end]

            if self.verbose:
                print(f"  [Batch {i + 1}/{num_batches}] Processing {len(batch)} workflows...")

            if i == 0:
                # First batch: Create initial generalized workflow using new template
                formatted_batch = self._format_suggestions(batch)
                prompt = GENERALIZATION_PROMPT_INITIAL.format(
                    task=task,
                    reference_context=reference_context if reference_context else "None provided",
                    num_workflows=len(batch),
                    formatted_workflows=formatted_batch
                )
            else:
                # Subsequent batches: Enhance existing workflow using new template
                formatted_batch = self._format_suggestions(batch)
                prompt = GENERALIZATION_PROMPT_ENHANCE.format(
                    task=task,
                    current_workflow=generalized_workflow,
                    num_new=len(batch),
                    new_workflows=formatted_batch
                )

            # REDUCE phase: thinking=False for faster synthesis (individual workflows already reasoned)
            result = await self.llm.create([UserMessage(prompt)], thinking=False, max_tokens=16000)
            generalized_workflow = result.content

            if self.verbose:
                print(f"  [Batch {i + 1}/{num_batches}] Done")

            # Rate limiting: delay between batches (except after last batch)
            if i < num_batches - 1 and self.batch_delay > 0:
                if self.verbose:
                    print(f"  Waiting {self.batch_delay}s before next batch...")
                await asyncio.sleep(self.batch_delay)

        return generalized_workflow

    async def run(
        self,
        df: pd.DataFrame,
        task: str,
        n_rows: int = 50,
        input_col: str = "input",
        output_col: str = "output",
        reference_blueprints: Optional[List[str]] = None,
        reference_context: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Generate a generalized workflow from input-output examples.

        Args:
            df: DataFrame with input-output pairs
            task: Description of the task
            n_rows: Number of rows to process (default: 50, can scale to 200+)
            input_col: Column name for input data (default: "input")
            output_col: Column name for output data (default: "output")
            reference_blueprints: List of blueprint names to use as reference (default: None)
            reference_context: Human-provided workflow hints/context (default: None)

        Returns:
            Dict with generalized_workflow, individual_workflows, assets_to_use, tools_to_use,
            trace_id, reference_blueprints_used, reference_context_provided
        """
        # Wrap in parent span if tracing is enabled
        tracer = _get_tracer() if is_tracing_enabled() else None

        if tracer:
            # Use start_as_current_span to create parent span
            # All LLM calls inside will become children of this span
            with tracer.start_as_current_span("workflow_generation") as span:
                span.set_attribute("penguin.workflow.task", task[:200])  # Truncate task
                span.set_attribute("penguin.workflow.n_rows", n_rows)
                if reference_blueprints:
                    span.set_attribute("penguin.workflow.reference_blueprints", ",".join(reference_blueprints))

                result = await self._run_internal(
                    df, task, n_rows, input_col, output_col,
                    reference_blueprints, reference_context
                )

                # Get trace_id from the parent span
                span_context = span.get_span_context()
                if span_context.is_valid:
                    result["trace_id"] = format(span_context.trace_id, '032x')

                return result
        else:
            return await self._run_internal(
                df, task, n_rows, input_col, output_col,
                reference_blueprints, reference_context
            )

    async def _run_internal(
        self,
        df: pd.DataFrame,
        task: str,
        n_rows: int,
        input_col: str,
        output_col: str,
        reference_blueprints: Optional[List[str]] = None,
        reference_context: Optional[str] = None
    ) -> Dict[str, Any]:
        """Internal run implementation (may be wrapped in span)."""
        # 1. Prepare Platform Context
        platform_context = self._get_platform_context()

        # 2. Prepare sample data
        sample_df = df.head(min(n_rows, len(df)))

        # Get first sample for blueprint analysis
        first_row = sample_df.iloc[0] if len(sample_df) > 0 else None
        sample_input = str(first_row.get(input_col, '')) if first_row is not None else ""
        sample_output = str(first_row.get(output_col, '')) if first_row is not None else ""

        # 3. Build combined reference context (blueprints + human context)
        blueprint_relevance = {}
        blueprints_used = []

        if reference_blueprints and self.blueprints:
            # Use new analysis-based context generation
            if self.verbose:
                print(f"[ANALYSIS] Analyzing {len(reference_blueprints)} blueprint(s) for relevance...")

            blueprint_context, blueprints_used, blueprint_relevance = await self._get_blueprint_context_with_analysis(
                blueprint_names=reference_blueprints,
                task=task,
                sample_input=sample_input,
                sample_output=sample_output
            )

            if self.verbose and blueprint_relevance:
                for bp_name, analysis in blueprint_relevance.items():
                    transferability = analysis.get("overall_transferability", "unknown")
                    applicable_count = len(analysis.get("applicable_patterns", []))
                    skip_count = len(analysis.get("skip_patterns", []))
                    print(f"  [{bp_name}] Transferability: {transferability}, "
                          f"Applicable: {applicable_count}, Skip: {skip_count}")
        else:
            # Fallback to original method if no blueprints
            blueprint_context, blueprints_used = self._get_blueprint_context(reference_blueprints or [])

        combined_reference = ""
        if blueprint_context:
            combined_reference += blueprint_context + "\n"
        if reference_context:
            combined_reference += f"--- ADDITIONAL CONTEXT ---\n{reference_context}\n"

        if self.verbose and combined_reference:
            print(f"[REF] Using {len(blueprints_used)} reference blueprint(s): {blueprints_used}")
            if reference_context:
                print(f"[REF] Additional context provided ({len(reference_context)} chars)")

        # 4. STAGE 1: Parallel Individual Workflow Generation (MAP)
        map_tasks = []

        if self.verbose:
            print(f"[MAP] Generating individual workflows for {len(sample_df)} examples...")

        for idx, row in sample_df.iterrows():
            map_tasks.append(
                self._generate_individual_workflow(
                    task,
                    str(row.get(input_col, '')),
                    str(row.get(output_col, '')),
                    platform_context,
                    combined_reference
                )
            )

        # Run with progress tracking
        individual_workflows = []
        completed = 0
        total = len(map_tasks)

        for coro in asyncio.as_completed(map_tasks):
            result = await coro
            individual_workflows.append(result)
            completed += 1
            if self.verbose and (completed % 5 == 0 or completed == total):
                print(f"  [MAP] {completed}/{total} workflows generated")

        if self.verbose:
            print(f"[MAP] Completed all {len(individual_workflows)} individual workflows")

        # 5. STAGE 2: Batched Synthesis (REDUCE)
        generalized_workflow = await self._generalize_in_batches(
            individual_workflows=individual_workflows,
            task=task,
            reference_context=combined_reference
        )

        # 6. Generate implementation hints for code generator
        implementation_hints = []
        if self.verbose:
            print("[HINTS] Generating implementation hints for code generation...")

        implementation_hints = await self._generate_implementation_hints(
            generalized_workflow=generalized_workflow,
            task=task
        )

        if self.verbose:
            print(f"[HINTS] Generated {len(implementation_hints)} implementation hints")

        # Extract referenced assets and tools
        assets_to_use = []
        tools_to_use = []

        if self.assets:
            assets_to_use = [
                a['name'] for a in self.assets.list_assets()
                if a['name'] in generalized_workflow
            ]

        if self.tools:
            tools_to_use = [
                t['name'] for t in self.tools.list_tools()
                if t['name'] in generalized_workflow
            ]

        # Capture trace ID (fallback if not wrapped in span)
        trace_id = getattr(self.llm, 'last_trace_id', None) or get_current_trace_id()

        if self.verbose:
            print(f"[DONE] Workflow generation complete!")
            if trace_id:
                print(f"[TRACE] {trace_id}")

        return {
            "generalized_workflow": generalized_workflow,
            "individual_workflows": individual_workflows,
            "implementation_hints": implementation_hints,
            "blueprint_relevance": blueprint_relevance,
            "assets_to_use": assets_to_use,
            "tools_to_use": tools_to_use,
            "trace_id": trace_id,
            "reference_blueprints_used": blueprints_used,
            "reference_context_provided": bool(reference_context)
        }
# END OF FILE: penguin/agents/workflow.py ---
