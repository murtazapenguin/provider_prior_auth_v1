"""
Penguin Core Model Factory & Registry

Wraps LangChain's ``init_chat_model`` with a Penguin-friendly model registry
and automatic Langfuse callback injection.

Usage:
    from penguin.core import create_model

    # Recommended: explicit provider + model (keyword-only args)
    model = create_model(provider="bedrock", model="claude-sonnet-4-5")

    # With options
    model = create_model(provider="bedrock", model="claude-sonnet-4-5", temperature=0.7, max_tokens=4096)

    # Alternative: provider:model string format
    model = create_model(model_name="openai:gpt-4o")

    # Auto-detect from environment
    model = create_model_from_env()
"""

import logging
import os
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, TYPE_CHECKING

if TYPE_CHECKING:
    from penguin.core import BaseChatModel
else:
    from langchain_core.language_models import BaseChatModel

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Provider enum
# ---------------------------------------------------------------------------

class Provider(str, Enum):
    """Supported LLM providers."""
    BEDROCK = "bedrock"
    OPENAI = "openai"
    AZURE_OPENAI = "azure_openai"
    GEMINI = "google-genai"


# ---------------------------------------------------------------------------
# Model metadata
# ---------------------------------------------------------------------------

@dataclass
class ModelInfo:
    """
    Model metadata and capabilities.

    Attributes:
        id: Friendly name (e.g., "claude-sonnet-4-5")
        provider: LangChain provider slug used by ``init_chat_model``
        model: Actual model ID sent to the provider API
        supports_vision: Whether the model can process images
        supports_thinking: Whether the model supports extended thinking
        supports_tools: Whether the model supports function/tool calling
        max_tokens: Maximum output tokens
        context_window: Maximum context window size
        description: Human-readable description
    """
    id: str
    provider: Provider
    model: str
    supports_vision: bool = False
    supports_thinking: bool = False
    supports_tools: bool = True
    max_tokens: int = 8192
    context_window: int = 128000
    description: str = ""


# ---------------------------------------------------------------------------
# Model registry
# ---------------------------------------------------------------------------

MODEL_REGISTRY: Dict[str, ModelInfo] = {
    # ── Bedrock / Claude ───────────────────────────────────────────────
    "claude-opus-4-5": ModelInfo(
        id="claude-opus-4-5",
        provider=Provider.BEDROCK,
        model="us.anthropic.claude-opus-4-5-20251101-v1:0",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=16384,
        context_window=200000,
        description="Claude Opus 4.5 - Most intelligent model with extended thinking",
    ),
    "claude-sonnet-4-5": ModelInfo(
        id="claude-sonnet-4-5",
        provider=Provider.BEDROCK,
        model="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=8192,
        context_window=200000,
        description="Claude Sonnet 4.5 - Latest model with extended thinking",
    ),
    "claude-sonnet-4": ModelInfo(
        id="claude-sonnet-4",
        provider=Provider.BEDROCK,
        model="us.anthropic.claude-sonnet-4-20250514-v1:0",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=8192,
        context_window=200000,
        description="Claude Sonnet 4",
    ),
    "claude-3-opus": ModelInfo(
        id="claude-3-opus",
        provider=Provider.BEDROCK,
        model="anthropic.claude-3-opus-20240229-v1:0",
        supports_vision=True,
        max_tokens=4096,
        context_window=200000,
        description="Claude 3 Opus - Most capable Claude 3",
    ),
    "claude-3-5-sonnet": ModelInfo(
        id="claude-3-5-sonnet",
        provider=Provider.BEDROCK,
        model="anthropic.claude-3-5-sonnet-20241022-v2:0",
        supports_vision=True,
        max_tokens=8192,
        context_window=200000,
        description="Claude 3.5 Sonnet",
    ),

    # ── OpenAI ─────────────────────────────────────────────────────────
    "gpt-4o": ModelInfo(
        id="gpt-4o",
        provider=Provider.OPENAI,
        model="gpt-4o",
        supports_vision=True,
        max_tokens=16384,
        context_window=128000,
        description="GPT-4o - Multimodal flagship model",
    ),
    "gpt-4o-mini": ModelInfo(
        id="gpt-4o-mini",
        provider=Provider.OPENAI,
        model="gpt-4o-mini",
        supports_vision=True,
        max_tokens=16384,
        context_window=128000,
        description="GPT-4o Mini - Faster and cheaper",
    ),
    "gpt-3.5-turbo": ModelInfo(
        id="gpt-3.5-turbo",
        provider=Provider.OPENAI,
        model="gpt-3.5-turbo",
        max_tokens=4096,
        context_window=16385,
        description="GPT-3.5 Turbo - Fast and cost-effective",
    ),
    "o1": ModelInfo(
        id="o1",
        provider=Provider.OPENAI,
        model="o1",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=100000,
        context_window=200000,
        description="o1 - Advanced reasoning model",
    ),
    "o1-mini": ModelInfo(
        id="o1-mini",
        provider=Provider.OPENAI,
        model="o1-mini",
        supports_thinking=True,
        max_tokens=65536,
        context_window=128000,
        description="o1-mini - Faster reasoning model",
    ),

    # ── Azure OpenAI ───────────────────────────────────────────────────
    "azure-gpt-4o": ModelInfo(
        id="azure-gpt-4o",
        provider=Provider.AZURE_OPENAI,
        model="gpt-4o",
        supports_vision=True,
        max_tokens=16384,
        context_window=128000,
        description="GPT-4o via Azure OpenAI",
    ),
    "azure-gpt-4o-mini": ModelInfo(
        id="azure-gpt-4o-mini",
        provider=Provider.AZURE_OPENAI,
        model="gpt-4o-mini",
        supports_vision=True,
        max_tokens=16384,
        context_window=128000,
        description="GPT-4o Mini via Azure OpenAI",
    ),

    # ── Google Gemini ──────────────────────────────────────────────────
    "gemini-3-flash-preview": ModelInfo(
        id="gemini-3-flash-preview",
        provider=Provider.GEMINI,
        model="gemini-3-flash-preview",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=8192,
        context_window=1000000,
        description="Gemini 3 Flash Preview",
    ),
    "gemini-3-pro-preview": ModelInfo(
        id="gemini-3-pro-preview",
        provider=Provider.GEMINI,
        model="gemini-3-pro-preview",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=8192,
        context_window=1000000,
        description="Gemini 3 Pro Preview",
    ),
    "gemini-2.5-pro": ModelInfo(
        id="gemini-2.5-pro",
        provider=Provider.GEMINI,
        model="gemini-2.5-pro",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=8192,
        context_window=1000000,
        description="Gemini 2.5 Pro",
    ),
    "gemini-2.5-flash": ModelInfo(
        id="gemini-2.5-flash",
        provider=Provider.GEMINI,
        model="gemini-2.5-flash",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=8192,
        context_window=1000000,
        description="Gemini 2.5 Flash - best price-performance",
    ),
    "gemini-2.5-flash-lite": ModelInfo(
        id="gemini-2.5-flash-lite",
        provider=Provider.GEMINI,
        model="gemini-2.5-flash-lite",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=8192,
        context_window=1000000,
        description="Gemini 2.5 Flash-Lite - fastest",
    ),
    "gemini-2.0-flash": ModelInfo(
        id="gemini-2.0-flash",
        provider=Provider.GEMINI,
        model="gemini-2.0-flash",
        supports_vision=True,
        max_tokens=8192,
        context_window=1000000,
        description="Gemini 2.0 Flash (deprecated)",
    ),
}

# Default model per provider
DEFAULT_MODELS: Dict[Provider, str] = {
    Provider.BEDROCK: "claude-sonnet-4-5",
    Provider.OPENAI: "gpt-4o",
    Provider.AZURE_OPENAI: "azure-gpt-4o",
    Provider.GEMINI: "gemini-2.5-flash",
}

# Provider detection from environment variables
_PROVIDER_ENV_MAP = {
    Provider.OPENAI: "OPENAI_API_KEY",
    Provider.GEMINI: "GOOGLE_API_KEY",
    Provider.AZURE_OPENAI: "AZURE_OPENAI_API_KEY",
    Provider.BEDROCK: "AWS_ACCESS_KEY_ID",
}


# ---------------------------------------------------------------------------
# init_chat_model provider slug mapping
# ---------------------------------------------------------------------------

_PROVIDER_TO_INIT_SLUG: Dict[Provider, str] = {
    Provider.BEDROCK: "bedrock_converse",
    Provider.OPENAI: "openai",
    Provider.AZURE_OPENAI: "azure_openai",
    Provider.GEMINI: "google_genai",
}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def create_model(
    *,
    model_name: Optional[str] = None,
    provider: Optional[str] = None,
    model: Optional[str] = None,
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
    callbacks: Optional[list] = None,
    enable_prompt_caching: bool = False,
    **kwargs: Any,
) -> BaseChatModel:
    """
    Create a LangChain chat model with explicit provider and model.

    Args:
        model_name: "provider:model" format (e.g., "openai:gpt-4o").
            Alternative to using separate provider and model parameters.
        provider: Provider name ("bedrock", "openai", "google-genai", "azure_openai").
            Use with 'model' parameter for explicit provider specification.
        model: Model ID to use with the provider (e.g., "gpt-4o", "us.anthropic.claude-sonnet-4-5-20250929-v1:0").
            Use with 'provider' parameter.
        temperature: Sampling temperature (0.0-2.0)
        max_tokens: Maximum output tokens
        callbacks: LangChain callback handlers (Langfuse handler auto-added if tracing enabled)
        enable_prompt_caching: If True, wraps the model with a caching proxy that
            automatically injects the provider-appropriate cache marker into every
            SystemMessage. Bedrock uses ``cachePoint: {type: default}``;
            Anthropic uses ``cache_control: {type: ephemeral}``.
        **kwargs: Additional kwargs passed to init_chat_model

    Returns:
        BaseChatModel instance

    Examples:
        # Recommended: Separate provider and model (all args are keyword-only)
        model = create_model(provider="bedrock", model="claude-sonnet-4-5")
        model = create_model(provider="openai", model="gpt-4o", temperature=0.7)

        # With Bedrock prompt caching
        model = create_model(provider="bedrock", model="claude-sonnet-4-5", enable_prompt_caching=True)

        # Alternative: Provider:model string format
        model = create_model(model_name="openai:gpt-4o-mini")

    Note:
        Use list_models() to see available models and their IDs.
    """
    from langchain.chat_models import init_chat_model

    provider_slug: Optional[str] = None
    model_id: str

    # Determine provider and model from input formats
    if provider is not None and model is not None:
        # Check if model is a friendly name that needs lookup
        provider_slug = provider

        # Try to find this model in the registry by friendly name
        # Accept both init_chat_model slugs ("bedrock_converse") and
        # user-friendly provider names ("bedrock")
        found_in_registry = False
        for friendly_name, info in MODEL_REGISTRY.items():
            slug = _PROVIDER_TO_INIT_SLUG[info.provider]
            if friendly_name == model and (slug == provider or info.provider.value == provider):
                # Found it! Use the full model ID and correct slug
                model_id = info.model
                provider_slug = slug
                found_in_registry = True
                break

        if not found_in_registry:
            # Not a friendly name, use as-is (could be full model ID)
            model_id = model
    elif model_name is not None:
        # Provider:model string format
        if ":" in model_name:
            provider_slug, model_id = model_name.split(":", 1)
        else:
            raise ValueError(
                f"Invalid model_name format: '{model_name}'. "
                f"Use 'provider:model' format (e.g., 'openai:gpt-4o') or "
                f"use provider='bedrock', model='claude-sonnet-4-5' parameters."
            )
    else:
        raise ValueError(
            "Must provide either 'model_name' or both 'provider' and 'model' parameters.\n"
            "Examples:\n"
            "  create_model(provider='openai', model='gpt-4o')\n"
            "  create_model('openai:gpt-4o')"
        )

    # Build kwargs
    init_kwargs: Dict[str, Any] = {}
    if temperature is not None:
        init_kwargs["temperature"] = temperature
    if max_tokens is not None:
        init_kwargs["max_tokens"] = max_tokens
    init_kwargs.update(kwargs)

    # Auto-inject Langfuse callback if tracing is enabled
    from penguin.core.tracing import get_callback_handler, is_tracing_enabled

    all_callbacks = list(callbacks or [])
    if is_tracing_enabled():
        try:
            from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
            with ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(get_callback_handler)
                handler = future.result(timeout=3)
            if handler is not None:
                all_callbacks.append(handler)
        except FuturesTimeoutError:
            logger.warning("Langfuse callback creation timed out (3s). Continuing without tracing.")
        except Exception as e:
            # Langfuse configuration errors should not prevent model creation
            logger.warning(f"Failed to initialize Langfuse tracing: {e}. Continuing without tracing.")

    if all_callbacks:
        init_kwargs["callbacks"] = all_callbacks

    base_model = init_chat_model(
        model=model_id,
        model_provider=provider_slug,
        **init_kwargs,
    )

    if enable_prompt_caching:
        from penguin.core.caching import with_prompt_caching
        cache_provider = "bedrock" if "bedrock" in (provider_slug or "") else "anthropic"
        return with_prompt_caching(base_model, provider=cache_provider)

    return base_model


def create_model_from_env(
    *,
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
    callbacks: Optional[list] = None,
    **kwargs: Any,
) -> BaseChatModel:
    """
    Create a model by auto-detecting provider from environment variables.

    Checks ``PENGUIN_LLM_PROVIDER`` first, then falls back to credential detection.

    Returns:
        BaseChatModel instance
    """
    explicit_provider = os.environ.get("PENGUIN_LLM_PROVIDER")
    explicit_model = os.environ.get("PENGUIN_LLM_MODEL")

    if explicit_provider and explicit_model:
        return create_model(
            f"{explicit_provider}:{explicit_model}",
            temperature=temperature,
            max_tokens=max_tokens,
            callbacks=callbacks,
            **kwargs,
        )

    # Auto-detect from credentials
    for provider, env_var in _PROVIDER_ENV_MAP.items():
        if os.environ.get(env_var):
            default_model = DEFAULT_MODELS[provider]
            logger.info(f"Auto-detected provider {provider.value} from {env_var}")
            return create_model(
                explicit_model or default_model,
                temperature=temperature,
                max_tokens=max_tokens,
                callbacks=callbacks,
                **kwargs,
            )

    raise RuntimeError(
        "Cannot auto-detect LLM provider. Set PENGUIN_LLM_PROVIDER and "
        "PENGUIN_LLM_MODEL, or provide credentials for a supported provider "
        "(OPENAI_API_KEY, AWS_ACCESS_KEY_ID, GOOGLE_API_KEY, AZURE_OPENAI_API_KEY)."
    )


# ---------------------------------------------------------------------------
# Registry helpers
# ---------------------------------------------------------------------------

def list_models(provider: Optional[str] = None) -> List[ModelInfo]:
    """
    List available models, optionally filtered by provider.

    Args:
        provider: Provider name to filter by (e.g., "bedrock", "openai")

    Returns:
        List of ModelInfo objects

    Raises:
        ValueError: If provider is invalid
    """
    models = list(MODEL_REGISTRY.values())
    if provider:
        try:
            provider_enum = Provider(provider)
            models = [m for m in models if m.provider == provider_enum]
        except ValueError:
            valid_providers = ", ".join([p.value for p in Provider])
            raise ValueError(
                f"Invalid provider '{provider}'. "
                f"Valid providers: {valid_providers}"
            )
    return models


def get_model_id(friendly_name: str) -> tuple[str, str]:
    """
    Get provider and full model ID from a friendly name.

    This is a convenience helper to avoid typing long model IDs.

    Args:
        friendly_name: Short name like "claude-sonnet-4-5", "gpt-4o", etc.

    Returns:
        Tuple of (provider, full_model_id)

    Raises:
        ValueError: If friendly name not found

    Example:
        provider, model_id = get_model_id("claude-sonnet-4-5")
        # Returns: ("bedrock", "us.anthropic.claude-sonnet-4-5-20250929-v1:0")

        model = create_model(provider=provider, model=model_id)
    """
    if friendly_name not in MODEL_REGISTRY:
        available = ", ".join(list(MODEL_REGISTRY.keys())[:10])
        raise ValueError(
            f"Model '{friendly_name}' not found in registry. "
            f"Available models: {available}... "
            f"Use list_models() to see all models."
        )

    info = MODEL_REGISTRY[friendly_name]
    provider_slug = _PROVIDER_TO_INIT_SLUG[info.provider]
    return (provider_slug, info.model)


def get_model_info(model_name: str) -> Optional[ModelInfo]:
    """Get model metadata by friendly name."""
    return MODEL_REGISTRY.get(model_name)


def get_model_capabilities(model_name: str) -> Dict[str, bool]:
    """Get capability flags for a model."""
    info = MODEL_REGISTRY.get(model_name)
    if info:
        return {
            "vision": info.supports_vision,
            "thinking": info.supports_thinking,
            "tools": info.supports_tools,
        }
    return {"vision": False, "thinking": False, "tools": True}
