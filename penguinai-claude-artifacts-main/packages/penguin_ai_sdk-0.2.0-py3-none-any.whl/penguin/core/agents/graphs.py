"""
Penguin Core Agent State Patterns

Reusable TypedDict definitions and graph patterns for custom LangGraph agents.

Usage:
    from penguin.core.agents.graphs import AgentState
    from langgraph.graph import StateGraph

    graph = StateGraph(AgentState)
    graph.add_node("my_node", my_node_fn)
    ...
"""

from typing import Annotated, Any, Dict, List, Optional, Sequence, TYPE_CHECKING

try:
    from typing import TypedDict
except ImportError:
    from typing_extensions import TypedDict

if TYPE_CHECKING:
    from penguin.core import BaseMessage, add_messages
else:
    from langchain_core.messages import BaseMessage
    from langgraph.graph.message import add_messages


class AgentState(TypedDict):
    """
    Standard agent state for Penguin LangGraph agents.

    The ``messages`` field uses LangGraph's ``add_messages`` reducer so that
    new messages are appended rather than overwritten.
    """

    messages: Annotated[Sequence[BaseMessage], add_messages]
    metadata: Dict[str, Any]
