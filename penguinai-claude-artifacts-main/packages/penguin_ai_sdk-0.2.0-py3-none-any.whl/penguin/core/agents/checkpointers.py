"""
Penguin Core Checkpointer Adapters

Provides convenience factories for LangGraph checkpointers.

Usage:
    from penguin.core.agents.checkpointers import get_memory_checkpointer

    checkpointer = get_memory_checkpointer()
    agent = create_penguin_agent(model, tools, checkpointer=checkpointer)
"""

import logging
from typing import Optional

logger = logging.getLogger(__name__)


def get_memory_checkpointer():
    """
    Get an in-memory checkpointer (for development and testing).

    Returns:
        ``MemorySaver`` instance
    """
    from langgraph.checkpoint.memory import MemorySaver

    return MemorySaver()


def get_postgres_checkpointer(conn_string: Optional[str] = None):
    """
    Get a PostgreSQL checkpointer (for production use).

    Can share the same PostgreSQL instance as Langfuse.

    Args:
        conn_string: PostgreSQL connection string. Defaults to
            ``PENGUIN_CHECKPOINT_DB_URL`` env var or the Langfuse DB.

    Returns:
        ``AsyncPostgresSaver`` instance

    Raises:
        ImportError: If ``langgraph-checkpoint-postgres`` is not installed.
            Install with: ``pip install penguin-ai-sdk[checkpointing]``
    """
    import os

    if conn_string is None:
        conn_string = os.environ.get(
            "PENGUIN_CHECKPOINT_DB_URL",
            "postgresql://langfuse:langfuse@localhost:5432/langfuse",
        )

    try:
        from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

        return AsyncPostgresSaver.from_conn_string(conn_string)
    except ImportError:
        raise ImportError(
            "PostgreSQL checkpointing requires 'langgraph-checkpoint-postgres'. "
            "Install with: pip install penguin-ai-sdk[checkpointing]"
        )
