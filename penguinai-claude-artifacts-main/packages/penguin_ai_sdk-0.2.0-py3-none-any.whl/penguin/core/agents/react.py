"""
Penguin Core React Agent (LangGraph)

Wraps ``langgraph.prebuilt.create_react_agent`` with Penguin conventions:
auto-Langfuse tracing, AgentResponse dataclass, and friendly factory API.

Usage:
    from penguin.core import create_model, create_agent, run_agent, tool

    model = create_model(provider="bedrock", model="claude-sonnet-4-5")

    @tool
    def get_weather(city: str) -> str:
        \"\"\"Get weather for a city.\"\"\"
        return f"72F in {city}"

    agent = create_agent(model, tools=[get_weather])
    result = await run_agent(agent, "What's the weather in NYC?")
    print(result.answer)
"""

import logging
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from penguin.core import (
        BaseChatModel,
        AIMessage,
        BaseMessage,
        BaseCallbackHandler,
        BaseTool,
        CompiledStateGraph,
    )
else:
    # Import at runtime to avoid circular imports
    from langchain_core.language_models import BaseChatModel
    from langchain_core.messages import AIMessage, BaseMessage
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.tools import BaseTool
    from langgraph.graph.state import CompiledStateGraph

logger = logging.getLogger(__name__)


@dataclass
class AgentResponse:
    """
    Response from a Penguin agent run.

    Backward-compatible with the old ``penguin.agents.AgentResponse``.
    """

    answer: str
    tool_calls: List[Dict[str, Any]] = field(default_factory=list)
    iterations: int = 0
    total_tokens: int = 0
    thread_id: Optional[str] = None
    messages: List[Any] = field(default_factory=list)


def create_penguin_agent(
    model: BaseChatModel,
    tools: List[Union[BaseTool, Any]],
    *,
    system_prompt: Optional[str] = None,
    checkpointer: Optional[Any] = None,
    callbacks: Optional[List[BaseCallbackHandler]] = None,
) -> CompiledStateGraph:
    """
    Create a LangGraph React agent with Penguin defaults.

    Args:
        model: LangChain BaseChatModel (from ``create_model``).
            Note: If the model was created with ``create_model()`` and tracing is
            enabled, it already has a Langfuse callback attached.
        tools: List of LangChain tools (or old Penguin tools - auto-adapted)
        system_prompt: Optional system message prepended to every invocation
        checkpointer: LangGraph checkpointer for multi-turn memory.
            Defaults to ``MemorySaver`` (in-memory).
        callbacks: Additional LangChain callbacks to attach to the agent.
            These are combined with auto-injected callbacks (e.g., Langfuse tracing).
            Callback precedence: user-provided callbacks + auto-injected Langfuse callback
            (if tracing is enabled).

    Returns:
        Compiled LangGraph agent (``CompiledStateGraph``)

    Note:
        Callbacks can be provided at three levels:
        1. Model-level: via ``create_model(callbacks=[...])`` - these are already
           attached to the model and will fire for all model calls
        2. Agent-level: via this function's ``callbacks`` parameter - these will
           fire for agent-level events (agent start/end, tool calls, etc.)
        3. Run-level: via ``run_agent(callbacks=[...])`` - these will fire only
           for that specific agent invocation

        All three levels are combined. If you provide callbacks at multiple levels,
        all of them will fire (in the order: model callbacks, agent callbacks, run callbacks).
    """
    from langgraph.prebuilt import create_react_agent
    from langgraph.checkpoint.memory import MemorySaver

    from penguin.core.tools import adapt_penguin_tools

    # Adapt any old-style Penguin tools
    adapted_tools = adapt_penguin_tools(tools)

    # Default to in-memory checkpointer for multi-turn support
    if checkpointer is None:
        checkpointer = MemorySaver()

    # Build callback list, injecting Langfuse if enabled
    all_callbacks = list(callbacks or [])
    from penguin.core.tracing import get_callback_handler, is_tracing_enabled

    if is_tracing_enabled():
        try:
            from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
            with ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(get_callback_handler)
                handler = future.result(timeout=3)
            if handler is not None:
                all_callbacks.append(handler)
        except FuturesTimeoutError:
            logger.warning("Langfuse callback creation timed out (3s). Continuing without tracing.")
        except Exception as e:
            # Langfuse configuration errors should not prevent agent creation
            logger.warning(f"Failed to initialize Langfuse tracing: {e}. Continuing without tracing.")

    # Build agent kwargs
    agent_kwargs: Dict[str, Any] = {}
    if system_prompt:
        agent_kwargs["prompt"] = system_prompt
    if checkpointer:
        agent_kwargs["checkpointer"] = checkpointer

    agent = create_react_agent(
        model=model,
        tools=adapted_tools,
        **agent_kwargs,
    )

    # Stash callbacks and metadata for run_agent to use
    agent._penguin_callbacks = all_callbacks
    agent._penguin_checkpointer = checkpointer

    return agent


async def run_agent(
    agent: CompiledStateGraph,
    prompt: str,
    *,
    thread_id: Optional[str] = None,
    max_iterations: int = 25,
    callbacks: Optional[List[BaseCallbackHandler]] = None,
) -> AgentResponse:
    """
    Run a Penguin agent and return an ``AgentResponse``.

    Args:
        agent: Compiled LangGraph agent from ``create_penguin_agent``
        prompt: User message
        thread_id: Thread ID for multi-turn conversations. Auto-generated if None.
        max_iterations: Maximum LangGraph recursion limit
        callbacks: Additional callbacks for this specific run.
            These are merged with callbacks from ``create_penguin_agent()``.
            Order: agent-level callbacks (from create_penguin_agent) + run-level callbacks (this parameter).

    Returns:
        AgentResponse with the agent's answer, tool calls, and metadata
    """
    from langchain_core.messages import HumanMessage

    if thread_id is None:
        thread_id = str(uuid.uuid4())

    # Merge callbacks
    all_callbacks = list(getattr(agent, "_penguin_callbacks", []) or [])
    if callbacks:
        all_callbacks.extend(callbacks)

    config: Dict[str, Any] = {
        "configurable": {"thread_id": thread_id},
        "recursion_limit": max_iterations,
    }
    if all_callbacks:
        config["callbacks"] = all_callbacks

    # Invoke the agent
    result = await agent.ainvoke(
        {"messages": [HumanMessage(content=prompt)]},
        config=config,
    )

    # Extract response from LangGraph state
    messages: List[BaseMessage] = result.get("messages", [])

    # Find the final AI answer
    answer = ""
    tool_calls_log: List[Dict[str, Any]] = []
    iterations = 0
    total_tokens = 0

    for msg in messages:
        if isinstance(msg, AIMessage):
            iterations += 1
            if msg.tool_calls:
                for tc in msg.tool_calls:
                    # Handle both dict and object types (LangChain may return either)
                    if isinstance(tc, dict):
                        tool_name = tc.get("name", "")
                        tool_args = tc.get("args", {})
                    else:
                        tool_name = getattr(tc, "name", "")
                        tool_args = getattr(tc, "args", {})
                    tool_calls_log.append({
                        "tool": tool_name,
                        "input": tool_args,
                    })
            # Token usage from response metadata
            usage = msg.response_metadata.get("usage", {}) if msg.response_metadata else {}
            total_tokens += usage.get("total_tokens", 0)

    # Last AI message is the final answer
    for msg in reversed(messages):
        if isinstance(msg, AIMessage) and msg.content and not msg.tool_calls:
            answer = msg.content if isinstance(msg.content, str) else str(msg.content)
            break

    return AgentResponse(
        answer=answer,
        tool_calls=tool_calls_log,
        iterations=iterations,
        total_tokens=total_tokens,
        thread_id=thread_id,
        messages=messages,
    )
