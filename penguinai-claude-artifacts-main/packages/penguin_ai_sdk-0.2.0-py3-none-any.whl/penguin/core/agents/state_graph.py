"""
Penguin Core Custom State Graphs (LangGraph)

Wraps ``langgraph.graph.StateGraph`` with Penguin conventions:
auto-Langfuse tracing, checkpointing defaults, and a clean factory API.

Usage:
    from penguin.core import create_state_graph, run_graph, START, END

    graph = create_state_graph(MyState)
    graph.add_node("step1", step1_fn)
    graph.add_node("step2", step2_fn)
    graph.add_edge(START, "step1")
    graph.add_edge("step1", "step2")
    graph.add_edge("step2", END)

    compiled = graph.compile()
    result = await run_graph(compiled, {"input": "hello"})
    print(result.state)
"""

import logging
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Type, Union, TYPE_CHECKING

from langgraph.types import StateSnapshot

if TYPE_CHECKING:
    from penguin.core import BaseCallbackHandler, StateGraph, CompiledStateGraph
else:
    # Import at runtime to avoid circular imports
    from langgraph.graph import StateGraph
    from langgraph.graph.state import CompiledStateGraph
    from langchain_core.callbacks import BaseCallbackHandler

logger = logging.getLogger(__name__)


@dataclass
class GraphResponse:
    """
    Response from a custom state graph run.

    Unlike ``AgentResponse`` (which assumes a chat agent with messages),
    this is generic — it returns the full final state from the graph.
    """

    state: Dict[str, Any] = field(default_factory=dict)
    output: Any = None
    thread_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class PenguinStateGraph:
    """
    Wrapper around LangGraph's ``StateGraph`` that auto-injects
    Langfuse tracing and checkpointing defaults at compile time.

    All builder methods delegate to the underlying ``StateGraph`` and
    return ``self`` for method chaining.
    """

    def __init__(
        self,
        state_schema: Type,
        *,
        callbacks: Optional[List[BaseCallbackHandler]] = None,
        **kwargs: Any,
    ) -> None:
        self._graph = StateGraph(state_schema, **kwargs)
        self._callbacks = list(callbacks or [])

    @property
    def graph(self) -> StateGraph:
        """Escape hatch to the raw LangGraph StateGraph."""
        return self._graph

    def add_node(self, node: str, action: Any, *, retry: Any = None, retry_policy: Any = None, **kwargs: Any) -> "PenguinStateGraph":
        if retry_policy is not None:
            kwargs["retry_policy"] = retry_policy
        elif retry is not None:
            kwargs["retry_policy"] = retry
        self._graph.add_node(node, action, **kwargs)
        return self

    def add_edge(self, start_key: str, end_key: str) -> "PenguinStateGraph":
        self._graph.add_edge(start_key, end_key)
        return self

    def add_conditional_edges(
        self,
        source: str,
        path: Any,
        path_map: Optional[Dict[str, str]] = None,
        **kwargs: Any,
    ) -> "PenguinStateGraph":
        if path_map is not None:
            self._graph.add_conditional_edges(source, path, path_map, **kwargs)
        else:
            self._graph.add_conditional_edges(source, path, **kwargs)
        return self

    def add_sequence(self, nodes: Sequence[Any]) -> "PenguinStateGraph":
        self._graph.add_sequence(nodes)
        return self

    def set_entry_point(self, key: str) -> "PenguinStateGraph":
        self._graph.set_entry_point(key)
        return self

    def set_finish_point(self, key: str) -> "PenguinStateGraph":
        self._graph.set_finish_point(key)
        return self

    def compile(
        self,
        *,
        checkpointer: Optional[Any] = None,
        interrupt_before: Optional[List[str]] = None,
        interrupt_after: Optional[List[str]] = None,
        debug: bool = False,
        name: Optional[str] = None,
    ) -> CompiledStateGraph:
        """
        Compile the graph with Penguin defaults.

        - Defaults ``checkpointer`` to ``MemorySaver``
        - Auto-injects Langfuse callback handler (with 3s timeout)
        """
        from langgraph.checkpoint.memory import MemorySaver

        if checkpointer is None:
            checkpointer = MemorySaver()

        # Build callback list, injecting Langfuse if enabled
        all_callbacks = list(self._callbacks)
        from penguin.core.tracing import get_callback_handler, is_tracing_enabled

        if is_tracing_enabled():
            try:
                from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
                with ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(get_callback_handler)
                    handler = future.result(timeout=3)
                if handler is not None:
                    all_callbacks.append(handler)
            except FuturesTimeoutError:
                logger.warning("Langfuse callback creation timed out (3s). Continuing without tracing.")
            except Exception as e:
                logger.warning(f"Failed to initialize Langfuse tracing: {e}. Continuing without tracing.")

        compile_kwargs: Dict[str, Any] = {"checkpointer": checkpointer}
        if interrupt_before is not None:
            compile_kwargs["interrupt_before"] = interrupt_before
        if interrupt_after is not None:
            compile_kwargs["interrupt_after"] = interrupt_after
        if debug:
            compile_kwargs["debug"] = debug
        if name is not None:
            compile_kwargs["name"] = name

        compiled = self._graph.compile(**compile_kwargs)

        # Stash callbacks for run_graph to pick up
        compiled._penguin_callbacks = all_callbacks

        return compiled


def create_state_graph(
    state_schema: Type,
    *,
    callbacks: Optional[List[BaseCallbackHandler]] = None,
) -> PenguinStateGraph:
    """
    Factory to create a ``PenguinStateGraph``.

    Args:
        state_schema: TypedDict or dataclass defining the graph state.
        callbacks: Additional LangChain callbacks to inject at compile time.

    Returns:
        PenguinStateGraph builder instance.
    """
    return PenguinStateGraph(state_schema, callbacks=callbacks)


def get_graph_state(
    graph: CompiledStateGraph,
    thread_id: str,
    *,
    checkpoint_id: Optional[str] = None,
) -> StateSnapshot:
    """
    Inspect the current state of a compiled graph for a given thread.

    Args:
        graph: Compiled LangGraph state graph (must have a checkpointer).
        thread_id: Thread ID to inspect.
        checkpoint_id: Optional checkpoint ID for a specific historical state.

    Returns:
        StateSnapshot with ``.values``, ``.next``, ``.tasks``, ``.created_at``.
    """
    config: Dict[str, Any] = {"configurable": {"thread_id": thread_id}}
    if checkpoint_id is not None:
        config["configurable"]["checkpoint_id"] = checkpoint_id
    return graph.get_state(config)


def update_graph_state(
    graph: CompiledStateGraph,
    thread_id: str,
    values: Dict[str, Any],
    *,
    as_node: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Update the state of a compiled graph for a given thread.

    Useful for human-in-the-loop corrections, injecting data, or creating
    branch points for time-travel.

    Args:
        graph: Compiled LangGraph state graph (must have a checkpointer).
        thread_id: Thread ID whose state to update.
        values: State values to merge.
        as_node: Pretend the update came from this node (affects ``next``).

    Returns:
        The updated config dict.
    """
    config: Dict[str, Any] = {"configurable": {"thread_id": thread_id}}
    return graph.update_state(config, values, as_node=as_node)


def get_graph_history(
    graph: CompiledStateGraph,
    thread_id: str,
    *,
    limit: Optional[int] = None,
) -> List[StateSnapshot]:
    """
    Get the checkpoint history for a thread (newest first).

    Enables time-travel: pick a historical ``checkpoint_id`` and resume
    from that point using ``get_graph_state(..., checkpoint_id=...)``.

    Args:
        graph: Compiled LangGraph state graph (must have a checkpointer).
        thread_id: Thread ID to get history for.
        limit: Max number of snapshots to return.

    Returns:
        List of StateSnapshot objects, newest first.
    """
    config: Dict[str, Any] = {"configurable": {"thread_id": thread_id}}
    snapshots = list(graph.get_state_history(config))
    if limit is not None:
        snapshots = snapshots[:limit]
    return snapshots


async def run_graph(
    graph: CompiledStateGraph,
    inputs: Dict[str, Any],
    *,
    thread_id: Optional[str] = None,
    max_iterations: int = 50,
    callbacks: Optional[List[BaseCallbackHandler]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    output_key: Optional[str] = None,
) -> GraphResponse:
    """
    Run a compiled state graph and return a ``GraphResponse``.

    Args:
        graph: Compiled LangGraph state graph.
        inputs: Initial state values for the graph.
        thread_id: Thread ID for stateful execution. Auto-generated if None.
        max_iterations: Maximum LangGraph recursion limit.
        callbacks: Additional callbacks for this specific run.
        metadata: Optional metadata dict propagated to LangChain callbacks.
            Only needed if you want Langfuse session grouping — pass
            ``session.config.get("metadata", {})`` from ``PenguinTracer.session()``
            to propagate ``langfuse_session_id``, ``langfuse_user_id``, and tags.
        output_key: If set, extract this key from the final state as ``output``.

    Returns:
        GraphResponse with the final state and optional extracted output.
    """
    if thread_id is None:
        thread_id = str(uuid.uuid4())

    # Use run-level callbacks if provided; fall back to graph-level auto-injected ones.
    # We do NOT merge both because they would contain duplicate Langfuse handlers
    # (one from compile() auto-injection, one from the user's session.callbacks),
    # causing every LLM call to be traced multiple times.
    if callbacks:
        all_callbacks = list(callbacks)
    else:
        all_callbacks = list(getattr(graph, "_penguin_callbacks", []) or [])

    config: Dict[str, Any] = {
        "configurable": {"thread_id": thread_id},
        "recursion_limit": max_iterations,
    }
    if all_callbacks:
        config["callbacks"] = all_callbacks
    if metadata:
        config["metadata"] = metadata

    result = await graph.ainvoke(inputs, config=config)

    # Extract output if requested
    output = None
    if output_key is not None and isinstance(result, dict):
        output = result.get(output_key)

    return GraphResponse(
        state=result if isinstance(result, dict) else {},
        output=output,
        thread_id=thread_id,
    )
