"""
Penguin Core Callbacks

LangChain callback handlers for security, guardrails, and tracing.
"""

from typing import List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from penguin.core import BaseCallbackHandler
else:
    from langchain_core.callbacks import BaseCallbackHandler

from .security import (
    PromptInjectionCallback,
    OutputSafetyCallback,
    SecurityViolation,
)
from .guardrails import (
    GuardrailCallback,
    GuardrailViolation,
    ToolBlockingCallback,
    RateLimitCallback,
)
from .local_trace import (
    LocalTraceCallback,
    read_trace_file,
    list_trace_files,
    analyze_trace_file,
    cleanup_old_traces,
)


def create_security_callbacks(
    block_injections: bool = True,
    filter_output: bool = True,
    additional_injection_patterns: Optional[list] = None,
    additional_output_patterns: Optional[list] = None,
) -> List[BaseCallbackHandler]:
    """
    Create a list of security callback handlers.

    Args:
        block_injections: Include prompt injection detection
        filter_output: Include output safety filtering
        additional_injection_patterns: Extra patterns for injection detection
        additional_output_patterns: Extra patterns for output filtering

    Returns:
        List of callback handlers
    """
    callbacks: List[BaseCallbackHandler] = []

    if block_injections:
        callbacks.append(
            PromptInjectionCallback(
                additional_patterns=additional_injection_patterns,
                block_on_detection=True,
                log_detections=True,
            )
        )

    if filter_output:
        callbacks.append(
            OutputSafetyCallback(
                additional_patterns=additional_output_patterns,
                block_on_detection=False,
                log_detections=True,
            )
        )

    return callbacks


def create_default_callbacks(
    *,
    enable_security: bool = True,
    enable_tracing: bool = True,
    session_id: Optional[str] = None,
    user_id: Optional[str] = None,
) -> List[BaseCallbackHandler]:
    """
    Create a combined list of all default Penguin callbacks.

    Args:
        enable_security: Include security callbacks
        enable_tracing: Include Langfuse tracing callback
        session_id: Langfuse session ID
        user_id: Langfuse user ID

    Returns:
        List of callback handlers
    """
    callbacks: List[BaseCallbackHandler] = []

    if enable_security:
        callbacks.extend(create_security_callbacks())

    if enable_tracing:
        from penguin.core.tracing import get_callback_handler, is_tracing_enabled

        if is_tracing_enabled():
            handler = get_callback_handler(
                session_id=session_id,
                user_id=user_id,
            )
            if handler is not None:
                callbacks.append(handler)

    return callbacks


__all__ = [
    # Security
    "PromptInjectionCallback",
    "OutputSafetyCallback",
    "SecurityViolation",
    # Guardrails
    "GuardrailCallback",
    "GuardrailViolation",
    "ToolBlockingCallback",
    "RateLimitCallback",
    # Local trace
    "LocalTraceCallback",
    "read_trace_file",
    "list_trace_files",
    "analyze_trace_file",
    "cleanup_old_traces",
    # Factories
    "create_security_callbacks",
    "create_default_callbacks",
]
