"""
Guardrail callback handlers for LangChain.

Ports guardrail logic from ``penguin.middleware.guardrails`` into
LangChain's callback system.

Usage:
    from penguin.core.callbacks.guardrails import GuardrailCallback

    callback = GuardrailCallback(max_input_length=5000)
    model.invoke(messages, config={"callbacks": [callback]})
"""

import logging
import re
import threading
import time
from typing import Any, Dict, List, Optional, Set, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from penguin.core import BaseCallbackHandler, BaseMessage
else:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.messages import BaseMessage

logger = logging.getLogger(__name__)


def _extract_text_from_message(msg: BaseMessage) -> str:
    """
    Extract text content from a LangChain message.

    Handles both simple string content and multi-part content (e.g., text + images).
    """
    if isinstance(msg.content, str):
        return msg.content
    elif isinstance(msg.content, list):
        # Multi-part content - extract text parts only
        text_parts = []
        for part in msg.content:
            if isinstance(part, dict) and part.get("type") == "text":
                text_parts.append(part.get("text", ""))
            elif isinstance(part, str):
                text_parts.append(part)
        return " ".join(text_parts)
    else:
        return str(msg.content)


class GuardrailViolation(Exception):
    """Raised when a guardrail check fails."""

    def __init__(
        self,
        message: str,
        guardrail: str,
        details: Optional[dict] = None,
    ):
        self.message = message
        self.guardrail = guardrail
        self.details = details or {}
        super().__init__(message)


class GuardrailCallback(BaseCallbackHandler):
    """
    Enforces input guardrails via ``on_chat_model_start``.

    Checks:
    - Maximum total input length
    - Maximum message count
    - Blocked regex patterns
    """

    def __init__(
        self,
        max_input_length: Optional[int] = None,
        max_message_count: Optional[int] = None,
        blocked_patterns: Optional[List[str]] = None,
    ):
        self.max_input_length = max_input_length
        self.max_message_count = max_message_count
        # Convert string patterns to compiled regex patterns
        self.blocked_patterns: List[re.Pattern[str]] = []
        if blocked_patterns:
            self.blocked_patterns = [
                re.compile(p, re.IGNORECASE) for p in blocked_patterns
            ]

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[BaseMessage]],
        **kwargs: Any,
    ) -> None:
        for message_list in messages:
            # Check message count
            if self.max_message_count is not None:
                if len(message_list) > self.max_message_count:
                    raise GuardrailViolation(
                        f"Message count exceeds limit: {len(message_list)} > {self.max_message_count}",
                        guardrail="max_message_count",
                        details={
                            "actual": len(message_list),
                            "limit": self.max_message_count,
                        },
                    )

            # Check total input length
            if self.max_input_length is not None:
                total_length = sum(
                    len(_extract_text_from_message(m))
                    for m in message_list
                )
                if total_length > self.max_input_length:
                    raise GuardrailViolation(
                        f"Input exceeds max length: {total_length} > {self.max_input_length}",
                        guardrail="max_input_length",
                        details={
                            "actual": total_length,
                            "limit": self.max_input_length,
                        },
                    )

            # Check blocked patterns
            for msg in message_list:
                content = _extract_text_from_message(msg)
                for pattern in self.blocked_patterns:
                    match = pattern.search(content)
                    if match:
                        raise GuardrailViolation(
                            f"Input matches blocked pattern: {pattern.pattern}",
                            guardrail="blocked_pattern",
                            details={
                                "pattern": pattern.pattern,
                                "match": match.group(),
                            },
                        )


class ToolBlockingCallback(BaseCallbackHandler):
    """
    Blocks specific tools from being executed via ``on_tool_start``.
    """

    def __init__(
        self,
        blocked_tools: List[str],
        on_blocked: str = "raise",
    ):
        self.blocked_tools: Set[str] = set(blocked_tools)
        self.on_blocked = on_blocked

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        **kwargs: Any,
    ) -> Any:
        """
        Check if the tool is blocked before execution.

        Returns:
            None normally, or raises GuardrailViolation if blocked
        """
        tool_name = serialized.get("name", "")
        if tool_name in self.blocked_tools:
            if self.on_blocked == "raise":
                raise GuardrailViolation(
                    f"Tool '{tool_name}' is blocked by guardrails",
                    guardrail="blocked_tool",
                    details={"tool_name": tool_name},
                )
            else:
                logger.warning(f"Blocked tool call to '{tool_name}' (skip mode)")
        return None


class RateLimitCallback(BaseCallbackHandler):
    """
    Simple rate limiting via ``on_chat_model_start``.

    Tracks call timestamps and raises ``GuardrailViolation`` if the
    per-minute limit is exceeded.

    Thread-safe: uses a lock to protect the call_times list.
    """

    def __init__(self, max_calls_per_minute: int = 60):
        self.max_calls = max_calls_per_minute
        self.call_times: List[float] = []
        self._lock = threading.Lock()

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[BaseMessage]],
        **kwargs: Any,
    ) -> None:
        with self._lock:
            now = time.time()
            self.call_times = [t for t in self.call_times if now - t < 60]

            if len(self.call_times) >= self.max_calls:
                oldest = self.call_times[0]
                wait = 60 - (now - oldest)
                raise GuardrailViolation(
                    f"Rate limit exceeded. Try again in {wait:.1f} seconds",
                    guardrail="rate_limit",
                    details={
                        "max_calls_per_minute": self.max_calls,
                        "retry_after_seconds": wait,
                    },
                )

            self.call_times.append(now)
