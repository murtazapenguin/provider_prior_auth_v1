"""
Security callback handlers for LangChain.

Ports the prompt injection and output safety patterns from
``penguin.middleware.security`` into LangChain's callback system.

Usage:
    from penguin.core.callbacks import create_security_callbacks

    callbacks = create_security_callbacks()
    model.invoke(messages, config={"callbacks": callbacks})
"""

import logging
import re
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from penguin.core import BaseCallbackHandler, BaseMessage
else:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.messages import BaseMessage

logger = logging.getLogger(__name__)


def _extract_text_from_message(msg: BaseMessage) -> str:
    """
    Extract text content from a LangChain message.

    Handles both simple string content and multi-part content (e.g., text + images).
    """
    if isinstance(msg.content, str):
        return msg.content
    elif isinstance(msg.content, list):
        # Multi-part content - extract text parts only
        text_parts = []
        for part in msg.content:
            if isinstance(part, dict) and part.get("type") == "text":
                text_parts.append(part.get("text", ""))
            elif isinstance(part, str):
                text_parts.append(part)
        return " ".join(text_parts)
    else:
        return str(msg.content)


class SecurityViolation(Exception):
    """Raised when a security check fails."""

    def __init__(
        self,
        message: str,
        pattern: Optional[str] = None,
        category: Optional[str] = None,
        severity: str = "high",
    ):
        self.message = message
        self.pattern = pattern
        self.category = category
        self.severity = severity
        super().__init__(message)


class PromptInjectionCallback(BaseCallbackHandler):
    """
    Detects and blocks prompt injection attempts in input messages.

    Fires on ``on_chat_model_start`` to inspect messages before they
    reach the LLM.

    Ports all patterns from ``penguin.middleware.security.PromptInjectionMiddleware``.
    """

    DEFAULT_PATTERNS: List[Tuple[str, str]] = [
        # Instruction override
        (
            r"ignore\s+(all\s+)?(your\s+)?(previous\s+|original\s+|system\s+)?(instructions|prompts|rules|guidelines)",
            "instruction_override",
        ),
        (
            r"disregard\s+(all\s+)?(your\s+)?(previous\s+|prior\s+|original\s+|system\s+)?(instructions|rules)",
            "instruction_override",
        ),
        (
            r"override\s+(all\s+)?(your|the)\s+(system\s+)?(instructions|rules|guidelines|constraints)",
            "instruction_override",
        ),
        # Role manipulation
        (r"you\s+are\s+now\s+(an?\s+)?(evil|unfiltered|unrestricted|uncensored)", "role_manipulation"),
        (r"pretend\s+(you\s+are|to\s+be)\s+(an?\s+)?(evil|unfiltered|unrestricted|jailbroken)", "role_manipulation"),
        (r"from\s+now\s+on,?\s+you\s+(have\s+no|don't\s+have\s+any)\s+(restrictions|limits|rules)", "role_manipulation"),
        # Mode switching
        (r"\b(jailbreak|jailbroken)\s*(mode)?", "mode_switch"),
        (r"\bDAN\s*(mode)?", "mode_switch"),
        (r"\b(STAN|DUDE|AIM)\s*(mode)?", "mode_switch"),
        (r"unrestricted\s+mode", "mode_switch"),
        (r"developer\s+mode", "mode_switch"),
        (r"god\s+mode", "mode_switch"),
        # System prompt extraction
        (
            r"(show|reveal|display|repeat|print|output|leak)\s+(me\s+)?(your\s+)?system\s+prompt",
            "prompt_extraction",
        ),
        (
            r"what\s+(are|is)\s+your\s+system\s+(prompt|instructions)",
            "prompt_extraction",
        ),
        (r"(copy|paste|write)\s+(out\s+)?your\s+system\s+prompt", "prompt_extraction"),
        # Delimiter injection
        (r"\[INST\].*\[/INST\]", "delimiter_injection"),
        (r"<\|im_start\|>|<\|im_end\|>", "delimiter_injection"),
        (r"<\|system\|>|<\|user\|>|<\|assistant\|>", "delimiter_injection"),
        (r"<<SYS>>.*<</SYS>>", "delimiter_injection"),
        # Encoding bypass
        (r"execute\s+(the\s+)?following\s+(base64|encoded|encrypted)\s+(payload|code|script)", "encoding_bypass"),
    ]

    def __init__(
        self,
        additional_patterns: Optional[List[Tuple[str, str]]] = None,
        block_on_detection: bool = True,
        log_detections: bool = True,
    ):
        self.patterns: List[Tuple[re.Pattern, str]] = [
            (re.compile(p, re.IGNORECASE), cat)
            for p, cat in self.DEFAULT_PATTERNS
        ]
        if additional_patterns:
            self.patterns.extend([
                (re.compile(p, re.IGNORECASE), cat)
                for p, cat in additional_patterns
            ])
        self.block_on_detection = block_on_detection
        self.log_detections = log_detections

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[BaseMessage]],
        **kwargs: Any,
    ) -> None:
        """Inspect messages before they reach the LLM."""
        for message_list in messages:
            for msg in message_list:
                content = _extract_text_from_message(msg)
                if not content:
                    continue

                for pattern, category in self.patterns:
                    match = pattern.search(content)
                    if match:
                        if self.log_detections:
                            logger.warning(
                                f"Prompt injection detected: category={category}, "
                                f"match={match.group()!r}"
                            )
                        if self.block_on_detection:
                            raise SecurityViolation(
                                message=f"Potential prompt injection detected: {category}",
                                pattern=pattern.pattern,
                                category=category,
                                severity="high",
                            )


class OutputSafetyCallback(BaseCallbackHandler):
    """
    Filters unsafe content from LLM responses.

    Fires on ``on_llm_end`` to inspect generated output.

    Ports patterns from ``penguin.middleware.security.OutputSafetyMiddleware``.
    """

    DEFAULT_PATTERNS: List[Tuple[str, str]] = [
        # Harmful instructions
        (
            r"(how\s+to|instructions\s+for|steps\s+to)\s+(make|build|create|construct)\s+(a\s+)?(bomb|weapon|explosive|poison)",
            "harmful_instructions",
        ),
        (
            r"(synthesize|manufacture|produce)\s+(illegal\s+)?(drugs|narcotics|methamphetamine)",
            "harmful_instructions",
        ),
        # Credential/secret exposure
        (
            r"(api[_\s]?key|api[_\s]?secret|access[_\s]?token)\s*[:=]\s*['\"]?[a-zA-Z0-9_\-]{20,}",
            "credential_exposure",
        ),
        (
            r"(password|passwd|pwd)\s*[:=]\s*['\"]?[^\s'\"]{8,}",
            "credential_exposure",
        ),
        (
            r"(bearer|authorization)\s*[:=]\s*['\"]?[a-zA-Z0-9_\-\.]{20,}",
            "credential_exposure",
        ),
        # System information leakage
        (
            r"(my\s+)?system\s+(prompt|instructions)\s*(is|are|:)",
            "system_leak",
        ),
        (
            r"(here\s+is|here\'s)\s+(my|the)\s+(system\s+)?(prompt|instructions)",
            "system_leak",
        ),
    ]

    def __init__(
        self,
        additional_patterns: Optional[List[Tuple[str, str]]] = None,
        block_on_detection: bool = False,
        log_detections: bool = True,
    ):
        self.patterns: List[Tuple[re.Pattern, str]] = [
            (re.compile(p, re.IGNORECASE), cat)
            for p, cat in self.DEFAULT_PATTERNS
        ]
        if additional_patterns:
            self.patterns.extend([
                (re.compile(p, re.IGNORECASE), cat)
                for p, cat in additional_patterns
            ])
        self.block_on_detection = block_on_detection
        self.log_detections = log_detections

    def on_llm_end(self, response: Any, **kwargs: Any) -> None:
        """Inspect LLM output for unsafe content."""
        # Extract text from LLMResult
        for generation_list in getattr(response, "generations", []):
            for generation in generation_list:
                text = getattr(generation, "text", "")
                if not text:
                    msg = getattr(generation, "message", None)
                    if msg:
                        text = _extract_text_from_message(msg)

                if not text:
                    continue

                for pattern, category in self.patterns:
                    if pattern.search(text):
                        if self.log_detections:
                            logger.warning(
                                f"Unsafe output detected: category={category}"
                            )
                        if self.block_on_detection:
                            raise SecurityViolation(
                                message=f"Unsafe content detected in output: {category}",
                                pattern=pattern.pattern,
                                category=category,
                                severity="high",
                            )
