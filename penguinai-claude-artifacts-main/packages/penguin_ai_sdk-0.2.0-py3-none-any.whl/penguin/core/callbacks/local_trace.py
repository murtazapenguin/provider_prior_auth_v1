"""
Local JSON trace storage callback for LangChain.

Writes session traces to JSONL files in ``~/.penguin/traces/`` as a fallback
when Langfuse is unavailable (or always, when configured).

Each session produces one ``.jsonl`` file with one JSON object per line.
The format is append-friendly and crash-resilient.

Usage:
    from penguin.core.callbacks.local_trace import LocalTraceCallback

    cb = LocalTraceCallback(session_id="case-001", user_id="clinician-42")
    with cb:
        model.invoke(messages, config={"callbacks": [cb]})

    # Read traces back
    from penguin.core.callbacks.local_trace import read_trace_file, list_trace_files
    for f in list_trace_files():
        events = read_trace_file(f)
"""

import json
import logging
import os
import re
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from penguin.core import AgentAction, AgentFinish, BaseCallbackHandler, BaseMessage, LLMResult
else:
    from langchain_core.agents import AgentAction, AgentFinish
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.messages import BaseMessage
    from langchain_core.outputs import LLMResult

logger = logging.getLogger(__name__)

DEFAULT_TRACE_DIR = Path.home() / ".penguin" / "traces"


def _sanitize_filename(name: str) -> str:
    """Replace non-alphanumeric characters with underscores."""
    return re.sub(r"[^a-zA-Z0-9_\-]", "_", name)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _now_ms() -> float:
    return time.monotonic() * 1000


def _serialize_messages(messages: Sequence[Sequence[BaseMessage]]) -> List[List[Dict[str, Any]]]:
    """Convert LangChain messages to serializable dicts."""
    result = []
    for msg_list in messages:
        batch = []
        for msg in msg_list:
            batch.append({
                "type": msg.type,
                "content": msg.content if isinstance(msg.content, str) else str(msg.content),
            })
        result.append(batch)
    return result


class LocalTraceCallback(BaseCallbackHandler):
    """Writes trace events to a JSONL file.

    Thread-safe. All errors are caught and logged so user code is never
    affected by tracing failures.

    Use as a context manager to get automatic ``session_start``/``session_end``
    events and proper file cleanup.
    """

    def __init__(
        self,
        session_id: str,
        user_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        trace_dir: Optional[Union[str, Path]] = None,
    ):
        self.session_id = session_id
        self.user_id = user_id
        self.tags = tags or []
        self.metadata = metadata or {}

        self._trace_dir = Path(trace_dir) if trace_dir else DEFAULT_TRACE_DIR
        self._lock = threading.Lock()
        self._file_handle = None
        self._file_path: Optional[Path] = None
        self._start_time: Optional[float] = None
        self._run_starts: Dict[str, float] = {}  # run_id -> monotonic ms

        # Open file immediately
        self._open_file()

    @property
    def file_path(self) -> Optional[Path]:
        return self._file_path

    def _open_file(self) -> None:
        """Create trace directory and open the JSONL file."""
        try:
            self._trace_dir.mkdir(parents=True, exist_ok=True)
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            safe_id = _sanitize_filename(self.session_id)
            filename = f"{safe_id}_{timestamp}.jsonl"
            self._file_path = self._trace_dir / filename
            self._file_handle = open(self._file_path, "a", encoding="utf-8")
        except Exception as e:
            logger.debug(f"LocalTraceCallback: failed to open trace file: {e}")
            self._file_handle = None

    def _write_event(self, event: Dict[str, Any]) -> None:
        """Write a single event as one JSON line. Thread-safe."""
        if self._file_handle is None:
            return
        try:
            with self._lock:
                self._file_handle.write(json.dumps(event, default=str) + "\n")
                self._file_handle.flush()
        except Exception as e:
            logger.debug(f"LocalTraceCallback: write failed: {e}")

    def _record_run_start(self, run_id: str) -> None:
        self._run_starts[str(run_id)] = _now_ms()

    def _calc_duration(self, run_id: str) -> Optional[float]:
        start = self._run_starts.pop(str(run_id), None)
        if start is not None:
            return round(_now_ms() - start, 2)
        return None

    # -- Context manager --

    def __enter__(self) -> "LocalTraceCallback":
        self._start_time = _now_ms()
        self._write_event({
            "event": "session_start",
            "timestamp": _now_iso(),
            "session_id": self.session_id,
            "user_id": self.user_id,
            "tags": self.tags,
            "metadata": self.metadata,
        })
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        duration = None
        if self._start_time is not None:
            duration = round(_now_ms() - self._start_time, 2)
        event: Dict[str, Any] = {
            "event": "session_end",
            "timestamp": _now_iso(),
            "session_id": self.session_id,
            "total_duration_ms": duration,
        }
        if exc_type is not None:
            event["error"] = f"{exc_type.__name__}: {exc_val}"
        self._write_event(event)
        self.close()
        return None

    def close(self) -> None:
        """Close the file handle."""
        if self._file_handle is not None:
            try:
                self._file_handle.close()
            except Exception:
                pass
            self._file_handle = None

    def flush(self) -> None:
        """Flush pending writes (compatibility with Langfuse handler)."""
        if self._file_handle is not None:
            try:
                self._file_handle.flush()
            except Exception:
                pass

    # -- LLM callbacks --

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[BaseMessage]],
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        try:
            self._record_run_start(str(run_id))
            model = serialized.get("kwargs", {}).get("model_name") or serialized.get("id", [""])[-1]
            self._write_event({
                "event": "llm_start",
                "run_id": str(run_id),
                "parent_run_id": str(parent_run_id) if parent_run_id else None,
                "timestamp": _now_iso(),
                "model": model,
                "messages": _serialize_messages(messages),
            })
        except Exception as e:
            logger.debug(f"LocalTraceCallback.on_chat_model_start failed: {e}")

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        try:
            duration = self._calc_duration(str(run_id))
            # Extract response text and usage
            output_text = None
            usage = {}
            for gen_list in getattr(response, "generations", []):
                for gen in gen_list:
                    msg = getattr(gen, "message", None)
                    if msg:
                        output_text = msg.content if isinstance(msg.content, str) else str(msg.content)
                        msg_usage = getattr(msg, "usage_metadata", None)
                        if msg_usage:
                            usage = dict(msg_usage) if hasattr(msg_usage, "__iter__") else {}
                    elif hasattr(gen, "text"):
                        output_text = gen.text
            # Also check llm_output for usage
            llm_output = getattr(response, "llm_output", None) or {}
            if not usage and isinstance(llm_output, dict):
                token_usage = llm_output.get("token_usage") or llm_output.get("usage") or {}
                if token_usage:
                    usage = dict(token_usage)

            self._write_event({
                "event": "llm_end",
                "run_id": str(run_id),
                "parent_run_id": str(parent_run_id) if parent_run_id else None,
                "timestamp": _now_iso(),
                "response": output_text,
                "usage": usage,
                "duration_ms": duration,
            })
        except Exception as e:
            logger.debug(f"LocalTraceCallback.on_llm_end failed: {e}")

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        try:
            duration = self._calc_duration(str(run_id))
            self._write_event({
                "event": "llm_error",
                "run_id": str(run_id),
                "parent_run_id": str(parent_run_id) if parent_run_id else None,
                "timestamp": _now_iso(),
                "error": str(error),
                "error_type": type(error).__name__,
                "duration_ms": duration,
            })
        except Exception as e:
            logger.debug(f"LocalTraceCallback.on_llm_error failed: {e}")

    # -- Tool callbacks --

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        try:
            self._record_run_start(str(run_id))
            tool_name = serialized.get("name") or serialized.get("id", [""])[-1]
            self._write_event({
                "event": "tool_start",
                "run_id": str(run_id),
                "parent_run_id": str(parent_run_id) if parent_run_id else None,
                "timestamp": _now_iso(),
                "tool": tool_name,
                "input": input_str,
            })
        except Exception as e:
            logger.debug(f"LocalTraceCallback.on_tool_start failed: {e}")

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        try:
            duration = self._calc_duration(str(run_id))
            self._write_event({
                "event": "tool_end",
                "run_id": str(run_id),
                "parent_run_id": str(parent_run_id) if parent_run_id else None,
                "timestamp": _now_iso(),
                "output": str(output),
                "duration_ms": duration,
            })
        except Exception as e:
            logger.debug(f"LocalTraceCallback.on_tool_end failed: {e}")

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        try:
            duration = self._calc_duration(str(run_id))
            self._write_event({
                "event": "tool_error",
                "run_id": str(run_id),
                "parent_run_id": str(parent_run_id) if parent_run_id else None,
                "timestamp": _now_iso(),
                "error": str(error),
                "error_type": type(error).__name__,
                "duration_ms": duration,
            })
        except Exception as e:
            logger.debug(f"LocalTraceCallback.on_tool_error failed: {e}")

    # -- Agent callbacks --

    def on_agent_action(
        self,
        action: AgentAction,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        try:
            self._write_event({
                "event": "agent_action",
                "run_id": str(run_id),
                "parent_run_id": str(parent_run_id) if parent_run_id else None,
                "timestamp": _now_iso(),
                "tool": action.tool,
                "tool_input": str(action.tool_input),
                "log": action.log,
            })
        except Exception as e:
            logger.debug(f"LocalTraceCallback.on_agent_action failed: {e}")

    def on_agent_finish(
        self,
        finish: AgentFinish,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        try:
            self._write_event({
                "event": "agent_finish",
                "run_id": str(run_id),
                "parent_run_id": str(parent_run_id) if parent_run_id else None,
                "timestamp": _now_iso(),
                "output": str(finish.return_values),
                "log": finish.log,
            })
        except Exception as e:
            logger.debug(f"LocalTraceCallback.on_agent_finish failed: {e}")


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


def read_trace_file(trace_file: Path) -> List[Dict[str, Any]]:
    """Read all events from a JSONL trace file.

    Args:
        trace_file: Path to the ``.jsonl`` file.

    Returns:
        List of event dicts, one per line.
    """
    events = []
    with open(trace_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                events.append(json.loads(line))
    return events


def list_trace_files(
    session_id_prefix: Optional[str] = None,
    trace_dir: Optional[Union[str, Path]] = None,
) -> List[Path]:
    """List trace files, optionally filtered by session ID prefix.

    Args:
        session_id_prefix: Filter files whose name starts with this prefix
            (after sanitization).
        trace_dir: Directory to search. Defaults to ``~/.penguin/traces/``.

    Returns:
        List of paths sorted by modification time (newest first).
    """
    d = Path(trace_dir) if trace_dir else DEFAULT_TRACE_DIR
    if not d.exists():
        return []

    files = list(d.glob("*.jsonl"))

    if session_id_prefix:
        prefix = _sanitize_filename(session_id_prefix)
        files = [f for f in files if f.name.startswith(prefix)]

    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return files


def analyze_trace_file(trace_file: Path) -> Dict[str, Any]:
    """Compute summary statistics for a trace file.

    Returns:
        Dict with keys: session_id, event_count, llm_calls, tool_calls,
        total_input_tokens, total_output_tokens, errors, total_duration_ms.
    """
    events = read_trace_file(trace_file)

    stats: Dict[str, Any] = {
        "file": str(trace_file),
        "event_count": len(events),
        "llm_calls": 0,
        "tool_calls": 0,
        "total_input_tokens": 0,
        "total_output_tokens": 0,
        "errors": 0,
        "session_id": None,
        "total_duration_ms": None,
    }

    for ev in events:
        etype = ev.get("event")
        if etype == "session_start":
            stats["session_id"] = ev.get("session_id")
        elif etype == "session_end":
            stats["total_duration_ms"] = ev.get("total_duration_ms")
        elif etype == "llm_end":
            stats["llm_calls"] += 1
            usage = ev.get("usage") or {}
            stats["total_input_tokens"] += usage.get("input_tokens", 0)
            stats["total_output_tokens"] += usage.get("output_tokens", 0)
        elif etype == "tool_end":
            stats["tool_calls"] += 1
        elif etype in ("llm_error", "tool_error"):
            stats["errors"] += 1

    return stats


def cleanup_old_traces(
    days_old: int = 30,
    trace_dir: Optional[Union[str, Path]] = None,
    dry_run: bool = False,
) -> List[Path]:
    """Remove trace files older than ``days_old`` days.

    Args:
        days_old: Delete files older than this many days.
        trace_dir: Directory to clean. Defaults to ``~/.penguin/traces/``.
        dry_run: If True, return files that would be deleted without removing.

    Returns:
        List of deleted (or would-be-deleted) file paths.
    """
    d = Path(trace_dir) if trace_dir else DEFAULT_TRACE_DIR
    if not d.exists():
        return []

    cutoff = time.time() - (days_old * 86400)
    deleted = []

    for f in d.glob("*.jsonl"):
        if f.stat().st_mtime < cutoff:
            deleted.append(f)
            if not dry_run:
                try:
                    f.unlink()
                except OSError as e:
                    logger.warning(f"Failed to delete trace file {f}: {e}")

    return deleted
