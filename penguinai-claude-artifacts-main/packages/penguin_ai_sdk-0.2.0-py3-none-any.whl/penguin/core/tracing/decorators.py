"""
Langfuse decorator re-exports for Penguin AI SDK.

Provides the @observe decorator from Langfuse for tracing arbitrary
functions (not just LangChain operations).

Compatible with Langfuse SDK v3.x.

Usage:
    from penguin.core.tracing import observe

    @observe(name="my_operation")
    def process_document(doc_id: str) -> dict:
        ...

    @observe(name="async_operation")
    async def fetch_results(query: str) -> list:
        ...
"""

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


def _noop_decorator(*args, **kwargs):
    """No-op decorator when Langfuse is not available."""
    if len(args) == 1 and callable(args[0]) and not kwargs:
        return args[0]

    def wrapper(fn):
        return fn

    return wrapper


try:
    # Langfuse v3: observe is a top-level export
    from langfuse import observe
except ImportError:
    logger.debug("langfuse not installed; @observe is a no-op")
    observe = _noop_decorator


def score_current_trace(
    name: str,
    value: float,
    comment: Optional[str] = None,
    data_type: Optional[str] = None,
) -> None:
    """
    Score the currently active Langfuse trace.

    Useful for evals/compliance scoring from within an @observe-decorated function.

    Args:
        name: Score name (e.g., "accuracy", "compliance_pass_rate")
        value: Score value (typically 0.0-1.0)
        comment: Optional comment explaining the score
        data_type: Score data type ("NUMERIC" or "BOOLEAN")
    """
    try:
        # Langfuse v3: get the current client and score the active trace
        from langfuse import get_client

        client = get_client()
        if client is not None:
            client.score_current_trace(
                name=name,
                value=value,
                comment=comment,
                data_type=data_type,
            )
    except ImportError:
        logger.debug("langfuse not installed; score_current_trace is a no-op")
    except Exception as e:
        logger.warning(f"Failed to score current trace: {e}")
