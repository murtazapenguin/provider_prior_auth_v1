"""
PenguinTracer - High-level tracing wrapper for Penguin AI SDK.

Provides project/session hierarchy on top of Langfuse, with graceful
degradation when Langfuse is unavailable.  When Langfuse is not available
(or ``enable_local_traces=True``), traces are written to JSONL files
in ``~/.penguin/traces/``.

Usage:
    from penguin.core.tracing import PenguinTracer

    # Project name from LANGFUSE_PROJECT env var (or pass explicitly)
    tracer = PenguinTracer()  # uses LANGFUSE_PROJECT env var, or "default"
    tracer = PenguinTracer(project="prior-auth")  # explicit override

    with tracer.session(session_id="case-001", user_id="clinician-42") as s:
        model = create_model(provider="bedrock", model="claude-sonnet-4-5")
        result = model.invoke([HumanMessage(content="Hi")], config=s.config)

    # Also works for chatbots, batch jobs, evals, etc:
    tracer = PenguinTracer(project="customer-support")
    with tracer.session("conv-abc", user_id="user-7") as s:
        result = await run_agent(agent, "help me", callbacks=s.callbacks)

Configuration (env var ``PENGUIN_LOCAL_TRACES``):
    auto   - (default) local traces only when Langfuse unavailable
    always - write local traces even when Langfuse is active
    never  - disable local traces entirely
"""

import logging
import os
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class SessionContext:
    """Context manager that provides config/callbacks for a tracing session."""

    def __init__(
        self,
        handlers: List[Any],
        langfuse_metadata: Dict[str, Any],
        enabled: bool,
        local_callback: Any = None,
    ):
        self._handlers = handlers
        self._langfuse_metadata = langfuse_metadata
        self._enabled = enabled
        self._local_callback = local_callback

    @property
    def config(self) -> Dict[str, Any]:
        """LangChain config dict with callbacks + metadata.

        Returns empty dict if tracing is disabled, so callers can always
        pass ``config=s.config`` safely.
        """
        if not self._enabled or not self._handlers:
            return {}
        return {
            "callbacks": list(self._handlers),
            "metadata": self._langfuse_metadata,
        }

    @property
    def callbacks(self) -> List[Any]:
        """List of callbacks for run_agent(). Empty list if tracing disabled."""
        if not self._enabled or not self._handlers:
            return []
        return list(self._handlers)

    def __enter__(self) -> "SessionContext":
        if self._local_callback is not None:
            self._local_callback.__enter__()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        # Close local trace callback first (writes session_end)
        if self._local_callback is not None:
            try:
                self._local_callback.__exit__(exc_type, exc_val, exc_tb)
            except Exception:
                pass

        # Flush Langfuse handlers
        for handler in self._handlers:
            if handler is not self._local_callback:
                try:
                    handler.flush()
                except Exception:
                    pass
        return None


class PenguinTracer:
    """High-level tracing wrapper for Penguin AI SDK.

    Wraps Langfuse complexity behind a clean project/session API.
    Gracefully degrades when Langfuse is unavailable, with optional
    local JSONL trace fallback.

    Args:
        project: Project name used as a Langfuse tag for filtering.
            Falls back to ``LANGFUSE_PROJECT`` env var, then ``"default"``.
        base_url: Langfuse server URL (overrides LANGFUSE_HOST env var).
            Defaults to https://langfuse.penguinai.co.
        public_key: Langfuse public key (overrides LANGFUSE_PUBLIC_KEY env var).
        secret_key: Langfuse secret key (overrides LANGFUSE_SECRET_KEY env var).
        enable_local_traces: Override for local trace mode. ``True`` maps to
            ``"always"``, ``False`` to ``"never"``, ``None`` reads from
            ``PENGUIN_LOCAL_TRACES`` env var (default ``"auto"``).
        local_trace_dir: Directory for JSONL trace files. Defaults to
            ``~/.penguin/traces/``.
    """

    def __init__(
        self,
        project: Optional[str] = None,
        base_url: Optional[str] = None,
        public_key: Optional[str] = None,
        secret_key: Optional[str] = None,
        enable_local_traces: Optional[bool] = None,
        local_trace_dir: Optional[str] = None,
    ):
        self._project = project or os.environ.get("LANGFUSE_PROJECT", "default")
        self._base_url = base_url or os.environ.get(
            "LANGFUSE_HOST", "https://langfuse.penguinai.co"
        )
        self._public_key = public_key or os.environ.get("LANGFUSE_PUBLIC_KEY")
        self._secret_key = secret_key or os.environ.get("LANGFUSE_SECRET_KEY")
        self._enabled: Optional[bool] = None  # lazy

        # Local trace configuration
        if enable_local_traces is True:
            self._local_trace_mode = "always"
        elif enable_local_traces is False:
            self._local_trace_mode = "never"
        else:
            self._local_trace_mode = os.environ.get(
                "PENGUIN_LOCAL_TRACES", "auto"
            ).lower()
        self._local_trace_dir = local_trace_dir

    @property
    def enabled(self) -> bool:
        """Whether Langfuse tracing is active (Langfuse reachable and configured)."""
        if self._enabled is not None:
            return self._enabled
        self._enabled = self._check_enabled()
        return self._enabled

    @property
    def local_traces_enabled(self) -> bool:
        """Whether local JSONL tracing will be used for new sessions."""
        if self._local_trace_mode == "always":
            return True
        if self._local_trace_mode == "never":
            return False
        # auto: enabled when Langfuse is NOT available
        return not self.enabled

    def _check_enabled(self) -> bool:
        """Check if Langfuse is configured and reachable."""
        if not self._public_key or not self._secret_key:
            logger.debug("PenguinTracer: no Langfuse keys configured, tracing disabled")
            return False
        try:
            from langfuse.langchain import CallbackHandler  # noqa: F401

            return _test_connection(
                self._public_key, self._secret_key, self._base_url
            )
        except ImportError:
            logger.debug("PenguinTracer: langfuse not installed, tracing disabled")
            return False
        except Exception as e:
            logger.debug(f"PenguinTracer: Langfuse check failed: {e}")
            return False

    def _should_enable_local(self) -> bool:
        """Determine whether to create a local trace callback."""
        if self._local_trace_mode == "always":
            return True
        if self._local_trace_mode == "never":
            return False
        # auto: enable when Langfuse is NOT available
        return not self.enabled

    def session(
        self,
        session_id: str,
        user_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> SessionContext:
        """Create a tracing session context.

        A session groups all traces (LLM calls, tool executions, agent steps)
        under a single session. When Langfuse is available, they map to
        Langfuse sessions. When not, traces are written to local JSONL files.

        Args:
            session_id: Unique ID for this session.
            user_id: Optional user identifier.
            tags: Optional extra tags (appended to the project tag).
            metadata: Optional additional metadata dict.

        Returns:
            SessionContext that can be used as a context manager.
        """
        handlers: List[Any] = []
        langfuse_handler = None
        local_callback = None

        all_tags = [self._project]
        if tags:
            all_tags.extend(tags)

        langfuse_metadata: Dict[str, Any] = {
            "langfuse_session_id": session_id,
            "langfuse_tags": all_tags,
        }
        if user_id:
            langfuse_metadata["langfuse_user_id"] = user_id
        if metadata:
            langfuse_metadata.update(metadata)

        # 1. Try Langfuse handler
        if self.enabled:
            try:
                from langfuse.langchain import CallbackHandler

                prev_env = {}
                env_overrides = {
                    "LANGFUSE_PUBLIC_KEY": self._public_key,
                    "LANGFUSE_SECRET_KEY": self._secret_key,
                    "LANGFUSE_HOST": self._base_url,
                }
                for key, value in env_overrides.items():
                    if value:
                        prev_env[key] = os.environ.get(key)
                        os.environ[key] = value
                try:
                    langfuse_handler = CallbackHandler()
                finally:
                    for key, prev_value in prev_env.items():
                        if prev_value is None:
                            os.environ.pop(key, None)
                        else:
                            os.environ[key] = prev_value

                handlers.append(langfuse_handler)
            except Exception as e:
                logger.warning(f"PenguinTracer: failed to create Langfuse handler: {e}")

        # 2. Local trace callback
        if self._should_enable_local():
            try:
                from penguin.core.callbacks.local_trace import LocalTraceCallback

                local_callback = LocalTraceCallback(
                    session_id=session_id,
                    user_id=user_id,
                    tags=all_tags,
                    metadata=metadata or {},
                    trace_dir=self._local_trace_dir,
                )
                handlers.append(local_callback)
            except Exception as e:
                logger.debug(f"PenguinTracer: failed to create local trace callback: {e}")

        enabled = len(handlers) > 0

        return SessionContext(
            handlers=handlers,
            langfuse_metadata=langfuse_metadata,
            enabled=enabled,
            local_callback=local_callback,
        )


# ---------------------------------------------------------------------------
# Connection resilience helpers
# ---------------------------------------------------------------------------

_connection_cache: Dict[str, bool] = {}
_connection_cache_time: Dict[str, float] = {}
_CACHE_TTL_SECONDS = 60.0


def _test_connection(
    public_key: str, secret_key: str, base_url: str, timeout: float = 3.0
) -> bool:
    """Test if a Langfuse server is reachable (with caching).

    Results are cached for 60 seconds to avoid repeated slow checks.
    """
    import time

    cache_key = f"{base_url}:{public_key}"
    now = time.time()

    cached_time = _connection_cache_time.get(cache_key, 0)
    if now - cached_time < _CACHE_TTL_SECONDS:
        return _connection_cache.get(cache_key, False)

    try:
        from langfuse import Langfuse

        client = Langfuse(
            public_key=public_key,
            secret_key=secret_key,
            base_url=base_url,
        )
        # auth_check does a lightweight server round-trip
        ok = client.auth_check()
        _connection_cache[cache_key] = ok
        _connection_cache_time[cache_key] = now
        if ok:
            logger.info("PenguinTracer: Langfuse connection verified")
        else:
            logger.warning("PenguinTracer: Langfuse auth check failed, tracing disabled")
        return ok
    except Exception as e:
        logger.warning(f"PenguinTracer: Langfuse unreachable ({e}), tracing disabled")
        _connection_cache[cache_key] = False
        _connection_cache_time[cache_key] = now
        return False
