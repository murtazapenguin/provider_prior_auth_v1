"""
Penguin Core Tracing (Langfuse)

Provides observability via Langfuse for all Penguin operations.
"""

from .langfuse_setup import (
    get_langfuse_client,
    get_callback_handler,
    is_tracing_enabled,
    flush_traces,
    shutdown_tracing,
)
from .decorators import observe, score_current_trace
from .tracer import PenguinTracer, SessionContext

__all__ = [
    "get_langfuse_client",
    "get_callback_handler",
    "is_tracing_enabled",
    "flush_traces",
    "shutdown_tracing",
    "observe",
    "score_current_trace",
    "PenguinTracer",
    "SessionContext",
]
