"""
Langfuse tracing setup for Penguin AI SDK.

Provides a singleton Langfuse client and callback handler factory
for integrating with LangChain's callback system.

Compatible with Langfuse SDK v3.x.

Environment Variables:
    LANGFUSE_PUBLIC_KEY: Langfuse public key
    LANGFUSE_SECRET_KEY: Langfuse secret key
    LANGFUSE_HOST: Langfuse server URL (default: https://langfuse.penguinai.co)
    PENGUIN_ENABLE_TRACING: Enable tracing even without Langfuse keys (true/1)
"""

import logging
import os
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

_langfuse_client = None


def is_tracing_enabled() -> bool:
    """Check if tracing is enabled via environment configuration."""
    has_keys = bool(os.environ.get("LANGFUSE_PUBLIC_KEY"))
    explicit_enable = os.environ.get("PENGUIN_ENABLE_TRACING", "").lower() in (
        "true",
        "1",
        "yes",
    )
    return has_keys or explicit_enable


def get_langfuse_client():
    """
    Get or create the singleton Langfuse client.

    Returns:
        Langfuse client instance, or None if tracing is not enabled.
    """
    global _langfuse_client

    if _langfuse_client is not None:
        return _langfuse_client

    if not is_tracing_enabled():
        return None

    try:
        from langfuse import Langfuse

        _langfuse_client = Langfuse(
            public_key=os.environ.get("LANGFUSE_PUBLIC_KEY"),
            secret_key=os.environ.get("LANGFUSE_SECRET_KEY"),
            base_url=os.environ.get("LANGFUSE_HOST", "https://langfuse.penguinai.co"),
        )
        logger.info("Langfuse tracing initialized")
        return _langfuse_client
    except ImportError:
        logger.warning("langfuse package not installed. Tracing disabled.")
        return None
    except Exception as e:
        logger.warning(f"Failed to initialize Langfuse: {e}. Tracing disabled.")
        return None


def get_callback_handler(
    session_id: Optional[str] = None,
    user_id: Optional[str] = None,
    trace_name: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    tags: Optional[list] = None,
):
    """
    Create a Langfuse callback handler for LangChain integration.

    This handler automatically traces all LangChain/LangGraph operations
    (LLM calls, tool executions, agent steps) to Langfuse.

    In Langfuse v3, session_id/user_id/tags are passed via LangChain's
    ``metadata`` config using ``langfuse_*`` prefixed keys. This function
    returns a tuple of ``(handler, langfuse_metadata)`` where the metadata
    dict should be merged into your LangChain config.

    Args:
        session_id: Group traces by session (e.g., conversation thread)
        user_id: Associate traces with a user
        trace_name: Custom name for the trace (passed as langfuse_trace_name)
        metadata: Additional metadata to attach to the trace
        tags: Tags for filtering in Langfuse dashboard

    Returns:
        CallbackHandler instance, or None if tracing is not enabled.
        The handler stores ``langfuse_metadata`` as an attribute for convenience.
    """
    if not is_tracing_enabled():
        return None

    try:
        from langfuse.langchain import CallbackHandler

        # Build Langfuse metadata dict (v3 reads these from LangChain metadata)
        langfuse_metadata: Dict[str, Any] = {}
        if session_id:
            langfuse_metadata["langfuse_session_id"] = session_id
        if user_id:
            langfuse_metadata["langfuse_user_id"] = user_id
        if tags:
            langfuse_metadata["langfuse_tags"] = tags
        if metadata:
            langfuse_metadata.update(metadata)

        # Create the callback handler
        # Note: Let Langfuse auto-generate trace IDs to avoid format issues
        # trace_name is stored in metadata for identification
        handler = CallbackHandler()

        # Stash metadata for callers to include in LangChain config
        handler.langfuse_metadata = langfuse_metadata

        return handler
    except ImportError:
        logger.warning("langfuse package not installed. Callback handler unavailable.")
        return None
    except Exception as e:
        logger.warning(f"Failed to create Langfuse callback handler: {e}")
        return None


def flush_traces() -> None:
    """Flush any pending traces to Langfuse."""
    client = get_langfuse_client()
    if client is not None:
        try:
            client.flush()
        except Exception as e:
            logger.warning(f"Failed to flush Langfuse traces: {e}")


def shutdown_tracing() -> None:
    """Flush pending traces and shut down the Langfuse client.

    Call this during process exit for a clean shutdown.
    """
    global _langfuse_client
    if _langfuse_client is not None:
        try:
            _langfuse_client.flush()
            _langfuse_client.shutdown()
        except Exception as e:
            logger.warning(f"Error during Langfuse shutdown: {e}")
        finally:
            _langfuse_client = None
