"""
Penguin Core - LangChain + LangGraph + Langfuse

The new unified API for Penguin AI SDK v0.2.0.

Quick Start:
    from penguin.core import (
        create_model,
        create_agent,
        run_agent,
        tool,
        observe,
        get_memory_checkpointer,
    )

    model = create_model(provider="bedrock", model="claude-sonnet-4-5")

    @tool
    def get_weather(city: str) -> str:
        \"\"\"Get weather for a city.\"\"\"
        return f"72F in {city}"

    # Create agent with checkpointing for conversation persistence
    checkpointer = get_memory_checkpointer()
    agent = create_agent(model, tools=[get_weather], checkpointer=checkpointer)

    # Run with thread_id for conversation continuity
    result = await run_agent(
        agent,
        "What's the weather in NYC?",
        thread_id="conversation-123"
    )
    print(result.answer)
"""

# Models
from penguin.core.models import (
    create_model,
    create_model_from_env,
    list_models,
    get_model_id,
    get_model_info,
    get_model_capabilities,
    ModelInfo,
    Provider,
    MODEL_REGISTRY,
)

# Tools
from penguin.core.tools import tool, adapt_penguin_tools, PenguinToolAdapter

# Agents
from penguin.core.agents import (
    create_penguin_agent,
    run_agent,
    AgentResponse,
    AgentState,
    PenguinStateGraph,
    GraphResponse,
    create_state_graph,
    run_graph,
    get_memory_checkpointer,
    get_postgres_checkpointer,
    get_graph_state,
    update_graph_state,
    get_graph_history,
)

# LangGraph re-exports (so users don't need direct LangGraph imports)
from langgraph.graph import START, END, StateGraph
from langgraph.graph import MessagesState
from langgraph.graph.message import add_messages
from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt import ToolNode
from langgraph.types import Send, Command, interrupt, Interrupt, RetryPolicy, StateSnapshot

# LangGraph checkpointers (optional - require extra dependencies)
try:
    from langgraph.checkpoint.memory import MemorySaver
    _HAS_MEMORY_CHECKPOINTER = True
except ImportError:
    _HAS_MEMORY_CHECKPOINTER = False

try:
    from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
    _HAS_POSTGRES_CHECKPOINTER = True
except ImportError:
    _HAS_POSTGRES_CHECKPOINTER = False

# LangChain re-exports - Core types
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.language_models import BaseChatModel
from langchain_core.tools import BaseTool
from langchain_core.agents import AgentAction, AgentFinish
from langchain_core.outputs import LLMResult

# Tracing
from penguin.core.tracing import observe, is_tracing_enabled, get_callback_handler, PenguinTracer

# Caching
from penguin.core.caching import with_prompt_caching, extract_cache_metrics

# Callbacks
from penguin.core.callbacks import (
    create_security_callbacks,
    create_default_callbacks,
)

# Messages (re-export from LangChain so users don't import langchain directly)
from langchain_core.messages import (
    HumanMessage,
    SystemMessage,
    AIMessage,
    ToolMessage,
    BaseMessage,
)

# Convenience aliases
create_agent = create_penguin_agent

__all__ = [
    # Models
    "create_model",
    "create_model_from_env",
    "list_models",
    "get_model_id",
    "get_model_info",
    "get_model_capabilities",
    "ModelInfo",
    "Provider",
    "MODEL_REGISTRY",
    # Tools
    "tool",
    "adapt_penguin_tools",
    "PenguinToolAdapter",
    # Agents
    "create_agent",
    "create_penguin_agent",
    "run_agent",
    "AgentResponse",
    "AgentState",
    "PenguinStateGraph",
    "GraphResponse",
    "create_state_graph",
    "run_graph",
    # Checkpointers
    "get_memory_checkpointer",
    "get_postgres_checkpointer",
    # State management helpers
    "get_graph_state",
    "update_graph_state",
    "get_graph_history",
    # LangGraph re-exports
    "START",
    "END",
    "StateGraph",
    "MessagesState",
    "add_messages",
    "CompiledStateGraph",
    "ToolNode",
    "Send",
    "Command",
    "interrupt",
    "Interrupt",
    "RetryPolicy",
    "StateSnapshot",
    # LangChain re-exports - Core types
    "BaseCallbackHandler",
    "BaseChatModel",
    "BaseTool",
    "AgentAction",
    "AgentFinish",
    "LLMResult",
    # Tracing
    "observe",
    "is_tracing_enabled",
    "get_callback_handler",
    "PenguinTracer",
    # Caching
    "with_prompt_caching",
    "extract_cache_metrics",
    # Callbacks
    "create_security_callbacks",
    "create_default_callbacks",
    # Messages
    "HumanMessage",
    "SystemMessage",
    "AIMessage",
    "ToolMessage",
    "BaseMessage",
]

# Conditionally add checkpointer classes if available
if _HAS_MEMORY_CHECKPOINTER:
    __all__.extend(["MemorySaver"])
if _HAS_POSTGRES_CHECKPOINTER:
    __all__.extend(["AsyncPostgresSaver"])
