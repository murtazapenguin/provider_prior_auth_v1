"""
Penguin Core - Prompt Caching

Utilities for injecting provider-specific cache markers into LLM calls,
enabling significant cost and latency savings for repeated system prompts.

Usage:
    from penguin.core import create_model, extract_cache_metrics
    from langchain_core.messages import SystemMessage, HumanMessage

    # Option A — enable at model creation (recommended)
    model = create_model(
        provider="bedrock",
        model="claude-sonnet-4-5",
        enable_prompt_caching=True,
    )

    # Option B — wrap an existing model
    from penguin.core import with_prompt_caching
    model = with_prompt_caching(create_model(...), provider="bedrock")

    # Use like a normal model — cachePoint is injected automatically
    response = model.invoke([
        SystemMessage("big system prompt..."),
        HumanMessage("question"),
    ])
    metrics = extract_cache_metrics(response)
    # First call:  cache_hit=False, cache_write_tokens=N
    # Second call: cache_hit=True,  cache_read_tokens=N
"""

from langchain_core.messages import SystemMessage


class _CachingModelProxy:
    """Proxy that injects cache markers into SystemMessages before model invocation."""

    def __init__(self, model, cache_marker: dict):
        self._model = model
        self._cache_marker = cache_marker

    def _inject(self, messages):
        result = []
        for msg in messages:
            if isinstance(msg, SystemMessage) and isinstance(msg.content, str):
                # Convert plain string → [text block, cache marker]
                result.append(SystemMessage(content=[
                    {"type": "text", "text": msg.content},
                    self._cache_marker,
                ]))
            elif isinstance(msg, SystemMessage) and isinstance(msg.content, list):
                # Already a list — append cache marker if not already present
                content = list(msg.content)
                if self._cache_marker not in content:
                    content.append(self._cache_marker)
                result.append(SystemMessage(content=content))
            else:
                result.append(msg)
        return result

    def invoke(self, input, *args, **kwargs):
        return self._model.invoke(self._inject(input), *args, **kwargs)

    async def ainvoke(self, input, *args, **kwargs):
        return await self._model.ainvoke(self._inject(input), *args, **kwargs)

    def stream(self, input, *args, **kwargs):
        return self._model.stream(self._inject(input), *args, **kwargs)

    async def astream(self, input, *args, **kwargs):
        async for chunk in self._model.astream(self._inject(input), *args, **kwargs):
            yield chunk

    def bind_tools(self, tools, **kwargs):
        return _CachingModelProxy(
            self._model.bind_tools(tools, **kwargs), self._cache_marker
        )

    def with_structured_output(self, schema, **kwargs):
        return _CachingModelProxy(
            self._model.with_structured_output(schema, **kwargs), self._cache_marker
        )

    def __getattr__(self, name):
        # Delegate all other attributes (callbacks, temperature, etc.) to underlying model
        return getattr(self._model, name)


def with_prompt_caching(model, provider: str = "bedrock") -> _CachingModelProxy:
    """
    Wrap a model to automatically add provider-appropriate cache control to SystemMessages.

    On every invoke/ainvoke/stream call, any SystemMessage with a plain string
    content is converted to a list with the appropriate cache marker appended.
    This tells Bedrock (or Anthropic) to cache the prompt prefix on the first
    call and serve from cache on subsequent calls.

    Args:
        model: Any BaseChatModel (typically from create_model())
        provider: "bedrock" or "bedrock_converse" → cachePoint type="default"
                  "anthropic"                      → cache_control type="ephemeral"

    Returns:
        A proxy with the same invoke/ainvoke/stream/bind_tools/with_structured_output
        interface as the underlying model.

    Examples:
        # Bedrock (default)
        cached = with_prompt_caching(create_model(provider="bedrock", model="claude-sonnet-4-5"))

        # Anthropic direct API
        cached = with_prompt_caching(model, provider="anthropic")
    """
    marker = (
        {"cachePoint": {"type": "default"}}
        if provider in ("bedrock", "bedrock_converse")
        else {"cache_control": {"type": "ephemeral"}}
    )
    return _CachingModelProxy(model, marker)


def extract_cache_metrics(response) -> dict:
    """
    Extract prompt-caching metrics from an LLM response.

    Handles two token-field formats:
    - LangChain normalised (Bedrock via langchain-aws):
        usage_metadata["input_token_details"]["cache_creation"] / ["cache_read"]
    - Raw provider keys (direct Bedrock / Anthropic SDK):
        usage_metadata["cache_write_input_tokens"] / ["cache_read_input_tokens"]

    On a cache miss (first call), cache_write_tokens > 0.
    On a cache hit (subsequent calls), cache_read_tokens > 0.

    Args:
        response: AIMessage or any object with usage_metadata / response_metadata

    Returns:
        {
            "cache_write_tokens": int,   # >0 on cache miss (first call)
            "cache_read_tokens": int,    # >0 on cache hit (subsequent calls)
            "cache_hit": bool,
        }
    """
    usage = getattr(response, "usage_metadata", {}) or {}
    if not usage:
        usage = getattr(response, "response_metadata", {}).get("usage", {})

    # LangChain normalised format (langchain-aws / BedrockConverse)
    details = usage.get("input_token_details", {}) or {}
    write_tokens = details.get("cache_creation", 0) or usage.get("cache_write_input_tokens", 0)
    read_tokens  = details.get("cache_read", 0)    or usage.get("cache_read_input_tokens", 0)

    return {
        "cache_write_tokens": write_tokens,
        "cache_read_tokens":  read_tokens,
        "cache_hit":          read_tokens > 0,
    }
