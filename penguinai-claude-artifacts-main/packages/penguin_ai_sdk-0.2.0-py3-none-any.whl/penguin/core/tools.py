"""
Penguin Core Tool System

Re-exports LangChain's @tool decorator and provides an adapter to wrap
old-style ``penguin.tools.BaseTool`` instances as LangChain tools.

Usage:
    from penguin.core import tool

    @tool
    def get_weather(city: str) -> str:
        \"\"\"Get weather for a city.\"\"\"
        return f"72F in {city}"

    # Adapt legacy Penguin tools
    from penguin.core.tools import adapt_penguin_tools
    lc_tools = adapt_penguin_tools([old_tool_1, old_tool_2])
"""

import asyncio
import logging
from typing import Any, Dict, List, Optional, Type, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from penguin.core import BaseTool as LCBaseTool
else:
    from langchain_core.tools import BaseTool as LCBaseTool

# Always import tool at runtime since it's re-exported
from langchain_core.tools import tool

logger = logging.getLogger(__name__)


class PenguinToolAdapter(LCBaseTool):
    """
    Wraps a legacy ``penguin.tools.BaseTool`` instance as a LangChain tool.

    This allows old Penguin tools to be used seamlessly with LangGraph agents
    and LangChain's tool-calling infrastructure.
    """

    name: str = ""
    description: str = ""
    penguin_tool: Any = None  # The wrapped penguin.tools.BaseTool instance

    def __init__(self, penguin_tool: Any, **kwargs: Any):
        # Extract name/description from the penguin tool before calling super
        super().__init__(
            name=penguin_tool.name,
            description=penguin_tool.description,
            penguin_tool=penguin_tool,
            **kwargs,
        )

    @property
    def args(self) -> dict:
        return self.penguin_tool.parameters

    def _run(self, **kwargs: Any) -> str:
        """
        Synchronous execution (runs the async method in an event loop).

        Note: When called from within a running event loop, this creates a new
        thread with a fresh event loop. This is necessary because asyncio.run()
        cannot be called from within an existing event loop.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # Running in an async context - spawn a thread with a new loop
            import concurrent.futures

            executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
            try:
                future = executor.submit(asyncio.run, self.penguin_tool.execute(**kwargs))
                result = future.result()
            finally:
                executor.shutdown(wait=True)
        else:
            # No running loop - safe to use asyncio.run()
            result = asyncio.run(self.penguin_tool.execute(**kwargs))

        if hasattr(result, "content"):
            content = result.content
            if hasattr(result, "success") and not result.success:
                error = getattr(result, "error", "Unknown error")
                return f"Error: {error}"
            return str(content) if content is not None else ""
        return str(result)

    async def _arun(self, **kwargs: Any) -> str:
        """Async execution - delegates to the Penguin tool's execute method."""
        result = await self.penguin_tool.execute(**kwargs)

        if hasattr(result, "content"):
            content = result.content
            if hasattr(result, "success") and not result.success:
                error = getattr(result, "error", "Unknown error")
                return f"Error: {error}"
            return str(content) if content is not None else ""
        return str(result)


def adapt_penguin_tools(
    tools: List[Any],
) -> List[Union[LCBaseTool, Any]]:
    """
    Convert a mixed list of old Penguin tools and LangChain tools into
    a uniform list of LangChain-compatible tools.

    Args:
        tools: List containing penguin.tools.BaseTool and/or LangChain tool instances

    Returns:
        List of LangChain-compatible tools
    """
    adapted = []
    for t in tools:
        if isinstance(t, LCBaseTool):
            adapted.append(t)
        elif hasattr(t, "execute") and hasattr(t, "name") and hasattr(t, "description"):
            # Looks like a Penguin BaseTool
            adapted.append(
                PenguinToolAdapter(
                    penguin_tool=t,
                )
            )
        elif callable(t):
            # Bare function - wrap with LangChain @tool
            adapted.append(tool(t))
        else:
            logger.warning(f"Cannot adapt tool of type {type(t).__name__}, skipping")
    return adapted


__all__ = [
    "tool",
    "PenguinToolAdapter",
    "adapt_penguin_tools",
]
