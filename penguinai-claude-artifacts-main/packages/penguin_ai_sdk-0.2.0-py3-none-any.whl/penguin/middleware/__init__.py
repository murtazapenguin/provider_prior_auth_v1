"""
Penguin Middleware (DEPRECATED)

.. deprecated:: 0.2.0
    Use ``penguin.core.callbacks`` instead. The middleware pattern has been
    replaced by LangChain callback handlers.

New Usage:
    from penguin.core.callbacks import create_security_callbacks, create_default_callbacks

    callbacks = create_security_callbacks()
    model.invoke(messages, config={"callbacks": callbacks})
"""

import warnings as _warnings
from typing import List, Optional, Tuple

_warnings.warn(
    "penguin.middleware is deprecated since v0.2.0. "
    "Use penguin.core.callbacks instead.",
    DeprecationWarning,
    stacklevel=2,
)

# New callback-based API (preferred)
from penguin.core.callbacks import (
    PromptInjectionCallback,
    OutputSafetyCallback,
    SecurityViolation as _NewSecurityViolation,
    GuardrailCallback,
    GuardrailViolation as _NewGuardrailViolation,
    ToolBlockingCallback,
    RateLimitCallback,
    create_security_callbacks,
    create_default_callbacks,
)

# Legacy classes still available for old agent code
from .base import (
    BaseMiddleware,
    MiddlewareChain,
    MiddlewareContext,
)
from .security import (
    PromptInjectionMiddleware,
    OutputSafetyMiddleware,
    SecurityViolation,
)
from .guardrails import (
    GuardrailMiddleware,
    GuardrailViolation,
    ToolBlockingMiddleware,
    RateLimitMiddleware,
)


def create_security_middleware(
    block_injections: bool = True,
    filter_output: bool = True,
    additional_injection_patterns: Optional[List[Tuple[str, str]]] = None,
    additional_output_patterns: Optional[List[Tuple[str, str]]] = None,
) -> MiddlewareChain:
    """Deprecated. Use ``penguin.core.callbacks.create_security_callbacks()``."""
    _warnings.warn(
        "create_security_middleware() is deprecated. "
        "Use penguin.core.callbacks.create_security_callbacks() instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    chain = MiddlewareChain()
    if block_injections:
        chain.add(PromptInjectionMiddleware(
            additional_patterns=additional_injection_patterns,
            block_on_detection=True,
            log_detections=True,
        ))
    if filter_output:
        chain.add(OutputSafetyMiddleware(
            additional_patterns=additional_output_patterns,
            redact_matches=True,
            block_on_detection=False,
        ))
    return chain


def create_guardrail_middleware(
    max_input_length: Optional[int] = None,
    max_message_count: Optional[int] = None,
    blocked_patterns: Optional[List[str]] = None,
    blocked_tools: Optional[List[str]] = None,
    max_calls_per_minute: Optional[int] = None,
) -> MiddlewareChain:
    """Deprecated. Use ``penguin.core.callbacks`` guardrail classes instead."""
    _warnings.warn(
        "create_guardrail_middleware() is deprecated. "
        "Use penguin.core.callbacks guardrail classes instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    chain = MiddlewareChain()
    if any([max_input_length, max_message_count, blocked_patterns]):
        chain.add(GuardrailMiddleware(
            max_input_length=max_input_length,
            max_message_count=max_message_count,
            blocked_patterns=blocked_patterns,
        ))
    if blocked_tools:
        chain.add(ToolBlockingMiddleware(
            blocked_tools=blocked_tools,
            on_blocked="raise",
        ))
    if max_calls_per_minute:
        chain.add(RateLimitMiddleware(
            max_calls_per_minute=max_calls_per_minute,
        ))
    return chain


__all__ = [
    # New (callback-based)
    "PromptInjectionCallback",
    "OutputSafetyCallback",
    "GuardrailCallback",
    "ToolBlockingCallback",
    "RateLimitCallback",
    "create_security_callbacks",
    "create_default_callbacks",
    # Legacy (middleware-based)
    "BaseMiddleware",
    "MiddlewareChain",
    "MiddlewareContext",
    "PromptInjectionMiddleware",
    "OutputSafetyMiddleware",
    "SecurityViolation",
    "GuardrailMiddleware",
    "GuardrailViolation",
    "ToolBlockingMiddleware",
    "RateLimitMiddleware",
    "create_security_middleware",
    "create_guardrail_middleware",
]
