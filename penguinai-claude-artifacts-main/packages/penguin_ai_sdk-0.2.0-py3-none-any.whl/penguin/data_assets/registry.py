# START OF FILE: penguin/data_assets/registry.py ---
import os
import pandas as pd
import json
from typing import List, Dict, Optional
from .models import DataAsset

class DataAssetRegistry:
    def __init__(self, inventory_file: str = "penguin_assets.json"):
        self.inventory_file = inventory_file
        self.assets: Dict[str, DataAsset] = {}
        self._load()

    def add_asset(self, name: str, description: str, file_path: str):
        """Registers a CSV file as an asset."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"CSV not found at {file_path}")
        
        asset = DataAsset(name=name, description=description, file_path=file_path)
        self.assets[name] = asset
        self._save()
        print(f"--- [Penguin] Asset '{name}' registered successfully. ---")

    def list_assets(self) -> List[Dict[str, str]]:
        """Returns a list of all assets and their descriptions."""
        return [{"name": a.name, "description": a.description} for a in self.assets.values()]

    def get_asset_df(self, name: str) -> pd.DataFrame:
        """Fetches the actual CSV content as a DataFrame for use in workflows."""
        if name not in self.assets:
            raise ValueError(f"Asset '{name}' not found.")
        return pd.read_csv(self.assets[name].file_path)

    def inspect_asset(self, name: str, n_rows: int = 5) -> pd.DataFrame:
        """Quick look at the first few rows of an asset."""
        df = self.get_asset_df(name)
        return df.head(n_rows)

    def _save(self):
        with open(self.inventory_file, "w") as f:
            json.dump({k: v.dict() for k, v in self.assets.items()}, f, indent=4)

    def _load(self):
        if os.path.exists(self.inventory_file):
            with open(self.inventory_file, "r") as f:
                data = json.load(f)
                self.assets = {k: DataAsset(**v) for k, v in data.items()}
# END OF FILE: penguin/data_assets/registry.py ---