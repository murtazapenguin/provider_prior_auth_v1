"""
Penguin Compliance Runner

Main orchestrator for compliance evaluation on input-output pairs.
"""

import asyncio
import logging
import uuid
from typing import Dict, List, Optional, Any

import pandas as pd
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import SystemMessage, HumanMessage

from .compliance_models import (
    ComplianceCase,
    ComplianceRuleResult,
    ComplianceReport,
    RuleSummary,
    BatchRuleResponse,
)

logger = logging.getLogger("penguin.compliance")


class ComplianceRunner:
    """
    Main orchestrator for compliance evaluation.

    Evaluates input-output pairs against compliance rules using LLM-as-judge.
    Each evaluation is traced and can be retrieved later using the trace_id.

    Example:
        ```python
        from penguin.core import create_model
        from penguin.compliance import ComplianceRunner

        model = create_model(provider="bedrock", model="us.anthropic.claude-sonnet-4-5-20250514-v1:0")
        runner = ComplianceRunner(model, max_concurrency=5)

        rules = [
            "Output must not contain PII (names, addresses, SSNs)",
            "Output must be professional in tone",
        ]

        report = await runner.evaluate(
            df=my_dataframe,
            rules=rules,
            task_name="Customer Support Bot",
            input_col="input",
            output_col="output"
        )

        print(f"Trace ID: {report.trace_id}")
        print(f"Pass Rate: {report.overall_pass_rate:.1%}")
        ```
    """

    def __init__(
        self,
        model: BaseChatModel,
        max_concurrency: int = 5
    ):
        """
        Initialize the compliance runner.

        Args:
            model: LangChain chat model for evaluation (from penguin.core.create_model)
            max_concurrency: Maximum concurrent LLM evaluations (default: 5)
        """
        self.model = model
        self.semaphore = asyncio.Semaphore(max_concurrency)
        self.max_concurrency = max_concurrency

    def _df_to_cases(
        self,
        df: pd.DataFrame,
        input_col: str,
        output_col: str,
        context_col: Optional[str] = None
    ) -> List[ComplianceCase]:
        """Convert DataFrame rows to ComplianceCase objects."""
        cases = []
        for idx, row in df.iterrows():
            input_text = str(row.get(input_col, "")) if pd.notna(row.get(input_col)) else ""
            output_text = str(row.get(output_col, "")) if pd.notna(row.get(output_col)) else ""
            context = None
            if context_col and context_col in row:
                context = str(row.get(context_col, "")) if pd.notna(row.get(context_col)) else None

            case = ComplianceCase(
                row_index=int(idx),
                input_text=input_text,
                output_text=output_text,
                context=context
            )
            cases.append(case)
        return cases

    async def _evaluate_batch(
        self,
        rules_list: List[str],
        case: ComplianceCase,
        task_name: str,
    ) -> List[ComplianceRuleResult]:
        """
        Evaluate multiple rules on one case in a single LLM call.

        Args:
            rules_list: List of rule descriptions (up to 10)
            case: The input-output pair to evaluate
            task_name: Name/description of the task

        Returns:
            List of ComplianceRuleResult, one per rule
        """
        async with self.semaphore:
            # Build numbered rules list for prompt
            rules_text = "\n".join(
                f"[{i}] {rule}" for i, rule in enumerate(rules_list)
            )

            system_content = f"""You are a compliance evaluator for: {task_name}

You will evaluate the OUTPUT against MULTIPLE RULES.
For EACH rule, determine if it passes or fails.

Think through each rule carefully before making a decision.
Return your evaluation for ALL rules in the specified JSON format."""

            user_content = f"""RULES TO EVALUATE:
{rules_text}

INPUT: {case.input_text}

OUTPUT: {case.output_text}"""

            if case.context:
                user_content += f"\n\nCONTEXT: {case.context}"

            user_content += """

Evaluate the OUTPUT against EACH rule above.
Return JSON with an evaluation for each rule by its index (0-based)."""

            messages = [
                SystemMessage(content=system_content),
                HumanMessage(content=user_content),
            ]

            try:
                structured_model = self.model.with_structured_output(BatchRuleResponse)
                response = await structured_model.ainvoke(messages)

                evaluations = response.evaluations if response else []

                # Map evaluations back to rules
                eval_by_index = {e.rule_index: e for e in evaluations}

                results = []
                for i, rule in enumerate(rules_list):
                    eval_item = eval_by_index.get(i)
                    results.append(ComplianceRuleResult(
                        rule_name=rule[:100],
                        row_index=case.row_index,
                        passed=bool(eval_item.passed) if eval_item else False,
                        reason=str(eval_item.reason) if eval_item else "No evaluation returned"
                    ))

                return results

            except Exception as e:
                logger.error(f"Error batch evaluating on row {case.row_index}: {e}")
                return [
                    ComplianceRuleResult(
                        rule_name=rule[:100],
                        row_index=case.row_index,
                        passed=False,
                        reason=f"Evaluation error: {str(e)}"
                    )
                    for rule in rules_list
                ]

    async def evaluate(
        self,
        df: pd.DataFrame,
        rules: List[str],
        task_name: str,
        input_col: str = "input",
        output_col: str = "output",
        context_col: Optional[str] = None,
        threshold: float = 0.7,
        batch_size: int = 10,
    ) -> ComplianceReport:
        """
        Evaluate compliance rules on input-output pairs.

        Args:
            df: DataFrame with input-output pairs
            rules: List of rule description strings
            task_name: Description of the task being evaluated
            input_col: Column name for input text (default: "input")
            output_col: Column name for output text (default: "output")
            context_col: Optional column name for additional context
            threshold: Pass/fail threshold for overall_passed (default: 0.7)
            batch_size: Max rules to evaluate per LLM call (default: 10)

        Returns:
            ComplianceReport with trace_id for later retrieval
        """
        trace_id = str(uuid.uuid4())

        logger.info(f"Starting compliance evaluation: {task_name}")
        logger.info(f"  Trace ID: {trace_id}")
        logger.info(f"  Rows: {len(df)}, Rules: {len(rules)}")

        # Convert DataFrame to cases
        cases = self._df_to_cases(df, input_col, output_col, context_col)

        # row_results[row_index][rule_name] = ComplianceRuleResult
        row_results: List[Dict[str, ComplianceRuleResult]] = [{} for _ in cases]
        rule_summaries: Dict[str, RuleSummary] = {}
        rule_pass_counts: Dict[str, int] = {rule: 0 for rule in rules}

        logger.info(f"  Using batch evaluation (batch_size={batch_size})")

        async def evaluate_case_batched(case: ComplianceCase) -> List[ComplianceRuleResult]:
            all_results = []
            for i in range(0, len(rules), batch_size):
                batch = rules[i:i + batch_size]
                batch_results = await self._evaluate_batch(batch, case, task_name)
                all_results.extend(batch_results)
            return all_results

        tasks = [evaluate_case_batched(case) for case in cases]
        all_case_results = await asyncio.gather(*tasks, return_exceptions=True)

        for case_idx, case_results in enumerate(all_case_results):
            if isinstance(case_results, Exception):
                for rule in rules:
                    row_results[case_idx][rule] = ComplianceRuleResult(
                        rule_name=rule[:100],
                        row_index=case_idx,
                        passed=False,
                        reason=f"Evaluation error: {str(case_results)}"
                    )
            else:
                for result in case_results:
                    row_results[case_idx][result.rule_name] = result
                    if result.passed:
                        for rule in rules:
                            if rule[:100] == result.rule_name:
                                rule_pass_counts[rule] += 1
                                break

        total = len(cases)
        for rule in rules:
            passed_count = rule_pass_counts[rule]
            rule_summaries[rule] = RuleSummary(
                rule_name=rule,
                total_evaluated=total,
                passed_count=passed_count,
                failed_count=total - passed_count,
                pass_rate=passed_count / total if total > 0 else 0.0
            )
            logger.info(f"  {rule[:50]}: {passed_count}/{total} passed ({passed_count/total*100:.1f}%)")

        overall_pass_rate = (
            sum(s.pass_rate for s in rule_summaries.values()) / len(rule_summaries)
            if rule_summaries else 0.0
        )
        overall_passed = overall_pass_rate >= threshold

        report = ComplianceReport(
            trace_id=trace_id,
            task_name=task_name,
            total_rows=len(df),
            rules_evaluated=rules,
            rule_summaries=rule_summaries,
            row_results=row_results,
            overall_pass_rate=overall_pass_rate,
            overall_passed=overall_passed
        )

        logger.info(f"Compliance evaluation complete. Pass rate: {overall_pass_rate:.1%}  Trace ID: {trace_id}")
        return report

    def to_dataframe(
        self,
        report: ComplianceReport,
        include_reasons: bool = True
    ) -> pd.DataFrame:
        """
        Convert compliance report to a DataFrame.

        Adds columns for each rule's pass/fail status.

        Args:
            report: ComplianceReport from evaluate()
            include_reasons: Whether to include reason columns (default: True)

        Returns:
            DataFrame with compliance columns added
        """
        data = []

        for row_idx, row_result in enumerate(report.row_results):
            row_data = {"row_index": row_idx}

            for rule_name, result in row_result.items():
                # Use a shorter key for the column name
                short_name = rule_name[:50] if len(rule_name) > 50 else rule_name
                row_data[f"{short_name}_passed"] = result.passed
                if include_reasons:
                    row_data[f"{short_name}_reason"] = result.reason

            data.append(row_data)

        return pd.DataFrame(data)
