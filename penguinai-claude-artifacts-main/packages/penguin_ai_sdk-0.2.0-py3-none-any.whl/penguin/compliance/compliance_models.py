"""
Penguin Compliance Models

Data models for compliance evaluation results.
"""

from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field


class ComplianceCase(BaseModel):
    """Single input-output pair for compliance evaluation."""
    row_index: int
    input_text: str
    output_text: str
    context: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ComplianceRuleResult(BaseModel):
    """Result of evaluating one rule on one row."""
    rule_name: str
    row_index: int
    passed: bool       # TRUE/FALSE only (no scores - LLMs unreliable with numeric scores)
    reason: str        # Explanation for pass/fail


class RuleSummary(BaseModel):
    """Summary statistics for a single rule."""
    rule_name: str
    total_evaluated: int
    passed_count: int
    failed_count: int
    pass_rate: float   # passed_count / total_evaluated


class ComplianceReport(BaseModel):
    """Complete compliance report with trace ID for retrieval."""
    trace_id: str              # UUID to retrieve traces later
    task_name: str
    total_rows: int
    rules_evaluated: List[str]
    rule_summaries: Dict[str, RuleSummary]
    row_results: List[Dict[str, ComplianceRuleResult]]
    overall_pass_rate: float   # Average of all rule pass_rates
    overall_passed: bool       # True if overall_pass_rate >= threshold

    def export_to_langfuse(self, trace_id: Optional[str] = None) -> None:
        """Push compliance scores to Langfuse.

        Args:
            trace_id: Langfuse trace ID to attach scores to. Falls back to
                self.trace_id if not provided.
        """
        try:
            from penguin.core.tracing import get_langfuse_client, is_tracing_enabled
        except ImportError:
            return
        if not is_tracing_enabled():
            return
        client = get_langfuse_client()
        if client is None:
            return

        effective_trace_id = trace_id or self.trace_id

        # Overall pass rate
        client.create_score(
            trace_id=effective_trace_id,
            name=f"{self.task_name}.overall_pass_rate",
            value=self.overall_pass_rate,
            data_type="NUMERIC",
            comment=f"Overall passed: {self.overall_passed}",
        )

        # Per-rule pass rates
        for rule_name, summary in self.rule_summaries.items():
            client.create_score(
                trace_id=effective_trace_id,
                name=f"{self.task_name}.{rule_name[:50]}",
                value=summary.pass_rate,
                data_type="NUMERIC",
            )

        client.flush()


# ============================================================================
# Batch Evaluation Models (for multi-rule per call)
# ============================================================================

class BatchRuleResult(BaseModel):
    """Single result within a batch compliance response."""
    rule_index: int     # 0-based index of the rule in the batch
    passed: bool
    reason: str


class BatchRuleResponse(BaseModel):
    """Schema for LLM batch compliance response (multiple rules, one row)."""
    evaluations: List[BatchRuleResult]
