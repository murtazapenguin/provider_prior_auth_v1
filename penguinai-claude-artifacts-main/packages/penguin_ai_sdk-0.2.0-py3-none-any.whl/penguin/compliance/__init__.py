"""
Penguin Compliance Module

Evaluate AI system outputs against compliance rules using LLM-as-judge.

Example:
    ```python
    from penguin.core import create_model
    from penguin.compliance import ComplianceRunner

    model = create_model(provider="bedrock", model="us.anthropic.claude-sonnet-4-5-20250514-v1:0")
    runner = ComplianceRunner(model, max_concurrency=5)

    rules = [
        "Output must not contain PII (names, addresses, SSNs)",
        "Output must be professional in tone",
    ]

    report = await runner.evaluate(
        df=my_dataframe,
        rules=rules,
        task_name="Customer Support Bot"
    )

    print(f"Pass Rate: {report.overall_pass_rate:.1%}")
    report.export_to_langfuse()
    ```
"""

from .compliance_models import (
    ComplianceCase,
    ComplianceRuleResult,
    ComplianceReport,
    RuleSummary,
)
from .compliance_checker import ComplianceRunner

__all__ = [
    "ComplianceRunner",
    "ComplianceCase",
    "ComplianceRuleResult",
    "ComplianceReport",
    "RuleSummary",
]
