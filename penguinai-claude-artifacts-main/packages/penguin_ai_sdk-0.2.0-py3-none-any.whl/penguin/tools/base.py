"""
Penguin Tools Base Module

Abstract base class for all tools with provider-specific format conversion.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict

from .types import ToolResult, ToolDefinition


class BaseTool(ABC):
    """
    Abstract base class for all tools.

    All tools must implement:
    - name: Tool identifier
    - description: Human-readable description for LLM
    - parameters: JSON Schema for parameters
    - execute(): Async execution method

    Provides format conversion for different LLM providers:
    - OpenAI format (universal standard)
    - Anthropic/Claude format
    - Gemini format
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique tool identifier."""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """Human-readable description for the LLM."""
        pass

    @property
    @abstractmethod
    def parameters(self) -> Dict[str, Any]:
        """JSON Schema for tool parameters."""
        pass

    @abstractmethod
    async def execute(self, **kwargs: Any) -> ToolResult:
        """
        Execute the tool with given parameters.

        Args:
            **kwargs: Tool-specific parameters

        Returns:
            ToolResult with execution result or error
        """
        pass

    # ================== Format Conversion ==================

    def to_openai_format(self) -> Dict[str, Any]:
        """
        Convert to OpenAI tool format (universal standard).

        Returns:
            {
                "type": "function",
                "function": {
                    "name": "...",
                    "description": "...",
                    "parameters": { JSON Schema }
                }
            }
        """
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters
            }
        }

    def to_anthropic_format(self) -> Dict[str, Any]:
        """
        Convert to Anthropic/Claude tool format.

        Returns:
            {
                "name": "...",
                "description": "...",
                "input_schema": { JSON Schema }
            }
        """
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.parameters
        }

    def to_gemini_format(self) -> Dict[str, Any]:
        """
        Convert to Gemini format.

        Gemini uses the same format as OpenAI.
        """
        return self.to_openai_format()

    def to_provider_format(self, provider: str) -> Dict[str, Any]:
        """
        Convert to provider-specific format.

        Args:
            provider: Provider name ("openai", "gemini", "bedrock")

        Returns:
            Provider-specific tool format
        """
        converters = {
            "openai": self.to_openai_format,
            "gemini": self.to_gemini_format,
            "bedrock": self.to_anthropic_format,
        }
        converter = converters.get(provider, self.to_openai_format)
        return converter()

    # ================== Utilities ==================

    def get_definition(self) -> ToolDefinition:
        """Get tool definition for serialization."""
        return ToolDefinition(
            name=self.name,
            description=self.description,
            parameters=self.parameters,
            is_async=True,  # All tools are async in this implementation
        )

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} name={self.name!r}>"
