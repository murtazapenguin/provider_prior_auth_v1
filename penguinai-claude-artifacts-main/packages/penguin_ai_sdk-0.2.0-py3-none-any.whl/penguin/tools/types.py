"""
Penguin Tools Types Module

Defines standardized types for tool execution results and definitions.
"""

from typing import Any, Dict, Optional
from pydantic import BaseModel


class ToolResult(BaseModel):
    """
    Standardized result from tool execution.

    Returned by BaseTool.execute() and used to communicate
    tool results back to the LLM.
    """
    call_id: str = ""
    tool_name: str
    content: Any = None                     # Result data (any type)
    success: bool = True
    error: Optional[str] = None
    execution_time_ms: Optional[float] = None

    def to_message_content(self) -> str:
        """Convert result to string for LLM consumption."""
        if not self.success:
            return f"Error: {self.error}"
        if self.content is None:
            return "Success (no output)"
        if isinstance(self.content, str):
            return self.content
        # Convert other types to string
        import json
        try:
            return json.dumps(self.content)
        except (TypeError, ValueError):
            return str(self.content)


class ToolDefinition(BaseModel):
    """
    Tool metadata for LLM consumption.

    Describes a tool's interface without the actual implementation.
    Used for serialization and display purposes.
    """
    name: str
    description: str
    parameters: Dict[str, Any]      # JSON Schema
    is_async: bool = False
