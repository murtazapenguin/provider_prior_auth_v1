"""
Penguin Tool Executor Module

Manages tool registration and execution.
"""

import asyncio
from typing import Any, Dict, List, Optional

from .base import BaseTool
from .types import ToolResult

# Import ToolCall from LLM messages
from ..llm.messages import ToolCall

# Tracing support
from ..observability.config import is_tracing_enabled, should_capture_content, get_tracer
from ..observability.attributes import GenAIAttributes, GenAISpanKind


class ToolExecutor:
    """
    Executes tools and manages in-memory tool registration.

    For persistent storage, use ToolRegistry instead.

    Features:
    - Register/unregister tools
    - Execute single or parallel tool calls
    - Convert tools to provider-specific formats

    Example:
        executor = ToolExecutor([get_weather_tool, calculate_tool])

        # Get tools for LLM
        tools = executor.to_provider_format("bedrock")

        # Execute tool calls from LLM response
        results = await executor.execute_parallel(result.tool_calls)
    """

    def __init__(self, tools: Optional[List[BaseTool]] = None):
        """
        Initialize executor with optional list of tools.

        Args:
            tools: List of tools to register
        """
        self._tools: Dict[str, BaseTool] = {}
        if tools:
            for t in tools:
                self.register(t)

    def register(self, tool: BaseTool) -> None:
        """
        Register a tool.

        Args:
            tool: Tool to register
        """
        self._tools[tool.name] = tool

    def unregister(self, name: str) -> bool:
        """
        Unregister a tool by name.

        Args:
            name: Tool name to unregister

        Returns:
            True if tool was found and removed, False otherwise
        """
        if name in self._tools:
            del self._tools[name]
            return True
        return False

    def get(self, name: str) -> Optional[BaseTool]:
        """
        Get a tool by name.

        Args:
            name: Tool name

        Returns:
            Tool if found, None otherwise
        """
        return self._tools.get(name)

    def list_tools(self) -> List[BaseTool]:
        """
        List all registered tools.

        Returns:
            List of all registered tools
        """
        return list(self._tools.values())

    def list_names(self) -> List[str]:
        """
        List all tool names.

        Returns:
            List of tool names
        """
        return list(self._tools.keys())

    def to_provider_format(self, provider: str) -> List[Dict[str, Any]]:
        """
        Convert all tools to provider-specific format.

        Args:
            provider: Provider name ("openai", "gemini", "bedrock")

        Returns:
            List of tools in provider format
        """
        return [t.to_provider_format(provider) for t in self._tools.values()]

    async def execute(self, call: ToolCall) -> ToolResult:
        """
        Execute a single tool call.

        Args:
            call: ToolCall from LLM response

        Returns:
            ToolResult with execution result or error
        """
        tool = self._tools.get(call.tool_name)

        if not tool:
            return ToolResult(
                call_id=call.call_id,
                tool_name=call.tool_name,
                content=None,
                success=False,
                error=f"Tool '{call.tool_name}' not found",
            )

        # Execute with optional tracing
        if is_tracing_enabled():
            return await self._execute_with_tracing(tool, call)
        else:
            result = await tool.execute(**call.parameters)
            result.call_id = call.call_id
            return result

    async def _execute_with_tracing(self, tool: BaseTool, call: ToolCall) -> ToolResult:
        """Execute tool with OpenTelemetry tracing."""
        import json
        from opentelemetry.trace import Status, StatusCode

        tracer = get_tracer("penguin.tools")

        with tracer.start_as_current_span(f"tool.{call.tool_name}") as span:
            # Set standard Gen-AI attributes
            span.set_attribute(GenAIAttributes.SPAN_TYPE, GenAISpanKind.TOOL)
            span.set_attribute(GenAIAttributes.TOOL_NAME, call.tool_name)
            span.set_attribute(GenAIAttributes.TOOL_CALL_ID, call.call_id)

            # Capture input parameters if enabled
            if should_capture_content():
                try:
                    span.set_attribute(
                        "gen_ai.tool.input",
                        json.dumps(call.parameters) if call.parameters else "{}"
                    )
                except (TypeError, ValueError):
                    span.set_attribute("gen_ai.tool.input", str(call.parameters))

            try:
                result = await tool.execute(**call.parameters)
                result.call_id = call.call_id

                # Record success/failure
                span.set_attribute("gen_ai.tool.success", result.success)

                if result.error:
                    span.set_attribute("gen_ai.tool.error", result.error)
                    # Tool executed but returned an error
                    span.set_status(Status(StatusCode.ERROR, result.error))
                else:
                    # Tool executed successfully
                    span.set_status(Status(StatusCode.OK))

                # Capture output if enabled
                if should_capture_content() and result.content:
                    content_str = str(result.content)
                    # Truncate if too long
                    if len(content_str) > 10000:
                        content_str = content_str[:10000] + "...[truncated]"
                    span.set_attribute("gen_ai.tool.output", content_str)

                return result

            except Exception as e:
                span.set_attribute("gen_ai.tool.success", False)
                span.set_attribute("gen_ai.tool.error", str(e))
                span.record_exception(e)
                span.set_status(Status(StatusCode.ERROR, str(e)))
                raise

    async def execute_parallel(self, calls: List[ToolCall]) -> List[ToolResult]:
        """
        Execute multiple tool calls in parallel.

        Args:
            calls: List of ToolCalls from LLM response

        Returns:
            List of ToolResults in same order as input
        """
        if not calls:
            return []

        return await asyncio.gather(*[self.execute(c) for c in calls])

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    def __repr__(self) -> str:
        return f"<ToolExecutor tools={list(self._tools.keys())}>"
