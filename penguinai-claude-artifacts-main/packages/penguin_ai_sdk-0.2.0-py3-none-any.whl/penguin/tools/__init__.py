"""
Penguin Tools Module (DEPRECATED)

.. deprecated:: 0.2.0
    Use ``penguin.core.tools`` for the ``@tool`` decorator instead.
    Legacy tool classes (BaseTool, FunctionTool, ToolExecutor, ToolRegistry)
    are still available for backward compatibility.

New Usage:
    from penguin.core import tool

    @tool
    def get_weather(city: str) -> str:
        \"\"\"Get weather for a city.\"\"\"
        return f"Weather in {city}: Sunny"
"""

import warnings as _warnings

_warnings.warn(
    "penguin.tools is deprecated since v0.2.0. Use penguin.core.tools instead.",
    DeprecationWarning,
    stacklevel=2,
)

# New LangChain @tool decorator
from penguin.core.tools import tool, PenguinToolAdapter, adapt_penguin_tools

# Legacy classes still available for backward compat
from .types import ToolResult, ToolDefinition
from .base import BaseTool
from .function_tool import FunctionTool
from .executor import ToolExecutor
from .registry import ToolRegistry
from .schema import SchemaGenerator

__all__ = [
    # New (preferred)
    "tool",
    "PenguinToolAdapter",
    "adapt_penguin_tools",
    # Legacy
    "ToolResult",
    "ToolDefinition",
    "BaseTool",
    "FunctionTool",
    "ToolExecutor",
    "ToolRegistry",
    "SchemaGenerator",
]
