"""
Penguin Tools Schema Generator

Generates JSON Schema from Python type hints for tool parameter validation.
"""

import inspect
from enum import Enum
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Type,
    Union,
    get_args,
    get_origin,
    get_type_hints,
)

from pydantic import BaseModel


class SchemaGenerator:
    """
    Generate JSON Schema from Python type hints.

    Supports:
    - Basic types: str, int, float, bool
    - Collections: List[T], Dict[str, T]
    - Optional: Optional[T]
    - Union: Union[A, B]
    - Literal: Literal["a", "b"]
    - Enum types
    - Pydantic models
    """

    # Python type to JSON Schema type mapping
    TYPE_MAP: Dict[type, str] = {
        str: "string",
        int: "integer",
        float: "number",
        bool: "boolean",
        list: "array",
        dict: "object",
        type(None): "null",
    }

    @classmethod
    def from_function(cls, func: Callable) -> Dict[str, Any]:
        """
        Extract JSON Schema from function signature.

        Uses inspect.signature() and typing.get_type_hints() to build
        a complete JSON Schema for the function's parameters.

        Args:
            func: The function to extract schema from

        Returns:
            JSON Schema dict with properties and required fields
        """
        sig = inspect.signature(func)

        # Get type hints (handles forward references)
        try:
            hints = get_type_hints(func)
        except Exception:
            hints = {}

        properties: Dict[str, Any] = {}
        required: List[str] = []

        for param_name, param in sig.parameters.items():
            # Skip self, cls, *args, **kwargs
            if param_name in ("self", "cls"):
                continue
            if param.kind in (
                inspect.Parameter.VAR_POSITIONAL,
                inspect.Parameter.VAR_KEYWORD
            ):
                continue

            # Get type annotation
            param_type = hints.get(param_name, param.annotation)

            # Build property schema
            prop_schema = cls._type_to_schema(param_type)

            # Add description from docstring if available
            doc_params = cls._parse_docstring_params(func.__doc__ or "")
            if param_name in doc_params:
                prop_schema["description"] = doc_params[param_name]

            properties[param_name] = prop_schema

            # Required if no default value
            if param.default is inspect.Parameter.empty:
                required.append(param_name)

        return {
            "type": "object",
            "properties": properties,
            "required": required,
        }

    @classmethod
    def from_pydantic(cls, model: Type[BaseModel]) -> Dict[str, Any]:
        """
        Extract JSON Schema from Pydantic model.

        Args:
            model: Pydantic model class

        Returns:
            JSON Schema dict
        """
        if hasattr(model, "model_json_schema"):
            # Pydantic v2
            return model.model_json_schema()
        else:
            # Pydantic v1
            return model.schema()  # type: ignore

    @classmethod
    def _type_to_schema(cls, python_type: Any) -> Dict[str, Any]:
        """
        Convert a Python type to JSON Schema.

        Handles basic types, generics, Optional, Union, Literal, Enum.
        """
        # Handle missing annotation
        if python_type is inspect.Parameter.empty:
            return {"type": "string"}  # Default to string

        # Handle None type
        if python_type is type(None):
            return {"type": "null"}

        # Get origin for generic types (List, Dict, Optional, Union, etc.)
        origin = get_origin(python_type)
        args = get_args(python_type)

        # Handle Literal
        if origin is type(None):
            return {"type": "null"}

        # Check for Literal (typing.Literal)
        try:
            from typing import Literal
            if origin is Literal:
                return {
                    "type": cls._infer_type_from_values(args),
                    "enum": list(args)
                }
        except ImportError:
            pass

        # Handle Optional[T] -> Union[T, None]
        if origin is Union:
            # Filter out NoneType
            non_none_args = [a for a in args if a is not type(None)]

            if len(non_none_args) == 1:
                # Optional[T] -> just T's schema (nullable implied)
                return cls._type_to_schema(non_none_args[0])
            else:
                # Union of multiple types
                return {
                    "oneOf": [cls._type_to_schema(a) for a in non_none_args]
                }

        # Handle List[T]
        if origin is list:
            if args:
                return {
                    "type": "array",
                    "items": cls._type_to_schema(args[0])
                }
            return {"type": "array"}

        # Handle Dict[K, V]
        if origin is dict:
            schema: Dict[str, Any] = {"type": "object"}
            if len(args) >= 2:
                schema["additionalProperties"] = cls._type_to_schema(args[1])
            return schema

        # Handle Enum
        if isinstance(python_type, type) and issubclass(python_type, Enum):
            values = [e.value for e in python_type]
            return {
                "type": cls._infer_type_from_values(values),
                "enum": values
            }

        # Handle Pydantic models
        if isinstance(python_type, type) and issubclass(python_type, BaseModel):
            return cls.from_pydantic(python_type)

        # Handle basic types
        if python_type in cls.TYPE_MAP:
            return {"type": cls.TYPE_MAP[python_type]}

        # Handle class types by name
        if isinstance(python_type, type):
            type_name = python_type.__name__.lower()
            if type_name in ("str", "string"):
                return {"type": "string"}
            if type_name in ("int", "integer"):
                return {"type": "integer"}
            if type_name in ("float", "number"):
                return {"type": "number"}
            if type_name in ("bool", "boolean"):
                return {"type": "boolean"}

        # Default fallback
        return {"type": "string"}

    @classmethod
    def _infer_type_from_values(cls, values: tuple) -> str:
        """Infer JSON Schema type from a tuple of values."""
        if not values:
            return "string"

        first = values[0]
        if isinstance(first, bool):
            return "boolean"
        if isinstance(first, int):
            return "integer"
        if isinstance(first, float):
            return "number"
        return "string"

    @classmethod
    def _parse_docstring_params(cls, docstring: str) -> Dict[str, str]:
        """
        Parse parameter descriptions from docstring.

        Supports Google-style and Sphinx-style docstrings.
        """
        params: Dict[str, str] = {}
        if not docstring:
            return params

        lines = docstring.strip().split("\n")
        in_args_section = False
        current_param = None
        current_desc: List[str] = []

        for line in lines:
            stripped = line.strip()

            # Check for Args/Parameters section
            if stripped.lower() in ("args:", "arguments:", "parameters:", "params:"):
                in_args_section = True
                continue

            # Check for end of Args section
            if in_args_section and stripped and not stripped.startswith(" ") and ":" in stripped:
                # Check if this is a new section header
                if stripped.lower().rstrip(":") in ("returns", "raises", "yields", "examples"):
                    in_args_section = False
                    if current_param:
                        params[current_param] = " ".join(current_desc).strip()
                    continue

            if in_args_section:
                # Try to match "param_name: description" or "param_name (type): description"
                if ":" in stripped:
                    parts = stripped.split(":", 1)
                    param_part = parts[0].strip()

                    # Remove type annotation if present
                    if "(" in param_part:
                        param_part = param_part.split("(")[0].strip()

                    if param_part and not param_part.startswith(" "):
                        # Save previous param
                        if current_param:
                            params[current_param] = " ".join(current_desc).strip()

                        current_param = param_part
                        current_desc = [parts[1].strip()] if len(parts) > 1 else []
                elif current_param and stripped:
                    # Continuation of previous param description
                    current_desc.append(stripped)

        # Save last param
        if current_param:
            params[current_param] = " ".join(current_desc).strip()

        return params
