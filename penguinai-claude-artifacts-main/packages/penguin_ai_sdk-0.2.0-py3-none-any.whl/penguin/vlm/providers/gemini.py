import os
import mimetypes
from typing import List, Dict, Any, Optional
from google import genai
from google.genai import types
from ..base import BaseVLMProvider
from ..models import VLMResult

class GeminiVLMProvider(BaseVLMProvider):
    def __init__(self, api_key: str = None, model_id: str = "gemini-2.0-flash-exp"):
        api_key = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY environment variable is required")
        
        self.api_key = api_key
        self.client = genai.Client(api_key=self.api_key)
        self.model_id = model_id

    def _prepare_parts(self, image_paths: List[str], prompt: str) -> List[types.Part]:
        parts = [types.Part.from_text(text=prompt)]
        
        for path in image_paths:
            with open(path, "rb") as f:
                data = f.read()
            
            mime_type, _ = mimetypes.guess_type(path)
            parts.append(
                types.Part.from_bytes(
                    data=data,
                    mime_type=mime_type or "image/jpeg"
                )
            )
        return parts

    async def extract(
        self, 
        image_paths: List[str], 
        prompt: str, 
        response_schema: Optional[Dict[str, Any]] = None
    ) -> VLMResult:
        """
        Generic extraction method. 
        If response_schema is provided, it forces JSON output.
        """
        parts = self._prepare_parts(image_paths, prompt)
        
        config_args = {}
        if response_schema:
            config_args["response_mime_type"] = "application/json"
            config_args["response_schema"] = response_schema

        # Note: Using sync call as google-genai's async support varies by environment, 
        # but we wrap it in the Penguin async interface.
        response = self.client.models.generate_content(
            model=self.model_id,
            contents=[types.Content(parts=parts, role="user")],
            config=types.GenerateContentConfig(**config_args) if config_args else None
        )

        return VLMResult(
            structured_data=response.parsed if response_schema else None,
            raw_text=response.text if not response_schema else None,
            provider="google_gemini",
            model_version=self.model_id,
            metadata={"usage": response.usage_metadata if response.usage_metadata else {}}
        )