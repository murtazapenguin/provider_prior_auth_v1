"""
Penguin AI Library

A provider-agnostic library for LLM interactions, tool management, and AI services.

v0.2.0: Core rebuilt on LangChain + LangGraph + Langfuse.

Modules:
    - core: NEW - LangChain/LangGraph/Langfuse unified API
    - llm: DEPRECATED -> delegates to core
    - tools: DEPRECATED -> delegates to core
    - agents: DEPRECATED -> delegates to core
    - middleware: DEPRECATED -> delegates to core/callbacks
    - observability: DEPRECATED -> delegates to core/tracing
    - automl: Automated machine learning with hyperparameter optimization
    - embeddings: Text embeddings (AWS Bedrock Titan)
    - vector_db: Vector database (AWS S3 Vectors)
    - data_assets: Bundled datasets (ICD-10, etc.)
    - evals: LLM-based evaluation framework
    - compliance: LLM-based compliance checking
    - ocr: OCR providers
    - redaction: PII redaction
"""

__version__ = "0.2.0"


# Lazy imports for core API
def create_model(*args, **kwargs):
    """Create a LangChain chat model. See ``penguin.core.create_model``."""
    from penguin.core import create_model as _create_model
    return _create_model(*args, **kwargs)


def create_agent(*args, **kwargs):
    """Create a LangGraph agent. See ``penguin.core.create_agent``."""
    from penguin.core import create_agent as _create_agent
    return _create_agent(*args, **kwargs)


def run_agent(*args, **kwargs):
    """Run a LangGraph agent. See ``penguin.core.run_agent``."""
    from penguin.core import run_agent as _run_agent
    return _run_agent(*args, **kwargs)


# Lazy imports for data assets (requires pandas)
def load_asset(*args, **kwargs):
    """Load a bundled data asset. Requires pandas."""
    from penguin.data_assets import load_asset as _load_asset
    return _load_asset(*args, **kwargs)


def list_assets(*args, **kwargs):
    """List available data assets. Requires pandas."""
    from penguin.data_assets import list_assets as _list_assets
    return _list_assets(*args, **kwargs)
