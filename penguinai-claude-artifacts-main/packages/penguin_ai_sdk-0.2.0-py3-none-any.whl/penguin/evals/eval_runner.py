"""
Penguin Evals Runner

Main orchestrator for LLM-based evaluation on input-output pairs.
"""

import asyncio
import logging
import uuid
from typing import Dict, List, Optional, Any

import pandas as pd
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import SystemMessage, HumanMessage

from .eval_models import (
    EvalCase,
    EvalCriteriaResult,
    EvalReport,
    CriteriaSummary,
    BatchEvalResponse,
)

logger = logging.getLogger("penguin.evals")


class EvalRunner:
    """
    Main orchestrator for LLM-based evaluation.

    Evaluates input-output pairs against custom criteria using LLM-as-judge.
    Each evaluation is traced and can be retrieved later using the trace_id.

    Example:
        ```python
        from penguin.core import create_model
        from penguin.evals import EvalRunner

        model = create_model(provider="bedrock", model="us.anthropic.claude-sonnet-4-5-20250514-v1:0")
        runner = EvalRunner(model, max_concurrency=5)

        criteria = [
            "Output must be factually accurate given the context",
            "Output must directly answer the question asked",
        ]

        report = await runner.evaluate(
            df=my_dataframe,
            criteria=criteria,
            task_name="QA Bot Evaluation",
            input_col="question",
            output_col="answer",
            expected_col="reference_answer",
            context_col="source_text"
        )

        print(f"Trace ID: {report.trace_id}")
        print(f"Pass Rate: {report.overall_pass_rate:.1%}")
        ```
    """

    def __init__(
        self,
        model: BaseChatModel,
        max_concurrency: int = 5
    ):
        """
        Initialize the evaluation runner.

        Args:
            model: LangChain chat model for evaluation (from penguin.core.create_model)
            max_concurrency: Maximum concurrent LLM evaluations (default: 5)
        """
        self.model = model
        self.semaphore = asyncio.Semaphore(max_concurrency)
        self.max_concurrency = max_concurrency

    def _df_to_cases(
        self,
        df: pd.DataFrame,
        input_col: str,
        output_col: str,
        expected_col: Optional[str] = None,
        context_col: Optional[str] = None
    ) -> List[EvalCase]:
        """Convert DataFrame rows to EvalCase objects."""
        cases = []
        for idx, row in df.iterrows():
            input_text = str(row.get(input_col, "")) if pd.notna(row.get(input_col)) else ""
            actual_output = str(row.get(output_col, "")) if pd.notna(row.get(output_col)) else ""

            expected_output = None
            if expected_col and expected_col in row:
                expected_output = str(row.get(expected_col, "")) if pd.notna(row.get(expected_col)) else None

            context = None
            if context_col and context_col in row:
                context = str(row.get(context_col, "")) if pd.notna(row.get(context_col)) else None

            case = EvalCase(
                row_index=int(idx),
                input_text=input_text,
                actual_output=actual_output,
                expected_output=expected_output,
                context=context
            )
            cases.append(case)
        return cases

    async def _evaluate_batch(
        self,
        criteria_list: List[str],
        case: EvalCase,
        task_name: str,
    ) -> List[EvalCriteriaResult]:
        """
        Evaluate multiple criteria on one case in a single LLM call.

        Args:
            criteria_list: List of criteria descriptions (up to 10)
            case: The input-output pair to evaluate
            task_name: Name/description of the task

        Returns:
            List of EvalCriteriaResult, one per criteria
        """
        async with self.semaphore:
            # Build numbered criteria list for prompt
            criteria_text = "\n".join(
                f"[{i}] {crit}" for i, crit in enumerate(criteria_list)
            )

            system_content = f"""You are an evaluator for: {task_name}

You will evaluate the OUTPUT against MULTIPLE CRITERIA.
For EACH criteria, determine if it passes or fails.

Think through each criteria carefully before making a decision.
Return your evaluation for ALL criteria in the specified JSON format."""

            user_content = f"""CRITERIA TO EVALUATE:
{criteria_text}

INPUT: {case.input_text}

OUTPUT: {case.actual_output}"""

            if case.expected_output:
                user_content += f"\n\nEXPECTED: {case.expected_output}"

            if case.context:
                user_content += f"\n\nCONTEXT: {case.context}"

            user_content += """

Evaluate the OUTPUT against EACH criteria above.
Return JSON with an evaluation for each criteria by its index (0-based)."""

            messages = [
                SystemMessage(content=system_content),
                HumanMessage(content=user_content),
            ]

            try:
                structured_model = self.model.with_structured_output(BatchEvalResponse)
                response = await structured_model.ainvoke(messages)

                evaluations = response.evaluations if response else []

                # Map evaluations back to criteria
                eval_by_index = {e.rule_index: e for e in evaluations}

                results = []
                for i, crit in enumerate(criteria_list):
                    eval_item = eval_by_index.get(i)
                    results.append(EvalCriteriaResult(
                        criteria_name=crit[:100],
                        row_index=case.row_index,
                        passed=bool(eval_item.passed) if eval_item else False,
                        reason=str(eval_item.reason) if eval_item else "No evaluation returned"
                    ))

                return results

            except Exception as e:
                logger.error(f"Error batch evaluating on row {case.row_index}: {e}")
                return [
                    EvalCriteriaResult(
                        criteria_name=crit[:100],
                        row_index=case.row_index,
                        passed=False,
                        reason=f"Evaluation error: {str(e)}"
                    )
                    for crit in criteria_list
                ]

    async def evaluate(
        self,
        df: pd.DataFrame,
        criteria: List[str],
        task_name: str,
        input_col: str = "input",
        output_col: str = "output",
        expected_col: Optional[str] = None,
        context_col: Optional[str] = None,
        threshold: float = 0.7,
        batch_size: int = 10,
    ) -> EvalReport:
        """
        Evaluate criteria on input-output pairs.

        Args:
            df: DataFrame with input-output pairs
            criteria: List of criteria description strings
            task_name: Description of the task being evaluated
            input_col: Column name for input/question (default: "input")
            output_col: Column name for actual output/answer (default: "output")
            expected_col: Optional column name for reference/expected answer
            context_col: Optional column name for additional context
            threshold: Pass/fail threshold for overall_passed (default: 0.7)
            batch_size: Max criteria to evaluate per LLM call (default: 10)

        Returns:
            EvalReport with trace_id for later retrieval
        """
        trace_id = str(uuid.uuid4())

        logger.info(f"Starting evaluation: {task_name}")
        logger.info(f"  Trace ID: {trace_id}")
        logger.info(f"  Rows: {len(df)}, Criteria: {len(criteria)}")

        # Convert DataFrame to cases
        cases = self._df_to_cases(df, input_col, output_col, expected_col, context_col)

        # row_results[row_index][criteria_name] = EvalCriteriaResult
        row_results: List[Dict[str, EvalCriteriaResult]] = [{} for _ in cases]
        criteria_summaries: Dict[str, CriteriaSummary] = {}
        criteria_pass_counts: Dict[str, int] = {crit: 0 for crit in criteria}

        logger.info(f"  Using batch evaluation (batch_size={batch_size})")

        async def evaluate_case_batched(case: EvalCase) -> List[EvalCriteriaResult]:
            all_results = []
            for i in range(0, len(criteria), batch_size):
                batch = criteria[i:i + batch_size]
                batch_results = await self._evaluate_batch(batch, case, task_name)
                all_results.extend(batch_results)
            return all_results

        tasks = [evaluate_case_batched(case) for case in cases]
        all_case_results = await asyncio.gather(*tasks, return_exceptions=True)

        for case_idx, case_results in enumerate(all_case_results):
            if isinstance(case_results, Exception):
                for crit in criteria:
                    row_results[case_idx][crit] = EvalCriteriaResult(
                        criteria_name=crit[:100],
                        row_index=case_idx,
                        passed=False,
                        reason=f"Evaluation error: {str(case_results)}"
                    )
            else:
                for result in case_results:
                    row_results[case_idx][result.criteria_name] = result
                    if result.passed:
                        for crit in criteria:
                            if crit[:100] == result.criteria_name:
                                criteria_pass_counts[crit] += 1
                                break

        total = len(cases)
        for crit in criteria:
            passed_count = criteria_pass_counts[crit]
            criteria_summaries[crit] = CriteriaSummary(
                criteria_name=crit,
                total_evaluated=total,
                passed_count=passed_count,
                failed_count=total - passed_count,
                pass_rate=passed_count / total if total > 0 else 0.0
            )
            logger.info(f"  {crit[:50]}: {passed_count}/{total} passed ({passed_count/total*100:.1f}%)")

        overall_pass_rate = (
            sum(s.pass_rate for s in criteria_summaries.values()) / len(criteria_summaries)
            if criteria_summaries else 0.0
        )
        overall_passed = overall_pass_rate >= threshold

        report = EvalReport(
            trace_id=trace_id,
            task_name=task_name,
            total_rows=len(df),
            criteria_evaluated=criteria,
            criteria_summaries=criteria_summaries,
            row_results=row_results,
            overall_pass_rate=overall_pass_rate,
            overall_passed=overall_passed
        )

        logger.info(f"Evaluation complete. Pass rate: {overall_pass_rate:.1%}  Trace ID: {trace_id}")
        return report

    def to_dataframe(
        self,
        report: EvalReport,
        include_reasons: bool = True
    ) -> pd.DataFrame:
        """
        Convert evaluation report to a DataFrame.

        Adds columns for each criteria's pass/fail status.

        Args:
            report: EvalReport from evaluate()
            include_reasons: Whether to include reason columns (default: True)

        Returns:
            DataFrame with evaluation columns added
        """
        data = []

        for row_idx, row_result in enumerate(report.row_results):
            row_data = {"row_index": row_idx}

            for criteria_name, result in row_result.items():
                # Use a shorter key for the column name
                short_name = criteria_name[:50] if len(criteria_name) > 50 else criteria_name
                row_data[f"{short_name}_passed"] = result.passed
                if include_reasons:
                    row_data[f"{short_name}_reason"] = result.reason

            data.append(row_data)

        return pd.DataFrame(data)
