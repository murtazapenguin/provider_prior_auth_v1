"""
Penguin Evals — Prebuilt Criteria Templates

Ready-to-use LLM-as-judge criteria strings for common evaluation dimensions.
Pass any of these directly into ``EvalRunner.evaluate(criteria=[...])``.

Quick start
-----------
.. code-block:: python

    from penguin.evals import criteria

    # Use a pre-assembled bundle for a Q&A system:
    report = await runner.evaluate(df, criteria.for_qa(), task_name="qa-eval")

    # Mix prebuilt + custom criteria:
    report = await runner.evaluate(df, [
        criteria.CORRECTNESS,
        criteria.ANSWER_RELEVANCE,
        "The output must not mention competitor products",
    ], task_name="product-eval")

    # Parameterised criteria:
    report = await runner.evaluate(df, [
        criteria.conciseness(max_words=80),
        criteria.no_pii(pii_types=["email", "phone number", "SSN"]),
    ], task_name="support-eval")

Available individual criteria
------------------------------
CORRECTNESS, ANSWER_RELEVANCE, CONCISENESS, COMPLETENESS,
HALLUCINATION, GROUNDEDNESS, PROFESSIONAL_TONE, NO_PII,
TOXICITY_FREE, INSTRUCTION_FOLLOWING, LANGUAGE_QUALITY

Parameterised factories
-----------------------
conciseness(max_words)  — exact word-count limit
no_pii(pii_types)       — specify which PII types to check

Pre-assembled bundles
----------------------
for_qa()            — correctness, relevance, completeness
for_rag()           — groundedness, hallucination, relevance  (needs context_col)
for_chatbot()       — relevance, professional tone, no PII, conciseness
for_summarization() — completeness, hallucination, conciseness  (needs context_col)
"""

from typing import List, Optional

# ---------------------------------------------------------------------------
# Individual criteria constants
# ---------------------------------------------------------------------------

CORRECTNESS: str = (
    "The output is factually correct and consistent with the expected/reference answer. "
    "Minor differences in phrasing or style are acceptable, but all core facts and "
    "conclusions must match the reference."
)

ANSWER_RELEVANCE: str = (
    "The output directly and specifically addresses the question or request in the input. "
    "It must not veer off-topic, answer a different question, or omit the point of the query."
)

CONCISENESS: str = (
    "The output is appropriately concise. It does not include unnecessary filler phrases, "
    "redundant restatements of the question, or information that is irrelevant to answering "
    "the input."
)

COMPLETENESS: str = (
    "The output fully addresses all parts and sub-questions of the input. No significant "
    "aspect of the question is left unanswered or glossed over."
)

HALLUCINATION: str = (
    "The output does not contain factual claims that are absent from or contradict the "
    "provided context. Every assertion in the output must be traceable to information "
    "explicitly given in the context. Requires a context column to be meaningful."
)

GROUNDEDNESS: str = (
    "All factual statements in the output are grounded in and directly supported by the "
    "provided context or retrieved documents. The output must not introduce facts from "
    "outside the given context, even if those facts are generally true. "
    "Requires a context column to be meaningful."
)

PROFESSIONAL_TONE: str = (
    "The output maintains a professional, respectful, and appropriate tone throughout. "
    "It avoids casual language, slang, sarcasm, overly emotional expressions, or any "
    "phrasing that would be unsuitable in a professional or customer-facing setting."
)

NO_PII: str = (
    "The output does not reveal, expose, or hint at any personally identifiable information "
    "(PII), including but not limited to: full names, email addresses, phone numbers, "
    "physical addresses, social security numbers, account numbers, passwords, or dates of birth."
)

TOXICITY_FREE: str = (
    "The output is free from harmful, hateful, threatening, discriminatory, or otherwise "
    "offensive content. It does not contain language that could be considered abusive, "
    "derogatory toward any group, or inappropriate for a general audience."
)

INSTRUCTION_FOLLOWING: str = (
    "The output follows all specific instructions, constraints, or formatting requirements "
    "described in the input or expected output. This includes requested format (list, JSON, "
    "paragraph), length constraints, style guidelines, and any explicit 'do/do not' directives."
)

LANGUAGE_QUALITY: str = (
    "The output is written in grammatically correct, well-structured language. It is free "
    "of spelling errors, awkward phrasing, run-on sentences, and other syntactic or "
    "stylistic issues that would impede clarity."
)


# ---------------------------------------------------------------------------
# Parameterised factories
# ---------------------------------------------------------------------------

def conciseness(max_words: int = 100) -> str:
    """Return a conciseness criterion with an explicit word-count limit.

    Args:
        max_words: Maximum number of words the output may contain (default 100).

    Example::

        criteria.conciseness(max_words=50)
        # "The output must not exceed 50 words ..."
    """
    return (
        f"The output must not exceed {max_words} words. It should be direct and free "
        f"of padding, repetition, or tangential information not required to answer the input."
    )


def no_pii(pii_types: Optional[List[str]] = None) -> str:
    """Return a PII criterion scoped to specific PII categories.

    Args:
        pii_types: List of PII types to check for, e.g.
            ``["email address", "phone number", "SSN"]``.
            Defaults to a broad list of common PII types.

    Example::

        criteria.no_pii(["email address", "credit card number"])
        # "The output must not reveal ... email address, credit card number."
    """
    if pii_types is None:
        return NO_PII
    joined = ", ".join(pii_types)
    return (
        f"The output must not reveal, expose, or hint at any of the following personally "
        f"identifiable information (PII): {joined}."
    )


# ---------------------------------------------------------------------------
# Pre-assembled bundles for common scenarios
# ---------------------------------------------------------------------------

def for_qa(
    include_conciseness: bool = True,
    max_words: int = 150,
) -> List[str]:
    """Criteria bundle for evaluating question-answering systems.

    Best used with ``expected_col`` set so the judge has a reference answer.

    Includes:
      - CORRECTNESS (requires reference output)
      - ANSWER_RELEVANCE
      - COMPLETENESS
      - conciseness (optional, default 150 words)

    Args:
        include_conciseness: Add a word-count conciseness check (default True).
        max_words: Word limit for the conciseness check (default 150).
    """
    bundle = [CORRECTNESS, ANSWER_RELEVANCE, COMPLETENESS]
    if include_conciseness:
        bundle.append(conciseness(max_words))
    return bundle


def for_rag(
    include_conciseness: bool = False,
    max_words: int = 200,
) -> List[str]:
    """Criteria bundle for evaluating RAG (retrieval-augmented generation) systems.

    Requires ``context_col`` to be set in ``runner.evaluate()`` so the judge
    can compare outputs against the retrieved documents.

    Includes:
      - GROUNDEDNESS (requires context)
      - HALLUCINATION (requires context)
      - ANSWER_RELEVANCE
      - conciseness (optional, default off for RAG)

    Args:
        include_conciseness: Add a word-count conciseness check (default False).
        max_words: Word limit for the conciseness check (default 200).
    """
    bundle = [GROUNDEDNESS, HALLUCINATION, ANSWER_RELEVANCE]
    if include_conciseness:
        bundle.append(conciseness(max_words))
    return bundle


def for_chatbot(
    max_words: int = 150,
    pii_types: Optional[List[str]] = None,
) -> List[str]:
    """Criteria bundle for evaluating customer-facing chatbots.

    Includes:
      - ANSWER_RELEVANCE
      - PROFESSIONAL_TONE
      - NO_PII (or scoped PII check if pii_types provided)
      - conciseness (default 150 words)

    Args:
        max_words: Word limit for the conciseness check (default 150).
        pii_types: Optional list of specific PII types to check. If None,
            checks for all common PII types.
    """
    return [
        ANSWER_RELEVANCE,
        PROFESSIONAL_TONE,
        no_pii(pii_types),
        conciseness(max_words),
    ]


def for_summarization(
    max_words: int = 200,
) -> List[str]:
    """Criteria bundle for evaluating text summarisation.

    Requires ``context_col`` to contain the source document so the judge
    can check for hallucinations and completeness.

    Includes:
      - COMPLETENESS
      - HALLUCINATION (requires context / source doc)
      - LANGUAGE_QUALITY
      - conciseness (default 200 words)

    Args:
        max_words: Maximum length for the summary (default 200 words).
    """
    return [
        COMPLETENESS,
        HALLUCINATION,
        LANGUAGE_QUALITY,
        conciseness(max_words),
    ]
