"""
Penguin Evals Module

Evaluate AI outputs against custom criteria using LLM-as-judge.

Example:
    ```python
    from penguin.core import create_model
    from penguin.evals import EvalRunner, criteria

    model = create_model(provider="bedrock", model="us.anthropic.claude-sonnet-4-5-20250514-v1:0")
    runner = EvalRunner(model, max_concurrency=5)

    # Use a prebuilt bundle:
    report = await runner.evaluate(
        df=my_dataframe,
        criteria=criteria.for_qa(),
        task_name="QA Evaluation",
        expected_col="reference_answer",
    )

    # Or mix prebuilt + custom:
    report = await runner.evaluate(
        df=my_dataframe,
        criteria=[
            criteria.CORRECTNESS,
            criteria.ANSWER_RELEVANCE,
            "The output must not mention competitor products",
        ],
        task_name="Product QA"
    )

    print(f"Pass Rate: {report.overall_pass_rate:.1%}")
    report.export_to_langfuse()
    ```
"""

from .eval_models import (
    EvalCase,
    EvalCriteriaResult,
    EvalReport,
    CriteriaSummary,
)
from .eval_runner import EvalRunner
from . import criteria

__all__ = [
    "EvalRunner",
    "EvalCase",
    "EvalCriteriaResult",
    "EvalReport",
    "CriteriaSummary",
    "criteria",
]
