"""
Penguin Embeddings Middleware Module

Provides middleware-wrapped embedding clients for automatic tracing.
"""

import uuid
from typing import Any, Dict, List, Optional

from .base import BaseEmbeddingProvider
from .types import EmbeddingResult, ProviderCapabilities


class MiddlewareWrappedEmbeddingClient:
    """
    Wraps an embedding client to route all calls through middleware for tracing.

    This provides automatic OpenTelemetry span creation for all embedding operations.
    """

    def __init__(
        self,
        client: BaseEmbeddingProvider,
        middleware_chain: "MiddlewareChain",
    ):
        self._client = client
        self._chain = middleware_chain
        self._last_trace_id: Optional[str] = None

    def _create_context(
        self,
        operation: str,
        **kwargs
    ) -> "MiddlewareContext":
        """Create middleware context for an operation."""
        from penguin.observability.middleware import MiddlewareContext

        return MiddlewareContext(
            trace_id=str(uuid.uuid4()),
            span_id=str(uuid.uuid4())[:16],
            span_name=f"embedding.{operation}",
            span_type="embedding",
            provider=self._client.provider_name,
            model=self._client.model,
            inputs=kwargs,
            attributes={
                "embedding.dimensions": self._client.dimensions,
                "embedding.operation": operation,
            }
        )

    async def embed(
        self,
        text: str,
        **kwargs: Any
    ) -> EmbeddingResult:
        """Embed text with tracing."""
        context = self._create_context(
            "embed",
            text_length=len(text),
            **{k: v for k, v in kwargs.items() if k not in ("text",)}
        )

        async def _execute(*args, **kw):
            return await self._client.embed(text, **kwargs)

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id

        # Add usage to context for tracing
        if hasattr(result, 'usage'):
            context.outputs = {
                "input_tokens": result.usage.input_tokens,
                "dimensions": result.dimensions,
            }

        return result

    async def embed_batch(
        self,
        texts: List[str],
        **kwargs: Any
    ) -> List[EmbeddingResult]:
        """Embed batch with tracing."""
        context = self._create_context(
            "embed_batch",
            batch_size=len(texts),
            **{k: v for k, v in kwargs.items() if k not in ("batch_size",)}
        )

        async def _execute(*args, **kw):
            return await self._client.embed_batch(texts, **kwargs)

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id

        # Aggregate usage
        if result:
            total_tokens = sum(r.usage.input_tokens for r in result)
            context.outputs = {
                "total_input_tokens": total_tokens,
                "batch_size": len(result),
            }

        return result

    async def embed_documents(
        self,
        documents: List[Dict[str, Any]],
        text_field: str = "content",
        id_field: Optional[str] = "id",
        include_text: bool = True,
        **kwargs: Any
    ) -> List[EmbeddingResult]:
        """Embed documents with tracing."""
        context = self._create_context(
            "embed_documents",
            document_count=len(documents),
            text_field=text_field,
            id_field=id_field,
            include_text=include_text,
        )

        async def _execute(*args, **kw):
            return await self._client.embed_documents(
                documents, text_field, id_field, include_text, **kwargs
            )

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id
        return result

    async def embed_document_chunks(
        self,
        chunks: List[Any],
        include_text: bool = True,
        **kwargs: Any
    ) -> List[Any]:
        """Embed document chunks with tracing."""
        context = self._create_context(
            "embed_document_chunks",
            chunk_count=len(chunks),
            include_text=include_text,
        )

        async def _execute(*args, **kw):
            return await self._client.embed_document_chunks(chunks, include_text, **kwargs)

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id

        # Add usage info
        if result:
            context.outputs = {
                "chunks_embedded": len(result),
            }

        return result

    # Proxy properties
    @property
    def provider_name(self) -> str:
        return self._client.provider_name

    @property
    def model(self) -> str:
        return self._client.model

    @property
    def dimensions(self) -> int:
        return self._client.dimensions

    @property
    def capabilities(self) -> ProviderCapabilities:
        return self._client.capabilities

    @property
    def last_trace_id(self) -> Optional[str]:
        return self._last_trace_id

    @property
    def device(self) -> Optional[str]:
        """Return device if underlying client supports it (sentence-transformers)."""
        return getattr(self._client, 'device', None)

    async def embed_query(self, text: str, **kwargs: Any) -> EmbeddingResult:
        """Embed query text with tracing (for asymmetric retrieval)."""
        # Check if client supports embed_query
        if hasattr(self._client, 'embed_query'):
            context = self._create_context(
                "embed_query",
                text_length=len(text),
                **{k: v for k, v in kwargs.items() if k not in ("text",)}
            )

            async def _execute(*args, **kw):
                return await self._client.embed_query(text, **kwargs)

            result = await self._chain.execute(context, _execute)
            self._last_trace_id = context.trace_id

            if hasattr(result, 'usage'):
                context.outputs = {
                    "input_tokens": result.usage.input_tokens,
                    "dimensions": result.dimensions,
                }

            return result
        else:
            # Fall back to regular embed
            return await self.embed(text, **kwargs)


def get_embedding_middleware_chain() -> "MiddlewareChain":
    """Get middleware chain for embedding operations."""
    from penguin.observability.config import is_tracing_enabled
    from penguin.observability.middleware import MiddlewareChain, OTelMiddleware

    chain = MiddlewareChain()
    if is_tracing_enabled():
        chain.add(OTelMiddleware(
            tracer_name="penguin.embeddings",
            capture_prompts=False,  # Don't capture full text
            capture_completions=False,
        ))
    return chain
