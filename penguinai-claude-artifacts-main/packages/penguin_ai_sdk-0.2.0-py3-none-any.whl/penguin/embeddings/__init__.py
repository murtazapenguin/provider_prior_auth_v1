"""
Penguin Embeddings Module

Multi-provider embedding abstraction supporting AWS Bedrock Titan.

Usage:
    from penguin.embeddings import create_embedding_client, list_models, get_model

    # List all available embedding models
    models = list_models()
    for model in models:
        print(f"{model.id}: {model.description}")

    # List models by provider
    bedrock_models = list_models("bedrock")

    # Get model info
    model = get_model("titan-embed-v2")
    print(model.supported_dimensions)  # [256, 512, 1024]
    print(model.default_dimension)     # 1024

    # Create Bedrock Titan client
    client = create_embedding_client("bedrock", dimensions=1024)

    # Generate embedding
    result = await client.embed("Hello world")
    print(result.embedding)  # [0.123, 0.456, ...]
    print(result.dimensions)  # 1024

    # Batch embedding
    results = await client.embed_batch(["text1", "text2", "text3"])
"""

from .factory import create_embedding_client, create_embedding_client_from_env
from .base import (
    BaseEmbeddingProvider,
    EmbeddingError,
    RateLimitError,
    AuthenticationError,
    InvalidRequestError,
)
from .types import (
    EmbeddingResult,
    EmbeddingUsage,
    EmbeddingConfig,
    ProviderCapabilities,
)
from .document_models import (
    DocumentChunk,
    EmbeddedDocument,
)
from .models import (
    EmbeddingModelInfo,
    Provider,
    list_models,
    get_model,
    get_default_model,
    resolve_model_id,
    get_models_by_dimension,
    get_model_capabilities,
    validate_dimension,
)
from .providers.bedrock import BedrockTitanEmbeddingClient

__all__ = [
    # Factory
    "create_embedding_client",
    "create_embedding_client_from_env",
    # Base
    "BaseEmbeddingProvider",
    "EmbeddingError",
    "RateLimitError",
    "AuthenticationError",
    "InvalidRequestError",
    # Types
    "EmbeddingResult",
    "EmbeddingUsage",
    "EmbeddingConfig",
    "ProviderCapabilities",
    # Document Models
    "DocumentChunk",
    "EmbeddedDocument",
    # Model Registry
    "EmbeddingModelInfo",
    "Provider",
    "list_models",
    "get_model",
    "get_default_model",
    "resolve_model_id",
    "get_models_by_dimension",
    "get_model_capabilities",
    "validate_dimension",
    # Providers
    "BedrockTitanEmbeddingClient",
]
