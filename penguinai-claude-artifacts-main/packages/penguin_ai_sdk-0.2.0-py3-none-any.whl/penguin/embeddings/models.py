"""
Penguin Embeddings Model Registry

Centralized embedding model definitions for all providers.
Adding a new embedding model? Just add it to the MODELS dict below!
"""

import logging
from dataclasses import dataclass
from typing import Dict, List, Optional, Set
from enum import Enum

logger = logging.getLogger(__name__)


class Provider(str, Enum):
    """Supported embedding providers."""
    BEDROCK = "bedrock"
    SENTENCE_TRANSFORMERS = "sentence_transformers"
    LOCAL = "local"  # Alias for sentence_transformers (local/finetuned models)


@dataclass
class EmbeddingModelInfo:
    """
    Embedding model metadata and capabilities.

    Attributes:
        id: Friendly name (e.g., "titan-embed-v2-1024")
        provider: Which provider this model belongs to
        api_id: Actual API model ID sent to the provider
        supported_dimensions: List of supported dimensions
        default_dimension: Default dimension if not specified
        max_input_tokens: Maximum input tokens
        max_batch_size: Maximum batch size for concurrent requests
        normalize: Whether embeddings are normalized by default
        description: Human-readable description
    """
    id: str
    provider: Provider
    api_id: str
    supported_dimensions: List[int]
    default_dimension: int = 1024
    max_input_tokens: int = 8192
    max_batch_size: int = 100
    normalize: bool = True
    description: str = ""

    def supports_dimension(self, dimension: int) -> bool:
        """Check if this model supports a specific dimension."""
        return dimension in self.supported_dimensions


# =============================================================================
# MODEL DEFINITIONS
# =============================================================================
# To add a new embedding model, just add an entry here!
# The model will automatically be available in list_models() and the provider.

MODELS: Dict[str, EmbeddingModelInfo] = {
    # =========================================================================
    # BEDROCK (Titan via AWS)
    # =========================================================================
    "titan-embed-v2-256": EmbeddingModelInfo(
        id="titan-embed-v2-256",
        provider=Provider.BEDROCK,
        api_id="amazon.titan-embed-text-v2:0",
        supported_dimensions=[256, 512, 1024],
        default_dimension=256,
        max_input_tokens=8192,
        max_batch_size=100,
        normalize=True,
        description="Amazon Titan Embeddings V2 - 256 dimensions (fastest, smallest)",
    ),
    "titan-embed-v2-512": EmbeddingModelInfo(
        id="titan-embed-v2-512",
        provider=Provider.BEDROCK,
        api_id="amazon.titan-embed-text-v2:0",
        supported_dimensions=[256, 512, 1024],
        default_dimension=512,
        max_input_tokens=8192,
        max_batch_size=100,
        normalize=True,
        description="Amazon Titan Embeddings V2 - 512 dimensions (balanced)",
    ),
    "titan-embed-v2": EmbeddingModelInfo(
        id="titan-embed-v2",
        provider=Provider.BEDROCK,
        api_id="amazon.titan-embed-text-v2:0",
        supported_dimensions=[256, 512, 1024],
        default_dimension=1024,
        max_input_tokens=8192,
        max_batch_size=100,
        normalize=True,
        description="Amazon Titan Embeddings V2 - 1024 dimensions (highest quality, default)",
    ),
    "titan-embed-v2-1024": EmbeddingModelInfo(
        id="titan-embed-v2-1024",
        provider=Provider.BEDROCK,
        api_id="amazon.titan-embed-text-v2:0",
        supported_dimensions=[256, 512, 1024],
        default_dimension=1024,
        max_input_tokens=8192,
        max_batch_size=100,
        normalize=True,
        description="Amazon Titan Embeddings V2 - 1024 dimensions (highest quality)",
    ),

    # =========================================================================
    # SENTENCE TRANSFORMERS (Open-source via HuggingFace)
    # =========================================================================
    "bge-m3": EmbeddingModelInfo(
        id="bge-m3",
        provider=Provider.SENTENCE_TRANSFORMERS,
        api_id="BAAI/bge-m3",
        supported_dimensions=[1024],
        default_dimension=1024,
        max_input_tokens=8192,
        max_batch_size=32,
        normalize=True,
        description="BGE M3 - Multi-task multilingual embedding model (recommended)",
    ),
    "bge-large-en": EmbeddingModelInfo(
        id="bge-large-en",
        provider=Provider.SENTENCE_TRANSFORMERS,
        api_id="BAAI/bge-large-en-v1.5",
        supported_dimensions=[1024],
        default_dimension=1024,
        max_input_tokens=512,
        max_batch_size=32,
        normalize=True,
        description="BGE Large EN v1.5 - English-optimized embeddings",
    ),
    "e5-large-v2": EmbeddingModelInfo(
        id="e5-large-v2",
        provider=Provider.SENTENCE_TRANSFORMERS,
        api_id="intfloat/e5-large-v2",
        supported_dimensions=[1024],
        default_dimension=1024,
        max_input_tokens=512,
        max_batch_size=32,
        normalize=True,
        description="E5 Large V2 - General-purpose embeddings by Microsoft",
    ),
    "all-MiniLM-L6": EmbeddingModelInfo(
        id="all-MiniLM-L6",
        provider=Provider.SENTENCE_TRANSFORMERS,
        api_id="sentence-transformers/all-MiniLM-L6-v2",
        supported_dimensions=[384],
        default_dimension=384,
        max_input_tokens=256,
        max_batch_size=64,
        normalize=True,
        description="MiniLM L6 - Fast, lightweight embeddings for prototyping",
    ),

    # Future models - commented out for reference
    # =========================================================================
    # # OPENAI
    # =========================================================================
    # "text-embedding-3-small": EmbeddingModelInfo(
    #     id="text-embedding-3-small",
    #     provider=Provider.OPENAI,
    #     api_id="text-embedding-3-small",
    #     supported_dimensions=[512, 1536],
    #     default_dimension=1536,
    #     max_input_tokens=8192,
    #     max_batch_size=100,
    #     normalize=True,
    #     description="OpenAI text-embedding-3-small - Fast and efficient",
    # ),
    # "text-embedding-3-large": EmbeddingModelInfo(
    #     id="text-embedding-3-large",
    #     provider=Provider.OPENAI,
    #     api_id="text-embedding-3-large",
    #     supported_dimensions=[256, 1024, 3072],
    #     default_dimension=3072,
    #     max_input_tokens=8192,
    #     max_batch_size=100,
    #     normalize=True,
    #     description="OpenAI text-embedding-3-large - Highest quality",
    # ),
    #
    # =========================================================================
    # # COHERE
    # =========================================================================
    # "embed-english-v3.0": EmbeddingModelInfo(
    #     id="embed-english-v3.0",
    #     provider=Provider.COHERE,
    #     api_id="embed-english-v3.0",
    #     supported_dimensions=[1024],
    #     default_dimension=1024,
    #     max_input_tokens=512,
    #     max_batch_size=96,
    #     normalize=False,
    #     description="Cohere Embed English V3 - English language optimized",
    # ),
}


# =============================================================================
# DEFAULT MODELS PER PROVIDER
# =============================================================================

DEFAULT_MODELS: Dict[Provider, str] = {
    Provider.BEDROCK: "titan-embed-v2",  # 1024 dimensions
    Provider.SENTENCE_TRANSFORMERS: "bge-m3",  # Best general-purpose
    Provider.LOCAL: None,  # Must specify model path
}


# =============================================================================
# API ID REVERSE LOOKUP
# =============================================================================
# Maps API model IDs back to friendly names for direct API ID usage

API_ID_TO_MODEL: Dict[str, str] = {
    model.api_id: model.id for model in MODELS.values()
}


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_model(model_id: str) -> Optional[EmbeddingModelInfo]:
    """
    Get embedding model info by ID (friendly name or API ID).

    Args:
        model_id: Model identifier (friendly name or raw API ID)

    Returns:
        EmbeddingModelInfo or None if not found

    Example:
        model = get_model("titan-embed-v2")
        if model:
            print(f"Supported dimensions: {model.supported_dimensions}")
    """
    # Try friendly name first
    if model_id in MODELS:
        return MODELS[model_id]

    # Try API ID lookup
    if model_id in API_ID_TO_MODEL:
        friendly_id = API_ID_TO_MODEL[model_id]
        return MODELS[friendly_id]

    return None


def list_models(provider: Optional[str] = None) -> List[EmbeddingModelInfo]:
    """
    List all available embedding models.

    Args:
        provider: Optional provider name to filter by ("bedrock", "openai", etc.)

    Returns:
        List of EmbeddingModelInfo objects

    Example:
        # List all models
        all_models = list_models()
        for model in all_models:
            print(f"{model.id}: {model.description}")

        # List only Bedrock models
        bedrock_models = list_models("bedrock")
    """
    models = list(MODELS.values())
    if provider:
        try:
            provider_enum = Provider(provider)
            models = [m for m in models if m.provider == provider_enum]
        except ValueError:
            return []  # Invalid provider
    return models


def get_default_model(provider: str) -> str:
    """
    Get default embedding model ID for a provider.

    Args:
        provider: Provider name ("bedrock", "openai", etc.)

    Returns:
        Default model ID for the provider

    Raises:
        ValueError: If provider is not recognized

    Example:
        default = get_default_model("bedrock")  # Returns "titan-embed-v2"
    """
    try:
        provider_enum = Provider(provider)
        default = DEFAULT_MODELS.get(provider_enum)
        if default:
            return default
        raise ValueError(f"No default model configured for provider: {provider}")
    except ValueError:
        valid_providers = ", ".join(p.value for p in Provider)
        raise ValueError(
            f"Unknown provider: '{provider}'. Valid providers: {valid_providers}"
        )


def resolve_model_id(model_id: str, provider: str) -> str:
    """
    Resolve friendly model ID to actual API model ID.

    Args:
        model_id: Friendly model name (e.g., "titan-embed-v2") or raw API ID
        provider: Provider name

    Returns:
        API model ID to send to the provider

    Raises:
        ValueError: If model exists but belongs to a different provider

    Example:
        api_id = resolve_model_id("titan-embed-v2", "bedrock")
        # Returns: "amazon.titan-embed-text-v2:0"
    """
    # Look up model (handles both friendly names and API IDs)
    model = get_model(model_id)

    if model:
        try:
            provider_enum = Provider(provider)
            if model.provider == provider_enum:
                return model.api_id
            else:
                # Model exists but for different provider - this is likely an error
                raise ValueError(
                    f"Model '{model_id}' belongs to provider '{model.provider.value}', "
                    f"not '{provider}'. Did you mean to use a different model or provider?"
                )
        except ValueError as e:
            if "Model '" in str(e):
                raise  # Re-raise our mismatch error
            # Invalid provider string
            valid_providers = ", ".join(p.value for p in Provider)
            raise ValueError(
                f"Unknown provider: '{provider}'. Valid providers: {valid_providers}"
            )

    # Not in registry - assume it's already an API ID, but warn
    logger.warning(
        f"Model '{model_id}' not found in registry. Using as raw API ID. "
        f"Consider adding this model to penguin/embeddings/models.py"
    )
    return model_id


def get_models_by_dimension(
    dimension: int,
    provider: Optional[str] = None
) -> List[EmbeddingModelInfo]:
    """
    Get embedding models that support a specific dimension.

    Args:
        dimension: Target embedding dimension
        provider: Optional provider name to filter by

    Returns:
        List of models supporting the specified dimension

    Example:
        # Find all 1024-dim models
        models_1024 = get_models_by_dimension(1024)

        # Find Bedrock models with 512 dimensions
        models_512 = get_models_by_dimension(512, "bedrock")
    """
    models = list_models(provider)
    return [m for m in models if m.supports_dimension(dimension)]


def get_model_capabilities(model_id: str) -> Dict[str, any]:
    """
    Get capabilities for a specific embedding model.

    Args:
        model_id: Model identifier

    Returns:
        Dict with capability information

    Example:
        caps = get_model_capabilities("titan-embed-v2")
        # Returns: {
        #     "supported_dimensions": [256, 512, 1024],
        #     "default_dimension": 1024,
        #     "max_input_tokens": 8192,
        #     "max_batch_size": 100,
        #     "normalize": True
        # }
    """
    model = MODELS.get(model_id)
    if model:
        return {
            "supported_dimensions": model.supported_dimensions,
            "default_dimension": model.default_dimension,
            "max_input_tokens": model.max_input_tokens,
            "max_batch_size": model.max_batch_size,
            "normalize": model.normalize,
        }
    return {
        "supported_dimensions": [1024],
        "default_dimension": 1024,
        "max_input_tokens": 8192,
        "max_batch_size": 100,
        "normalize": True,
    }


def validate_dimension(model_id: str, dimension: int) -> bool:
    """
    Check if a dimension is valid for a given model.

    Args:
        model_id: Model identifier
        dimension: Requested embedding dimension

    Returns:
        True if dimension is supported, False otherwise

    Example:
        if validate_dimension("titan-embed-v2", 512):
            print("512 dimensions supported!")
    """
    model = get_model(model_id)
    if model:
        return model.supports_dimension(dimension)
    # If model not found, assume dimension is valid
    return True
