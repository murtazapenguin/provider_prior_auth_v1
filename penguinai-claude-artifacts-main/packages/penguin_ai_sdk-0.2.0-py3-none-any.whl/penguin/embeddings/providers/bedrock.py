"""
Penguin AWS Bedrock Titan Embedding Provider

AWS Bedrock Titan Text Embeddings V2 implementation.
"""

import asyncio
import json
import os
from typing import Any, List, Optional

from ..base import (
    BaseEmbeddingProvider,
    EmbeddingError,
    AuthenticationError,
    RateLimitError,
    InvalidRequestError,
)
from ..types import EmbeddingResult, EmbeddingUsage, ProviderCapabilities


class BedrockTitanEmbeddingClient(BaseEmbeddingProvider):
    """
    AWS Bedrock Titan Text Embeddings V2 client.

    Supports:
    - Configurable dimensions (256, 512, 1024)
    - Batch embedding
    - Token usage tracking

    Uses AWS credentials from environment or boto3 credential chain.

    Example:
        client = BedrockTitanEmbeddingClient(dimensions=1024)
        result = await client.embed("Hello world")
        print(result.embedding)  # [0.123, 0.456, ...]
    """

    SUPPORTED_DIMENSIONS = [256, 512, 1024]
    DEFAULT_MODEL = "amazon.titan-embed-text-v2:0"

    def __init__(
        self,
        model: str = "amazon.titan-embed-text-v2:0",
        dimensions: int = 1024,
        region_name: Optional[str] = None,
        profile_name: Optional[str] = None,
        read_timeout: int = 120,
        connect_timeout: int = 60,
        max_retries: int = 3,
        **kwargs: Any
    ):
        """
        Initialize Bedrock Titan embedding client.

        Args:
            model: Model identifier (default: amazon.titan-embed-text-v2:0)
            dimensions: Embedding dimensions (256, 512, 1024)
            region_name: AWS region (falls back to AWS_DEFAULT_REGION)
            profile_name: AWS profile name for credentials
            read_timeout: Read timeout in seconds
            connect_timeout: Connection timeout in seconds
            max_retries: Max retry attempts
        """
        # Lazy import boto3 - gives clear error if not installed
        try:
            import boto3
            from botocore.config import Config as BotoConfig
        except ImportError:
            raise ImportError(
                "boto3 is required for Bedrock embeddings. "
                "Install with: pip install penguin-ai-sdk[embeddings]"
            )

        if dimensions not in self.SUPPORTED_DIMENSIONS:
            raise InvalidRequestError(
                f"Unsupported dimensions: {dimensions}. "
                f"Supported: {self.SUPPORTED_DIMENSIONS}",
                provider="bedrock"
            )

        super().__init__(model=model, dimensions=dimensions, **kwargs)

        region_name = region_name or os.environ.get("AWS_DEFAULT_REGION", "us-east-1")

        # Create boto3 session
        session_kwargs = {"region_name": region_name}
        if profile_name:
            session_kwargs["profile_name"] = profile_name

        boto_config = BotoConfig(
            read_timeout=read_timeout,
            connect_timeout=connect_timeout,
            retries={"max_attempts": max_retries, "mode": "adaptive"}
        )

        try:
            session = boto3.Session(**session_kwargs)
            self.client = session.client("bedrock-runtime", config=boto_config)
        except Exception as e:
            raise AuthenticationError(
                f"Failed to create Bedrock client: {e}",
                provider="bedrock"
            )

    @property
    def provider_name(self) -> str:
        return "bedrock"

    @property
    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            supported_dimensions=self.SUPPORTED_DIMENSIONS,
            max_batch_size=100,
            max_text_length=8192,
            supports_documents=True,
        )

    async def embed(
        self,
        text: str,
        normalize: bool = True,
        include_text: bool = False,
        **kwargs: Any
    ) -> EmbeddingResult:
        """
        Generate embedding for a single text.

        Args:
            text: Input text to embed
            normalize: Whether to normalize the embedding (default: True)
            include_text: Include original text in result (default: False)
            **kwargs: Additional parameters

        Returns:
            EmbeddingResult with vector and usage info
        """
        request_body = {
            "inputText": text,
            "dimensions": self.dimensions,
            "normalize": normalize,
        }

        loop = asyncio.get_event_loop()
        try:
            response = await loop.run_in_executor(
                None,
                lambda: self.client.invoke_model(
                    modelId=self.model,
                    body=json.dumps(request_body),
                    contentType="application/json",
                    accept="application/json"
                )
            )

            response_body = json.loads(response["body"].read())

            return EmbeddingResult(
                embedding=response_body["embedding"],
                dimensions=len(response_body["embedding"]),
                input_text=text if include_text else None,
                usage=EmbeddingUsage(
                    input_tokens=response_body.get("inputTextTokenCount", 0),
                    total_tokens=response_body.get("inputTextTokenCount", 0),
                ),
                model=self.model,
                provider=self.provider_name,
            )

        except self.client.exceptions.ThrottlingException as e:
            raise RateLimitError(str(e), provider=self.provider_name)
        except self.client.exceptions.ValidationException as e:
            raise InvalidRequestError(str(e), provider=self.provider_name)
        except Exception as e:
            if "ThrottlingException" in str(type(e).__name__):
                raise RateLimitError(str(e), provider=self.provider_name)
            raise EmbeddingError(str(e), provider=self.provider_name)

    async def embed_batch(
        self,
        texts: List[str],
        normalize: bool = True,
        max_concurrency: int = 10,
        **kwargs: Any
    ) -> List[EmbeddingResult]:
        """
        Generate embeddings for multiple texts.

        Note: Titan V2 requires individual API calls, so this uses
        concurrent execution for better performance.

        Args:
            texts: List of input texts
            normalize: Whether to normalize embeddings
            max_concurrency: Max concurrent requests
            **kwargs: Additional parameters

        Returns:
            List of EmbeddingResult objects
        """
        semaphore = asyncio.Semaphore(max_concurrency)

        async def embed_with_semaphore(text: str) -> EmbeddingResult:
            async with semaphore:
                return await self.embed(text, normalize=normalize, **kwargs)

        tasks = [embed_with_semaphore(text) for text in texts]
        return await asyncio.gather(*tasks)
