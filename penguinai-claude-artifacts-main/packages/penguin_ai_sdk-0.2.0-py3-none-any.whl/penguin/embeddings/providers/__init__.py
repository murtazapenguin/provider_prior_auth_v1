"""
Penguin Embeddings Providers

Available embedding provider implementations.
"""

from .bedrock import BedrockTitanEmbeddingClient

# Lazy import for sentence-transformers (optional dependency)
def _get_sentence_transformer_client():
    """Lazy loader to avoid requiring sentence-transformers at import time."""
    from .sentence_transformers import SentenceTransformerEmbeddingClient
    return SentenceTransformerEmbeddingClient

# Try direct import for type hints (fails silently if not installed)
try:
    from .sentence_transformers import SentenceTransformerEmbeddingClient
except ImportError:
    SentenceTransformerEmbeddingClient = None  # type: ignore

__all__ = [
    "BedrockTitanEmbeddingClient",
    "SentenceTransformerEmbeddingClient",
]
