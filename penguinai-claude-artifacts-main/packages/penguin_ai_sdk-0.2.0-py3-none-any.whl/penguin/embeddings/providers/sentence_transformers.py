"""
Penguin Sentence Transformers Embedding Provider

Open-source embedding models via sentence-transformers library.
Supports HuggingFace models and local/finetuned models.
"""

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, List, Optional, Union

from ..base import (
    BaseEmbeddingProvider,
    EmbeddingError,
    InvalidRequestError,
)
from ..types import EmbeddingResult, EmbeddingUsage, ProviderCapabilities

logger = logging.getLogger(__name__)


class SentenceTransformersNotInstalled(EmbeddingError):
    """Raised when sentence-transformers is not installed."""
    def __init__(self):
        super().__init__(
            "sentence-transformers is required for this provider. "
            "Install with: pip install sentence-transformers",
            provider="sentence_transformers"
        )


class SentenceTransformerEmbeddingClient(BaseEmbeddingProvider):
    """
    Embedding provider using sentence-transformers library.

    Supports:
    - HuggingFace model IDs (e.g., "BAAI/bge-m3")
    - Local model paths (e.g., "./my_finetuned_model")
    - Finetuned models from penguin.finetuning
    - Automatic device detection (CUDA/CPU)
    - Asymmetric encoding for query/document models

    Example:
        # HuggingFace model
        client = SentenceTransformerEmbeddingClient(model="BAAI/bge-m3")
        result = await client.embed("Hello world")

        # Local finetuned model
        client = SentenceTransformerEmbeddingClient(model="./my_model")

        # Query embedding (for asymmetric models)
        result = await client.embed_query("What is machine learning?")
    """

    # Models that benefit from query/passage prefixes
    ASYMMETRIC_MODELS = {
        "BAAI/bge-m3": ("", ""),  # BGE-M3 handles this internally
        "BAAI/bge-large-en-v1.5": ("query: ", ""),
        "BAAI/bge-base-en-v1.5": ("query: ", ""),
        "intfloat/e5-large-v2": ("query: ", "passage: "),
        "intfloat/e5-base-v2": ("query: ", "passage: "),
        "intfloat/e5-small-v2": ("query: ", "passage: "),
    }

    def __init__(
        self,
        model: str,
        dimensions: Optional[int] = None,
        device: str = "auto",
        normalize: bool = True,
        batch_size: int = 32,
        show_progress_bar: bool = False,
        **kwargs: Any
    ):
        """
        Initialize sentence-transformers embedding client.

        Args:
            model: HuggingFace model ID or local path to model directory
            dimensions: Embedding dimensions (auto-detected if not specified)
            device: Device to use ("auto", "cuda", "cpu", "mps")
            normalize: Whether to normalize embeddings (default: True)
            batch_size: Batch size for encoding (default: 32)
            show_progress_bar: Show progress bar during batch encoding
            **kwargs: Additional arguments passed to SentenceTransformer
        """
        self._check_dependencies()

        from sentence_transformers import SentenceTransformer

        # Resolve device
        resolved_device = self._resolve_device(device)

        # Load model - with fallback for transformers 4.57.x bug
        self._is_fallback_mode = False
        try:
            self._model = SentenceTransformer(model, device=resolved_device)
            logger.info(f"Loaded model '{model}' on device '{resolved_device}'")
        except AttributeError as e:
            # Workaround for transformers 4.57.x bug with AutoTokenizer
            if "'dict' object has no attribute 'model_type'" in str(e):
                logger.warning(f"Using fallback loading for '{model}' (transformers 4.57.x bug)")
                self._load_with_fallback(model, resolved_device)
            else:
                raise EmbeddingError(
                    f"Failed to load model '{model}': {e}",
                    provider="sentence_transformers"
                )
        except Exception as e:
            raise EmbeddingError(
                f"Failed to load model '{model}': {e}",
                provider="sentence_transformers"
            )

        # Auto-detect dimensions from model
        if dimensions is None:
            if self._is_fallback_mode:
                dimensions = self._fallback_model.config.hidden_size
            else:
                dimensions = self._model.get_sentence_embedding_dimension()

        super().__init__(model=model, dimensions=dimensions, **kwargs)

        self.normalize = normalize
        self.batch_size = batch_size
        self.show_progress_bar = show_progress_bar
        self._device = resolved_device

        # Detect if model needs asymmetric encoding
        self._query_prefix, self._passage_prefix = self._get_prefixes(model)

    def _load_with_fallback(self, model: str, device: str) -> None:
        """Fallback loading using transformers directly (for transformers 4.57.x bug)."""
        from transformers import AutoModel

        model_path = Path(model)

        # Read config to determine tokenizer class
        config_path = model_path / "config.json"
        if not config_path.exists():
            raise EmbeddingError(
                f"No config.json found at {model_path}",
                provider="sentence_transformers"
            )

        with open(config_path) as f:
            config = json.load(f)
        model_type = config.get("model_type", "")

        # Map model type to tokenizer class
        tokenizer_map = {
            "xlm-roberta": "XLMRobertaTokenizer",
            "bert": "BertTokenizer",
            "roberta": "RobertaTokenizer",
            "distilbert": "DistilBertTokenizer",
        }

        tokenizer_class_name = tokenizer_map.get(model_type)
        if not tokenizer_class_name:
            raise EmbeddingError(
                f"Unsupported model type for fallback loading: {model_type}",
                provider="sentence_transformers"
            )

        # Import and load the specific tokenizer class
        import transformers
        tokenizer_class = getattr(transformers, tokenizer_class_name)
        self._fallback_tokenizer = tokenizer_class.from_pretrained(
            str(model_path), local_files_only=True
        )

        # Load model
        self._fallback_model = AutoModel.from_pretrained(
            str(model_path), local_files_only=True
        )
        self._fallback_model.eval()

        if device != "cpu":
            self._fallback_model = self._fallback_model.to(device)

        self._is_fallback_mode = True
        logger.info(f"Loaded model '{model}' with fallback mode on device '{device}'")

    def _check_dependencies(self) -> None:
        """Check that sentence-transformers is installed."""
        try:
            import sentence_transformers  # noqa: F401
        except ImportError:
            raise SentenceTransformersNotInstalled()

    def _resolve_device(self, device: str) -> str:
        """Resolve 'auto' to actual device."""
        if device != "auto":
            return device

        try:
            import torch
            if torch.cuda.is_available():
                return "cuda"
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                return "mps"
            return "cpu"
        except ImportError:
            return "cpu"

    def _get_prefixes(self, model: str) -> tuple:
        """Get query/passage prefixes for asymmetric models."""
        # Check if model or its base is in asymmetric models
        for model_id, prefixes in self.ASYMMETRIC_MODELS.items():
            if model_id in model or model in model_id:
                return prefixes
        return ("", "")

    @property
    def provider_name(self) -> str:
        return "sentence_transformers"

    @property
    def capabilities(self) -> ProviderCapabilities:
        if self._is_fallback_mode:
            max_length = 512
        else:
            max_length = self._model.max_seq_length if hasattr(self._model, 'max_seq_length') else 512
        return ProviderCapabilities(
            supported_dimensions=[self.dimensions],
            max_batch_size=self.batch_size,
            max_text_length=max_length,
            supports_documents=True,
        )

    def _encode_with_fallback(
        self,
        texts: Union[str, List[str]],
        normalize: bool = True
    ) -> "numpy.ndarray":
        """Encode texts using fallback model with mean pooling."""
        import torch
        import numpy as np

        if isinstance(texts, str):
            texts = [texts]

        # Tokenize
        inputs = self._fallback_tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=512,
            return_tensors="pt"
        )

        # Move to device
        if self._device != "cpu":
            inputs = {k: v.to(self._device) for k, v in inputs.items()}

        # Forward pass
        with torch.no_grad():
            outputs = self._fallback_model(**inputs)

        # Mean pooling over sequence length (excluding padding)
        attention_mask = inputs["attention_mask"]
        token_embeddings = outputs.last_hidden_state
        input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        embeddings = torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(
            input_mask_expanded.sum(1), min=1e-9
        )

        # Normalize if requested
        if normalize:
            embeddings = torch.nn.functional.normalize(embeddings, p=2, dim=1)

        return embeddings.cpu().numpy()

    @property
    def device(self) -> str:
        """Return the device the model is running on."""
        return self._device

    async def embed(
        self,
        text: str,
        normalize: Optional[bool] = None,
        include_text: bool = False,
        **kwargs: Any
    ) -> EmbeddingResult:
        """
        Generate embedding for a single text (document/passage).

        Args:
            text: Input text to embed
            normalize: Whether to normalize (defaults to instance setting)
            include_text: Include original text in result
            **kwargs: Additional parameters

        Returns:
            EmbeddingResult with vector and metadata
        """
        if normalize is None:
            normalize = self.normalize

        # Add passage prefix if model uses asymmetric encoding
        prefixed_text = f"{self._passage_prefix}{text}" if self._passage_prefix else text

        loop = asyncio.get_event_loop()

        if self._is_fallback_mode:
            embedding = await loop.run_in_executor(
                None,
                lambda: self._encode_with_fallback(prefixed_text, normalize)
            )
            embedding = embedding[0]  # Get first (only) result
        else:
            embedding = await loop.run_in_executor(
                None,
                lambda: self._model.encode(
                    prefixed_text,
                    normalize_embeddings=normalize,
                    show_progress_bar=False,
                )
            )

        # Convert numpy array to list
        embedding_list = embedding.tolist()

        return EmbeddingResult(
            embedding=embedding_list,
            dimensions=len(embedding_list),
            input_text=text if include_text else None,
            usage=EmbeddingUsage(
                input_tokens=len(text.split()),  # Approximate token count
                total_tokens=len(text.split()),
            ),
            model=self.model,
            provider=self.provider_name,
        )

    async def embed_query(
        self,
        text: str,
        normalize: Optional[bool] = None,
        include_text: bool = False,
        **kwargs: Any
    ) -> EmbeddingResult:
        """
        Generate embedding for a query (for asymmetric retrieval).

        For models like BGE and E5, queries and documents should be
        encoded differently for optimal retrieval performance.

        Args:
            text: Query text to embed
            normalize: Whether to normalize (defaults to instance setting)
            include_text: Include original text in result
            **kwargs: Additional parameters

        Returns:
            EmbeddingResult with vector and metadata
        """
        if normalize is None:
            normalize = self.normalize

        # Add query prefix if model uses asymmetric encoding
        prefixed_text = f"{self._query_prefix}{text}" if self._query_prefix else text

        loop = asyncio.get_event_loop()

        if self._is_fallback_mode:
            embedding = await loop.run_in_executor(
                None,
                lambda: self._encode_with_fallback(prefixed_text, normalize)
            )
            embedding = embedding[0]  # Get first (only) result
        else:
            embedding = await loop.run_in_executor(
                None,
                lambda: self._model.encode(
                    prefixed_text,
                    normalize_embeddings=normalize,
                    show_progress_bar=False,
                )
            )

        embedding_list = embedding.tolist()

        return EmbeddingResult(
            embedding=embedding_list,
            dimensions=len(embedding_list),
            input_text=text if include_text else None,
            usage=EmbeddingUsage(
                input_tokens=len(text.split()),
                total_tokens=len(text.split()),
            ),
            model=self.model,
            provider=self.provider_name,
        )

    async def embed_batch(
        self,
        texts: List[str],
        normalize: Optional[bool] = None,
        batch_size: Optional[int] = None,
        show_progress_bar: Optional[bool] = None,
        **kwargs: Any
    ) -> List[EmbeddingResult]:
        """
        Generate embeddings for multiple texts.

        Uses sentence-transformers' native batching for efficiency.

        Args:
            texts: List of input texts
            normalize: Whether to normalize embeddings
            batch_size: Override default batch size
            show_progress_bar: Show encoding progress
            **kwargs: Additional parameters

        Returns:
            List of EmbeddingResult objects
        """
        if normalize is None:
            normalize = self.normalize
        if batch_size is None:
            batch_size = self.batch_size
        if show_progress_bar is None:
            show_progress_bar = self.show_progress_bar

        # Add passage prefix if model uses asymmetric encoding
        prefixed_texts = [
            f"{self._passage_prefix}{t}" if self._passage_prefix else t
            for t in texts
        ]

        loop = asyncio.get_event_loop()

        if self._is_fallback_mode:
            embeddings = await loop.run_in_executor(
                None,
                lambda: self._encode_with_fallback(prefixed_texts, normalize)
            )
        else:
            embeddings = await loop.run_in_executor(
                None,
                lambda: self._model.encode(
                    prefixed_texts,
                    normalize_embeddings=normalize,
                    batch_size=batch_size,
                    show_progress_bar=show_progress_bar,
                )
            )

        results = []
        for i, (text, embedding) in enumerate(zip(texts, embeddings)):
            embedding_list = embedding.tolist()
            results.append(EmbeddingResult(
                embedding=embedding_list,
                dimensions=len(embedding_list),
                input_text=None,
                usage=EmbeddingUsage(
                    input_tokens=len(text.split()),
                    total_tokens=len(text.split()),
                ),
                model=self.model,
                provider=self.provider_name,
            ))

        return results

    async def embed_queries_batch(
        self,
        texts: List[str],
        normalize: Optional[bool] = None,
        batch_size: Optional[int] = None,
        show_progress_bar: Optional[bool] = None,
        **kwargs: Any
    ) -> List[EmbeddingResult]:
        """
        Generate query embeddings for multiple texts.

        Args:
            texts: List of query texts
            normalize: Whether to normalize embeddings
            batch_size: Override default batch size
            show_progress_bar: Show encoding progress
            **kwargs: Additional parameters

        Returns:
            List of EmbeddingResult objects
        """
        if normalize is None:
            normalize = self.normalize
        if batch_size is None:
            batch_size = self.batch_size
        if show_progress_bar is None:
            show_progress_bar = self.show_progress_bar

        # Add query prefix if model uses asymmetric encoding
        prefixed_texts = [
            f"{self._query_prefix}{t}" if self._query_prefix else t
            for t in texts
        ]

        loop = asyncio.get_event_loop()

        if self._is_fallback_mode:
            embeddings = await loop.run_in_executor(
                None,
                lambda: self._encode_with_fallback(prefixed_texts, normalize)
            )
        else:
            embeddings = await loop.run_in_executor(
                None,
                lambda: self._model.encode(
                    prefixed_texts,
                    normalize_embeddings=normalize,
                    batch_size=batch_size,
                    show_progress_bar=show_progress_bar,
                )
            )

        results = []
        for i, (text, embedding) in enumerate(zip(texts, embeddings)):
            embedding_list = embedding.tolist()
            results.append(EmbeddingResult(
                embedding=embedding_list,
                dimensions=len(embedding_list),
                input_text=None,
                usage=EmbeddingUsage(
                    input_tokens=len(text.split()),
                    total_tokens=len(text.split()),
                ),
                model=self.model,
                provider=self.provider_name,
            ))

        return results
