"""
Penguin Embeddings Document Models

Standard document structures for embedding operations.
"""

from typing import Any, Dict, Optional
from pydantic import BaseModel, Field
from datetime import datetime


class DocumentChunk(BaseModel):
    """
    Standard document chunk for embedding.

    Represents a piece of text with associated metadata,
    suitable for embedding and vector storage.
    """
    # Required fields
    id: str = Field(..., description="Unique identifier for this chunk")
    content: str = Field(..., description="Text content to embed")

    # Optional metadata
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata (source, page, etc.)"
    )

    # Common optional fields for convenience
    source: Optional[str] = Field(None, description="Source file path")
    page: Optional[int] = Field(None, description="Page number")
    chunk_index: Optional[int] = Field(None, description="Chunk position in document")
    document_id: Optional[str] = Field(None, description="Parent document identifier")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict, merging optional fields into metadata"""
        result = {
            "id": self.id,
            "content": self.content,
            "metadata": self.metadata.copy()
        }

        # Add optional fields to metadata if present
        if self.source:
            result["metadata"]["source"] = self.source
        if self.page is not None:
            result["metadata"]["page"] = self.page
        if self.chunk_index is not None:
            result["metadata"]["chunk_index"] = self.chunk_index
        if self.document_id:
            result["metadata"]["document_id"] = self.document_id

        return result

    @classmethod
    def from_ocr_result(
        cls,
        ocr_result,
        chunk_size: int = 512,
        overlap: int = 50
    ) -> list["DocumentChunk"]:
        """
        Create DocumentChunks from OCR result.

        Args:
            ocr_result: OCRResult from penguin.ocr
            chunk_size: Max characters per chunk
            overlap: Overlap between chunks

        Returns:
            List of DocumentChunk objects
        """
        from pathlib import Path

        # Validate parameters to prevent infinite loop
        if overlap >= chunk_size:
            raise ValueError(f"overlap ({overlap}) must be less than chunk_size ({chunk_size})")
        if chunk_size <= 0:
            raise ValueError(f"chunk_size must be positive, got {chunk_size}")
        if overlap < 0:
            raise ValueError(f"overlap must be non-negative, got {overlap}")

        chunks = []
        text = ocr_result.full_text
        filename = Path(ocr_result.file_path).name

        # Simple chunking
        start = 0
        chunk_idx = 0
        while start < len(text):
            end = min(start + chunk_size, len(text))
            chunk_text = text[start:end]

            chunks.append(cls(
                id=f"{filename}_chunk_{chunk_idx}",
                content=chunk_text,
                source=ocr_result.file_path,
                document_id=filename,
                chunk_index=chunk_idx,
                metadata={
                    "provider": ocr_result.provider,
                    "total_chunks": -1  # Will be updated
                }
            ))

            # Move forward by (chunk_size - overlap) to ensure progress
            start += chunk_size - overlap
            chunk_idx += 1

        # Update total_chunks
        for chunk in chunks:
            chunk.metadata["total_chunks"] = len(chunks)

        return chunks


class EmbeddedDocument(BaseModel):
    """
    Document chunk with its embedding.

    Combines DocumentChunk with EmbeddingResult for convenience.
    """
    chunk: DocumentChunk
    embedding: list[float]
    dimensions: int
    model: str
    provider: str

    def to_vector_record(self):
        """Convert to VectorRecord for vector database storage"""
        from penguin.vector_db import VectorRecord

        # Merge all metadata
        metadata = self.chunk.to_dict()["metadata"]
        metadata.update({
            "content": self.chunk.content,
            "embedding_model": self.model,
            "embedding_provider": self.provider,
            "dimensions": self.dimensions
        })

        return VectorRecord(
            id=self.chunk.id,
            vector=self.embedding,
            metadata=metadata
        )
