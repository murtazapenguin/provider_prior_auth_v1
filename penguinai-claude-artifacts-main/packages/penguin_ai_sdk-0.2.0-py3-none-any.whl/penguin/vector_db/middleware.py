"""
Penguin Vector DB Middleware Module

Provides middleware-wrapped vector database clients for automatic tracing.
"""

import uuid
from typing import Any, Dict, List, Optional

from .base import BaseVectorDBProvider
from .types import (
    VectorRecord,
    VectorQueryResult,
    IndexConfig,
    DistanceMetric,
    ProviderCapabilities,
)


class MiddlewareWrappedVectorClient:
    """
    Wraps a vector database client to route all calls through middleware for tracing.

    This provides automatic OpenTelemetry span creation for all vector operations.
    """

    def __init__(
        self,
        client: BaseVectorDBProvider,
        middleware_chain: "MiddlewareChain",
    ):
        self._client = client
        self._chain = middleware_chain
        self._last_trace_id: Optional[str] = None

    def _create_context(
        self,
        operation: str,
        **kwargs
    ) -> "MiddlewareContext":
        """Create middleware context for an operation."""
        from penguin.observability.middleware import MiddlewareContext

        return MiddlewareContext(
            trace_id=str(uuid.uuid4()),
            span_id=str(uuid.uuid4())[:16],
            span_name=f"vector_db.{operation}",
            span_type="vector_db",
            provider=self._client.provider_name,
            model=None,
            inputs=kwargs,
            attributes={
                "vector_db.operation": operation,
                "vector_db.bucket": self._client.bucket_name,
            }
        )

    # ================== BUCKET OPERATIONS ==================

    async def create_bucket(
        self,
        bucket_name: str,
        **kwargs: Any
    ) -> bool:
        """Create bucket with tracing."""
        context = self._create_context("create_bucket", bucket_name=bucket_name)

        async def _execute(*args, **kw):
            return await self._client.create_bucket(bucket_name, **kwargs)

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id
        return result

    async def delete_bucket(
        self,
        bucket_name: str,
        **kwargs: Any
    ) -> bool:
        """Delete bucket with tracing."""
        context = self._create_context("delete_bucket", bucket_name=bucket_name)

        async def _execute(*args, **kw):
            return await self._client.delete_bucket(bucket_name, **kwargs)

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id
        return result

    async def list_buckets(self, **kwargs: Any) -> List[str]:
        """List buckets with tracing."""
        context = self._create_context("list_buckets")

        async def _execute(*args, **kw):
            return await self._client.list_buckets(**kwargs)

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id
        return result

    async def bucket_exists(self, bucket_name: str) -> bool:
        """Check if bucket exists with tracing."""
        context = self._create_context("bucket_exists", bucket_name=bucket_name)

        async def _execute(*args, **kw):
            return await self._client.bucket_exists(bucket_name)

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id
        return result

    # ================== INDEX OPERATIONS ==================

    async def create_index(
        self,
        index_name: str,
        dimension: int,
        distance_metric: DistanceMetric = DistanceMetric.COSINE,
        data_type: str = "float32",
        **kwargs: Any
    ) -> bool:
        """Create index with tracing."""
        context = self._create_context(
            "create_index",
            index_name=index_name,
            dimension=dimension,
            distance_metric=distance_metric.value,
            data_type=data_type,
        )

        async def _execute(*args, **kw):
            return await self._client.create_index(
                index_name, dimension, distance_metric, data_type=data_type, **kwargs
            )

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id
        return result

    async def delete_index(
        self,
        index_name: str,
        **kwargs: Any
    ) -> bool:
        """Delete index with tracing."""
        context = self._create_context("delete_index", index_name=index_name)

        async def _execute(*args, **kw):
            return await self._client.delete_index(index_name, **kwargs)

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id
        return result

    async def list_indexes(self, **kwargs: Any) -> List[IndexConfig]:
        """List indexes with tracing."""
        context = self._create_context("list_indexes")

        async def _execute(*args, **kw):
            return await self._client.list_indexes(**kwargs)

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id
        return result

    async def index_exists(self, index_name: str, bucket_name: Optional[str] = None) -> bool:
        """Check if index exists with tracing."""
        context = self._create_context(
            "index_exists",
            index_name=index_name,
            bucket_name=bucket_name
        )

        async def _execute(*args, **kw):
            return await self._client.index_exists(index_name, bucket_name)

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id
        return result

    # ================== VECTOR OPERATIONS ==================

    async def put_vectors(
        self,
        index_name: str,
        vectors: List[VectorRecord],
        **kwargs: Any
    ) -> int:
        """Put vectors with tracing."""
        context = self._create_context(
            "put_vectors",
            index_name=index_name,
            vector_count=len(vectors),
        )

        async def _execute(*args, **kw):
            return await self._client.put_vectors(index_name, vectors, **kwargs)

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id
        context.outputs = {"vectors_inserted": result}
        return result

    async def get_vectors(
        self,
        index_name: str,
        ids: List[str],
        **kwargs: Any
    ) -> List[VectorRecord]:
        """Get vectors with tracing."""
        context = self._create_context(
            "get_vectors",
            index_name=index_name,
            id_count=len(ids),
        )

        async def _execute(*args, **kw):
            return await self._client.get_vectors(index_name, ids, **kwargs)

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id
        return result

    async def delete_vectors(
        self,
        index_name: str,
        ids: List[str],
        **kwargs: Any
    ) -> int:
        """Delete vectors with tracing."""
        context = self._create_context(
            "delete_vectors",
            index_name=index_name,
            id_count=len(ids),
        )

        async def _execute(*args, **kw):
            return await self._client.delete_vectors(index_name, ids, **kwargs)

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id
        return result

    async def query_vectors(
        self,
        index_name: str,
        vector: List[float],
        top_k: int = 10,
        filter: Optional[Dict[str, Any]] = None,
        include_metadata: bool = True,
        include_vectors: bool = False,
        **kwargs: Any
    ) -> VectorQueryResult:
        """Query vectors with tracing."""
        context = self._create_context(
            "query_vectors",
            index_name=index_name,
            top_k=top_k,
            has_filter=filter is not None,
            vector_dimension=len(vector),
        )

        async def _execute(*args, **kw):
            return await self._client.query_vectors(
                index_name, vector, top_k, filter,
                include_metadata, include_vectors, **kwargs
            )

        result = await self._chain.execute(context, _execute)
        self._last_trace_id = context.trace_id
        context.outputs = {"matches_found": len(result.matches)}
        return result

    # Proxy properties
    @property
    def provider_name(self) -> str:
        return self._client.provider_name

    @property
    def bucket_name(self) -> Optional[str]:
        return self._client.bucket_name

    @property
    def capabilities(self) -> ProviderCapabilities:
        return self._client.capabilities

    @property
    def last_trace_id(self) -> Optional[str]:
        return self._last_trace_id


def get_vector_middleware_chain() -> "MiddlewareChain":
    """Get middleware chain for vector database operations."""
    from penguin.observability.config import is_tracing_enabled
    from penguin.observability.middleware import MiddlewareChain, OTelMiddleware

    chain = MiddlewareChain()
    if is_tracing_enabled():
        chain.add(OTelMiddleware(
            tracer_name="penguin.vector_db",
            capture_prompts=False,
            capture_completions=False,
        ))
    return chain
