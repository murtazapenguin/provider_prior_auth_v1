"""
Penguin Vector DB Factory Module

Factory functions for creating vector database clients.
"""

import os
from typing import Optional, Union

from .base import BaseVectorDBProvider
from .middleware import MiddlewareWrappedVectorClient


# Provider registry - lazy imports to avoid loading all dependencies
PROVIDER_CLASSES = {
    "s3vectors": ("penguin.vector_db.providers.s3vectors", "S3VectorsClient"),
}


def _import_provider_class(provider: str) -> type:
    """Dynamically import provider class to avoid loading all dependencies."""
    if provider not in PROVIDER_CLASSES:
        raise ValueError(
            f"Unknown provider: {provider}. "
            f"Available providers: {', '.join(PROVIDER_CLASSES.keys())}"
        )

    module_path, class_name = PROVIDER_CLASSES[provider]

    import importlib
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def create_vector_client(
    provider: str = "s3vectors",
    bucket_name: Optional[str] = None,
    enable_tracing: Optional[bool] = None,
    **kwargs
) -> Union[BaseVectorDBProvider, MiddlewareWrappedVectorClient]:
    """
    Create a vector database client.

    Args:
        provider: Provider name ("s3vectors")
        bucket_name: Default bucket/namespace name
        enable_tracing: Override tracing (None = use env var)
        **kwargs: Provider-specific config (region_name, profile_name)

    Returns:
        Configured vector database client

    Example:
        # Create S3 Vectors client
        client = create_vector_client("s3vectors", bucket_name="my-vectors")
        await client.create_index("embeddings", dimension=1024)
        await client.put_vectors("embeddings", vectors)

        # With custom region
        client = create_vector_client(
            "s3vectors",
            bucket_name="my-vectors",
            region_name="us-west-2",
            profile_name="my-profile"
        )
    """
    provider = provider.lower()

    client_class = _import_provider_class(provider)
    client = client_class(bucket_name=bucket_name, **kwargs)

    # Determine if tracing is enabled
    if enable_tracing is None:
        from penguin.observability.config import is_tracing_enabled
        tracing = is_tracing_enabled()
    else:
        tracing = enable_tracing

    # Wrap with middleware if tracing enabled
    if tracing:
        from penguin.observability import setup_tracing
        setup_tracing()
        from .middleware import get_vector_middleware_chain
        chain = get_vector_middleware_chain()
        return MiddlewareWrappedVectorClient(client, chain)

    return client


def create_vector_client_from_env(
    bucket_name: Optional[str] = None,
    enable_tracing: Optional[bool] = None,
    **kwargs
) -> Union[BaseVectorDBProvider, MiddlewareWrappedVectorClient]:
    """
    Create a vector database client using environment variables for configuration.

    Checks for AWS credentials to determine provider.

    Args:
        bucket_name: Default bucket name
        enable_tracing: Override tracing
        **kwargs: Additional configuration

    Returns:
        Configured vector database client
    """
    # Check for AWS credentials
    if any([
        os.environ.get("AWS_ACCESS_KEY_ID"),
        os.environ.get("AWS_PROFILE"),
        os.environ.get("AWS_ROLE_ARN"),
    ]):
        return create_vector_client(
            "s3vectors",
            bucket_name=bucket_name,
            enable_tracing=enable_tracing,
            **kwargs
        )

    raise ValueError(
        "No vector database provider credentials found. "
        "Set AWS credentials for S3 Vectors."
    )
