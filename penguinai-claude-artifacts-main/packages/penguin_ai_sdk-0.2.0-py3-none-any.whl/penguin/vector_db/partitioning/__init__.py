"""
Penguin Vector DB Partitioning Module

Provides partitioning, namespacing, and tenant isolation for vector databases.
"""

from .types import (
    PartitionStrategy,
    PartitionConfig,
    PartitionKey,
    TenantIsolationLevel,
)
from .strategies import (
    BasePartitionStrategy,
    HashPartitionStrategy,
    RangePartitionStrategy,
    ListPartitionStrategy,
)
from .namespace import NamespaceManager, Namespace
from .tenant_manager import TenantManager, TenantConfig

__all__ = [
    # Types
    "PartitionStrategy",
    "PartitionConfig",
    "PartitionKey",
    "TenantIsolationLevel",
    # Strategies
    "BasePartitionStrategy",
    "HashPartitionStrategy",
    "RangePartitionStrategy",
    "ListPartitionStrategy",
    # Namespace
    "NamespaceManager",
    "Namespace",
    # Tenant Management
    "TenantManager",
    "TenantConfig",
]
