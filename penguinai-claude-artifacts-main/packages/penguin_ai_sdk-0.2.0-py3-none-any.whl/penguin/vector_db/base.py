"""
Penguin Vector DB Base Module

Abstract base class for all vector database implementations.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

from .types import (
    VectorRecord,
    VectorQueryResult,
    IndexConfig,
    DistanceMetric,
    ProviderCapabilities,
)


class BaseVectorDBProvider(ABC):
    """
    Abstract base class for vector database implementations.

    Provides unified interface for vector storage and retrieval
    operations across different providers.
    """

    def __init__(
        self,
        bucket_name: Optional[str] = None,
        **kwargs: Any
    ):
        """
        Initialize the vector database provider.

        Args:
            bucket_name: Vector bucket/namespace name
            **kwargs: Provider-specific configuration
        """
        self.bucket_name = bucket_name
        self.config = kwargs

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Return the provider name (e.g., 's3vectors')."""
        pass

    @property
    @abstractmethod
    def capabilities(self) -> ProviderCapabilities:
        """Return provider capabilities."""
        pass

    # ================== BUCKET OPERATIONS ==================

    @abstractmethod
    async def create_bucket(
        self,
        bucket_name: str,
        **kwargs: Any
    ) -> bool:
        """
        Create a new vector bucket.

        Args:
            bucket_name: Name of the bucket to create
            **kwargs: Additional configuration

        Returns:
            True if created successfully
        """
        pass

    @abstractmethod
    async def delete_bucket(
        self,
        bucket_name: str,
        **kwargs: Any
    ) -> bool:
        """
        Delete a vector bucket.

        Args:
            bucket_name: Name of the bucket to delete
            **kwargs: Additional configuration

        Returns:
            True if deleted successfully
        """
        pass

    @abstractmethod
    async def list_buckets(
        self,
        **kwargs: Any
    ) -> List[str]:
        """
        List all vector buckets.

        Returns:
            List of bucket names
        """
        pass

    # ================== INDEX OPERATIONS ==================

    @abstractmethod
    async def create_index(
        self,
        index_name: str,
        dimension: int,
        distance_metric: DistanceMetric = DistanceMetric.COSINE,
        data_type: str = "float32",
        **kwargs: Any
    ) -> bool:
        """
        Create a new vector index within a bucket.

        Args:
            index_name: Name of the index
            dimension: Vector dimension
            distance_metric: Distance metric (cosine, euclidean)
            data_type: Vector data type (default: float32)
            **kwargs: Additional index configuration

        Returns:
            True if created successfully
        """
        pass

    @abstractmethod
    async def delete_index(
        self,
        index_name: str,
        **kwargs: Any
    ) -> bool:
        """
        Delete a vector index.

        Args:
            index_name: Name of the index to delete

        Returns:
            True if deleted successfully
        """
        pass

    @abstractmethod
    async def list_indexes(
        self,
        **kwargs: Any
    ) -> List[IndexConfig]:
        """
        List all indexes in the current bucket.

        Returns:
            List of IndexConfig objects
        """
        pass

    # ================== VECTOR OPERATIONS ==================

    @abstractmethod
    async def put_vectors(
        self,
        index_name: str,
        vectors: List[VectorRecord],
        **kwargs: Any
    ) -> int:
        """
        Insert or update vectors in an index.

        Args:
            index_name: Target index name
            vectors: List of VectorRecord objects
            **kwargs: Additional parameters

        Returns:
            Number of vectors successfully inserted
        """
        pass

    @abstractmethod
    async def get_vectors(
        self,
        index_name: str,
        ids: List[str],
        **kwargs: Any
    ) -> List[VectorRecord]:
        """
        Retrieve vectors by ID.

        Args:
            index_name: Index name
            ids: List of vector IDs

        Returns:
            List of VectorRecord objects
        """
        pass

    @abstractmethod
    async def delete_vectors(
        self,
        index_name: str,
        ids: List[str],
        **kwargs: Any
    ) -> int:
        """
        Delete vectors by ID.

        Args:
            index_name: Index name
            ids: List of vector IDs to delete

        Returns:
            Number of vectors deleted
        """
        pass

    @abstractmethod
    async def query_vectors(
        self,
        index_name: str,
        vector: List[float],
        top_k: int = 10,
        filter: Optional[Dict[str, Any]] = None,
        include_metadata: bool = True,
        include_vectors: bool = False,
        **kwargs: Any
    ) -> VectorQueryResult:
        """
        Query for similar vectors with optional metadata filtering.

        Filtering enables efficient subset queries, multi-tenant isolation,
        time-range searches, and category filtering. Reduces query cost and
        improves performance by scanning only relevant vectors.

        Args:
            index_name: Index name to query
            vector: Query vector (embedding)
            top_k: Number of results to return (default: 10)
            filter: Metadata filter conditions (optional)
                   Dictionary with field-value pairs or comparison operators.
                   Multiple conditions are ANDed together.

                   Examples:
                   - Simple: {"category": "engineering"}
                   - Multiple: {"category": "engineering", "status": "published"}
                   - Comparison: {"rating": {"$gte": 4.0}}
                   - Range: {"created_at": {"$gte": "2024-01-01", "$lte": "2024-12-31"}}
                   - Multi-tenant: {"tenant_id": "acme_corp"}

                   Supported operators (provider-dependent):
                   - $eq: Equal to
                   - $ne: Not equal to
                   - $gt: Greater than
                   - $gte: Greater than or equal
                   - $lt: Less than
                   - $lte: Less than or equal
                   - $in: Value in list
                   - $nin: Value not in list
                   - $or: OR condition (list of conditions)
                   - $and: AND condition (list of conditions)

            include_metadata: Include metadata in results (default: True)
            include_vectors: Include vector values in results (default: False)
            **kwargs: Additional provider-specific arguments

        Returns:
            VectorQueryResult with matches sorted by similarity score

        Examples:
            # Basic query without filtering
            results = await client.query_vectors(
                "documents",
                vector=query_embedding,
                top_k=10
            )

            # Query with category filter
            results = await client.query_vectors(
                "documents",
                vector=query_embedding,
                filter={"category": "engineering"}
            )

            # Multi-tenant query with filtering
            results = await client.query_vectors(
                "documents",
                vector=query_embedding,
                filter={"tenant_id": "acme_corp", "status": "published"}
            )

            # Time-range query
            results = await client.query_vectors(
                "logs",
                vector=query_embedding,
                filter={"timestamp": {"$gte": "2024-01-01"}}
            )

        Performance:
            Filtering typically provides:
            - 10-20x faster queries (50ms vs 500ms)
            - 10-100x cost reduction
            - Essential for multi-tenant applications

        Note:
            Filter syntax may vary by provider. Consult provider-specific
            documentation for exact filter expression syntax.
        """
        pass


# ================== EXCEPTIONS ==================

class VectorDBError(Exception):
    """Base exception for vector database errors."""

    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        status_code: Optional[int] = None,
    ):
        self.provider = provider
        self.status_code = status_code
        super().__init__(message)


class BucketNotFoundError(VectorDBError):
    """Bucket does not exist."""
    pass


class BucketAlreadyExistsError(VectorDBError):
    """Bucket already exists."""
    pass


class IndexNotFoundError(VectorDBError):
    """Index does not exist."""
    pass


class IndexAlreadyExistsError(VectorDBError):
    """Index already exists."""
    pass


class AuthenticationError(VectorDBError):
    """Authentication failed."""
    pass


class RateLimitError(VectorDBError):
    """Rate limit exceeded."""
    pass
