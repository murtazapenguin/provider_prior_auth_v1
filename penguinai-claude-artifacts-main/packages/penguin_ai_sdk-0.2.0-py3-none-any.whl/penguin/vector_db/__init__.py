"""
Penguin Vector DB Module

Vector database abstraction supporting AWS S3 Vectors.

Usage:
    from penguin.vector_db import (
        create_vector_client,
        VectorRecord,
        list_providers,
        get_provider,
        DistanceMetric
    )

    # List all available vector database providers
    providers = list_providers()
    for provider in providers:
        print(f"{provider.id}: {provider.description}")

    # Get provider info
    provider = get_provider("s3vectors")
    print(provider.supported_metrics)  # [DistanceMetric.COSINE, DistanceMetric.EUCLIDEAN]
    print(provider.max_vector_dimension)  # 4096

    # Create S3 Vectors client
    client = create_vector_client("s3vectors", bucket_name="my-vectors")

    # Create an index
    await client.create_index("embeddings", dimension=1024)

    # Store vectors
    vectors = [
        VectorRecord(id="doc1", vector=[0.1, 0.2, ...], metadata={"source": "file.pdf"}),
        VectorRecord(id="doc2", vector=[0.3, 0.4, ...], metadata={"source": "file2.pdf"}),
    ]
    await client.put_vectors("embeddings", vectors)

    # Query for similar vectors
    results = await client.query_vectors("embeddings", query_vector, top_k=10)
    for match in results.matches:
        print(f"{match.id}: {match.score}")
"""

from .factory import create_vector_client, create_vector_client_from_env
from .base import (
    BaseVectorDBProvider,
    VectorDBError,
    BucketNotFoundError,
    BucketAlreadyExistsError,
    IndexNotFoundError,
    IndexAlreadyExistsError,
    AuthenticationError,
    RateLimitError,
)
from .types import (
    VectorRecord,
    VectorMatch,
    VectorQueryResult,
    IndexConfig,
    BucketConfig,
    DistanceMetric,
    ProviderCapabilities,
)
from .models import (
    VectorDBInfo,
    Provider,
    list_providers,
    get_provider,
    get_default_provider,
    get_providers_by_metric,
    get_providers_by_dimension,
    get_cloud_providers,
    get_self_hosted_providers,
    get_provider_capabilities,
    validate_metric,
    validate_dimension,
    compare_providers,
)
from .providers.s3vectors import S3VectorsClient

__all__ = [
    # Factory
    "create_vector_client",
    "create_vector_client_from_env",
    # Base
    "BaseVectorDBProvider",
    "VectorDBError",
    "BucketNotFoundError",
    "BucketAlreadyExistsError",
    "IndexNotFoundError",
    "IndexAlreadyExistsError",
    "AuthenticationError",
    "RateLimitError",
    # Types
    "VectorRecord",
    "VectorMatch",
    "VectorQueryResult",
    "IndexConfig",
    "BucketConfig",
    "DistanceMetric",
    "ProviderCapabilities",
    # Provider Registry
    "VectorDBInfo",
    "Provider",
    "list_providers",
    "get_provider",
    "get_default_provider",
    "get_providers_by_metric",
    "get_providers_by_dimension",
    "get_cloud_providers",
    "get_self_hosted_providers",
    "get_provider_capabilities",
    "validate_metric",
    "validate_dimension",
    "compare_providers",
    # Providers
    "S3VectorsClient",
]
