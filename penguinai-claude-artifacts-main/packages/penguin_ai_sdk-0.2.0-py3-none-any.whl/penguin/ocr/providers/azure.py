import os
import asyncio
import time
from typing import List, Tuple

from azure.core.credentials import AzureKeyCredential
from azure.ai.formrecognizer.aio import DocumentAnalysisClient

from ..base import BaseOCRProvider
from ..models import OCRResult, OCRLine
from ...observability.decorator import observe


class AzureOCRProvider(BaseOCRProvider):
    def __init__(self, endpoint: str = None, key: str = None, model_id: str = "prebuilt-read"):
        self.endpoint = endpoint or os.environ.get("AZURE_OCR_ENDPOINT")
        self.key = key or os.environ.get("AZURE_OCR_SECRET_KEY")
        self.model_id = model_id

        if not self.endpoint or not self.key:
            raise ValueError("Azure credentials missing. Set AZURE_OCR_ENDPOINT + AZURE_OCR_SECRET_KEY.")

    async def _get_client(self):
        """Creates and returns the async client."""
        return DocumentAnalysisClient(
            endpoint=self.endpoint, 
            credential=AzureKeyCredential(self.key)
        )

    def _parse_azure_result(self, file_path: str, azure_result) -> OCRResult:
        """Converts Azure specific response to Penguin standard format."""
        all_lines_data = []
        final_text_parts = []

        # Extract page dimensions for metadata
        page_dimensions = []
        for page in azure_result.pages:
            page_dimensions.append({
                "page_number": page.page_number,
                "width": page.width,
                "height": page.height,
                "unit": page.unit
            })

            for line_idx, line in enumerate(page.lines, start=1):
                # Convert Azure Point to Dict
                bbox = [{"x": point.x, "y": point.y} for point in line.polygon]

                line_obj = OCRLine(
                    content=line.content,
                    page_number=page.page_number,
                    line_number=line_idx,
                    bounding_box=bbox,
                    confidence=line.confidence if hasattr(line, 'confidence') else None
                )
                all_lines_data.append(line_obj)
                final_text_parts.append(f"{line.content} || {line_idx}")

        return OCRResult(
            file_path=file_path,
            full_text="\n".join(final_text_parts),
            lines=all_lines_data,
            provider="azure_document_intelligence",
            metadata={
                "model_id": self.model_id,
                "page_dimensions": page_dimensions
            }
        )

    # @observe(type="ocr", model_provider="azure-document-intelligence")
    async def process_file(self, file_path: str) -> OCRResult:
        """
        Performs OCR on a single file using Azure.
        """
        async with await self._get_client() as client:
            try:
                with open(file_path, 'rb') as f:
                    document_bytes = f.read()

                poller = await client.begin_analyze_document(
                    model_id=self.model_id, 
                    document=document_bytes
                )
                result = await poller.result()
                
                return self._parse_azure_result(file_path, result)
            except Exception as e:
                # In a real library, you might want to raise a custom PenguinException
                raise RuntimeError(f"Azure OCR failed for {file_path}: {str(e)}")

    async def _process_with_semaphore(self, file_path: str, semaphore: asyncio.Semaphore) -> OCRResult:
        async with semaphore:
            return await self.process_file(file_path)

    async def process_batch(self, file_paths: List[str], max_concurrency: int = 5) -> List[OCRResult]:
        """
        Processes a list of files in parallel using Azure.
        """
        print(f"--- [Penguin] Starting Batch OCR for {len(file_paths)} files ---")
        start_time = time.time()
        
        semaphore = asyncio.Semaphore(max_concurrency)
        tasks = [self._process_with_semaphore(f, semaphore) for f in file_paths]
        
        # return_exceptions=True allows the batch to complete even if one file fails
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        valid_results = []
        for i, res in enumerate(results):
            if isinstance(res, Exception):
                print(f"[ERROR] Failed to process {file_paths[i]}: {res}")
            else:
                valid_results.append(res)

        end_time = time.time()
        print(f"--- [Penguin] Finished in {end_time - start_time:.2f} seconds ---")
        return valid_results