"""
Penguin Observability Exporter Base

Abstract base class for trace exporters.
"""

from abc import ABC, abstractmethod
from typing import Any


class BaseExporter(ABC):
    """
    Abstract base class for trace exporters.

    Exporters are responsible for sending completed trace data
    to external systems or storage.
    """

    @abstractmethod
    def export(self, span: Any) -> bool:
        """
        Export a completed span.

        Args:
            span: The span/trace data to export

        Returns:
            True if export succeeded, False otherwise
        """
        pass

    @abstractmethod
    def flush(self) -> None:
        """Flush any buffered data."""
        pass

    @abstractmethod
    def shutdown(self) -> None:
        """Shutdown the exporter and release resources."""
        pass
