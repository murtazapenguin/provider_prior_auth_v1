"""
Penguin OTLP Exporter

Exports trace data via OpenTelemetry Protocol (OTLP).
"""

import logging
from typing import Any, Dict, Optional

from .base import BaseExporter

logger = logging.getLogger("penguin.observability")


class OTLPExporter(BaseExporter):
    """
    Exports traces via OTLP (OpenTelemetry Protocol).

    This is a wrapper that configures OpenTelemetry's OTLP exporter.
    Requires opentelemetry-exporter-otlp-proto-http or grpc package.
    """

    def __init__(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        protocol: str = "http",  # "http" or "grpc"
        timeout: int = 30,
    ):
        """
        Initialize OTLP exporter.

        Args:
            endpoint: OTLP endpoint URL
            headers: Optional headers for authentication
            protocol: "http" or "grpc"
            timeout: Request timeout in seconds
        """
        self.endpoint = endpoint
        self.headers = headers or {}
        self.protocol = protocol
        self.timeout = timeout

        self._exporter = None
        self._span_processor = None
        self._initialized = False

        self._initialize()

    def _initialize(self) -> None:
        """Initialize the OTLP exporter."""
        try:
            from opentelemetry import trace
            from opentelemetry.sdk.trace import TracerProvider
            from opentelemetry.sdk.trace.export import BatchSpanProcessor

            if self.protocol == "grpc":
                from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
                    OTLPSpanExporter,
                )
            else:
                from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
                    OTLPSpanExporter,
                )

            # Create exporter
            exporter_kwargs = {
                "endpoint": self.endpoint,
                "timeout": self.timeout,
            }
            if self.headers:
                exporter_kwargs["headers"] = self.headers

            self._exporter = OTLPSpanExporter(**exporter_kwargs)
            self._span_processor = BatchSpanProcessor(self._exporter)

            # Get or create tracer provider
            provider = trace.get_tracer_provider()
            if not isinstance(provider, TracerProvider):
                provider = TracerProvider()
                trace.set_tracer_provider(provider)

            provider.add_span_processor(self._span_processor)
            self._initialized = True

            logger.info(f"OTLP exporter initialized: {self.endpoint}")

        except ImportError as e:
            logger.warning(
                f"OpenTelemetry OTLP exporter not available: {e}. "
                "Install opentelemetry-exporter-otlp-proto-http or grpc."
            )
        except Exception as e:
            logger.error(f"Failed to initialize OTLP exporter: {e}")

    def export(self, span: Any) -> bool:
        """
        Export a span via OTLP.

        Note: When using OpenTelemetry's span processor, spans are
        automatically exported when ended. This method is for compatibility
        with the BaseExporter interface.

        Args:
            span: Span data (primarily for file-based exporters)

        Returns:
            True if initialized, False otherwise
        """
        # OTLP exports happen automatically through the span processor
        # This is mainly a compatibility stub
        return self._initialized

    def flush(self) -> None:
        """Force flush pending spans."""
        if self._span_processor:
            try:
                self._span_processor.force_flush()
            except Exception as e:
                logger.error(f"Failed to flush OTLP exporter: {e}")

    def shutdown(self) -> None:
        """Shutdown the OTLP exporter."""
        if self._span_processor:
            try:
                self._span_processor.shutdown()
            except Exception as e:
                logger.error(f"Failed to shutdown OTLP exporter: {e}")


class OTLPGrpcExporter(OTLPExporter):
    """OTLP exporter using gRPC protocol."""

    def __init__(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        timeout: int = 30,
    ):
        super().__init__(
            endpoint=endpoint,
            headers=headers,
            protocol="grpc",
            timeout=timeout,
        )
