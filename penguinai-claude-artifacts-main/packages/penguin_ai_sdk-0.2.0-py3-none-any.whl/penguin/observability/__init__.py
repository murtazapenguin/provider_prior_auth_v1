"""
Penguin Observability Module (DEPRECATED)

.. deprecated:: 0.2.0
    Use ``penguin.core.tracing`` instead. This module delegates to the new
    Langfuse-based tracing system. The old OpenTelemetry exports are still
    available for backward compatibility but will be removed in v0.3.0.

New Usage:
    from penguin.core.tracing import observe, get_callback_handler, is_tracing_enabled
"""

import warnings as _warnings

_warnings.warn(
    "penguin.observability is deprecated since v0.2.0. "
    "Use penguin.core.tracing instead.",
    DeprecationWarning,
    stacklevel=2,
)

# New Langfuse-based tracing (preferred)
from penguin.core.tracing import (
    observe,
    is_tracing_enabled,
    get_callback_handler,
    flush_traces,
    score_current_trace,
)

# Backward-compatible aliases
setup_tracing = flush_traces  # best-effort compat
shutdown_tracing = flush_traces


def get_middleware_chain():
    """Deprecated. Use LangChain callbacks instead."""
    _warnings.warn(
        "get_middleware_chain() is deprecated. Use penguin.core.callbacks instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return []


def auto_setup_if_enabled():
    """Deprecated. Langfuse auto-initializes from env vars."""
    _warnings.warn(
        "auto_setup_if_enabled() is deprecated. Langfuse initializes automatically.",
        DeprecationWarning,
        stacklevel=2,
    )


# Stubs for old exports that no longer apply
def get_file_exporter():
    _warnings.warn("get_file_exporter() is deprecated.", DeprecationWarning, stacklevel=2)
    return None


def get_exporter():
    _warnings.warn("get_exporter() is deprecated.", DeprecationWarning, stacklevel=2)
    return None


def get_current_trace_id():
    _warnings.warn("get_current_trace_id() is deprecated.", DeprecationWarning, stacklevel=2)
    return None


def get_current_span_id():
    _warnings.warn("get_current_span_id() is deprecated.", DeprecationWarning, stacklevel=2)
    return None


def get_current_project_id():
    _warnings.warn("get_current_project_id() is deprecated.", DeprecationWarning, stacklevel=2)
    return None


def set_trace_context(*args, **kwargs):
    _warnings.warn("set_trace_context() is deprecated.", DeprecationWarning, stacklevel=2)


def reset_context():
    _warnings.warn("reset_context() is deprecated.", DeprecationWarning, stacklevel=2)


def get_config():
    _warnings.warn("get_config() is deprecated.", DeprecationWarning, stacklevel=2)
    return None


def set_config(*args, **kwargs):
    _warnings.warn("set_config() is deprecated.", DeprecationWarning, stacklevel=2)


def should_capture_content():
    return True


def get_tracer(*args, **kwargs):
    _warnings.warn("get_tracer() is deprecated.", DeprecationWarning, stacklevel=2)
    return None


def provider_to_system(provider: str) -> str:
    return provider


__all__ = [
    "observe",
    "is_tracing_enabled",
    "get_callback_handler",
    "flush_traces",
    "score_current_trace",
    "setup_tracing",
    "shutdown_tracing",
    "get_middleware_chain",
    "auto_setup_if_enabled",
    "get_file_exporter",
    "get_exporter",
    "get_current_trace_id",
    "get_current_span_id",
    "get_current_project_id",
    "set_trace_context",
    "reset_context",
    "get_config",
    "set_config",
    "should_capture_content",
    "get_tracer",
    "provider_to_system",
]
