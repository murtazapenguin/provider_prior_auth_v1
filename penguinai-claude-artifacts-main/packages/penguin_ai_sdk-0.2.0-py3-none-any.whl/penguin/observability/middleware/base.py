"""
Penguin Observability Middleware Base

Defines the middleware chain pattern for observability.
"""

from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class MiddlewareContext(BaseModel):
    """
    Context passed through the middleware chain.

    Carries information about the operation being traced.
    """
    # Span identification
    trace_id: str
    span_id: str
    parent_span_id: Optional[str] = None
    project_id: str = "default"

    # Operation info
    span_name: str
    span_type: str = "chain"  # llm, tool, chain, ocr, vlm

    # Timing
    start_time: float = 0.0
    end_time: Optional[float] = None

    # Provider info (for LLM operations)
    provider: Optional[str] = None
    model: Optional[str] = None

    # Request info
    inputs: Dict[str, Any] = Field(default_factory=dict)
    request_params: Dict[str, Any] = Field(default_factory=dict)

    # Response info (populated after execution)
    outputs: Optional[Any] = None
    status: str = "RUNNING"
    error: Optional[str] = None

    # Token usage (for LLM operations)
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    thinking_tokens: Optional[int] = None
    cached_tokens: Optional[int] = None

    # Additional attributes
    attributes: Dict[str, Any] = Field(default_factory=dict)

    class Config:
        extra = "allow"


class BaseMiddleware(ABC):
    """
    Base class for observability middleware.

    Middleware can intercept and modify the context at different stages:
    - before_execute: Before the wrapped function runs
    - after_execute: After successful execution
    - on_error: When an error occurs
    """

    @abstractmethod
    def before_execute(self, context: MiddlewareContext) -> MiddlewareContext:
        """
        Called before the wrapped function executes.

        Args:
            context: Current middleware context

        Returns:
            Modified context
        """
        pass

    @abstractmethod
    def after_execute(
        self,
        context: MiddlewareContext,
        result: Any
    ) -> MiddlewareContext:
        """
        Called after successful execution.

        Args:
            context: Current middleware context
            result: The result from the wrapped function

        Returns:
            Modified context
        """
        pass

    @abstractmethod
    def on_error(
        self,
        context: MiddlewareContext,
        error: Exception
    ) -> MiddlewareContext:
        """
        Called when an error occurs.

        Args:
            context: Current middleware context
            error: The exception that was raised

        Returns:
            Modified context
        """
        pass


class MiddlewareChain:
    """
    Chain of middleware that process observability context.

    Middleware are executed in order for before_execute,
    and in reverse order for after_execute and on_error.
    """

    def __init__(self, middlewares: Optional[List[BaseMiddleware]] = None):
        """
        Initialize middleware chain.

        Args:
            middlewares: List of middleware to use
        """
        self._middlewares: List[BaseMiddleware] = middlewares or []

    def add(self, middleware: BaseMiddleware) -> "MiddlewareChain":
        """
        Add middleware to the chain.

        Args:
            middleware: Middleware to add

        Returns:
            Self for chaining
        """
        self._middlewares.append(middleware)
        return self

    def before_execute(self, context: MiddlewareContext) -> MiddlewareContext:
        """Run before_execute on all middleware in order."""
        for middleware in self._middlewares:
            context = middleware.before_execute(context)
        return context

    def after_execute(
        self,
        context: MiddlewareContext,
        result: Any
    ) -> MiddlewareContext:
        """Run after_execute on all middleware in reverse order."""
        for middleware in reversed(self._middlewares):
            context = middleware.after_execute(context, result)
        return context

    def on_error(
        self,
        context: MiddlewareContext,
        error: Exception
    ) -> MiddlewareContext:
        """Run on_error on all middleware in reverse order."""
        for middleware in reversed(self._middlewares):
            context = middleware.on_error(context, error)
        return context

    async def execute(
        self,
        context: MiddlewareContext,
        func: Callable[..., T],
        *args,
        **kwargs
    ) -> T:
        """
        Execute a function wrapped in the middleware chain.

        Args:
            context: Initial middleware context
            func: Function to execute
            *args, **kwargs: Arguments for the function

        Returns:
            Result from the function

        Raises:
            Any exception from the function
        """
        import asyncio
        import time

        context.start_time = time.time()
        context = self.before_execute(context)

        try:
            if asyncio.iscoroutinefunction(func):
                result = await func(*args, **kwargs)
            else:
                result = func(*args, **kwargs)

            context.end_time = time.time()
            context.status = "OK"
            context = self.after_execute(context, result)
            return result

        except Exception as e:
            context.end_time = time.time()
            context.status = "ERROR"
            context.error = str(e)
            context = self.on_error(context, e)
            raise

    def execute_sync(
        self,
        context: MiddlewareContext,
        func: Callable[..., T],
        *args,
        **kwargs
    ) -> T:
        """
        Execute a sync function wrapped in the middleware chain.

        Args:
            context: Initial middleware context
            func: Function to execute
            *args, **kwargs: Arguments for the function

        Returns:
            Result from the function

        Raises:
            Any exception from the function
        """
        import time

        context.start_time = time.time()
        context = self.before_execute(context)

        try:
            result = func(*args, **kwargs)
            context.end_time = time.time()
            context.status = "OK"
            context = self.after_execute(context, result)
            return result

        except Exception as e:
            context.end_time = time.time()
            context.status = "ERROR"
            context.error = str(e)
            context = self.on_error(context, e)
            raise

    async def execute_stream(
        self,
        context: MiddlewareContext,
        async_gen_func: Callable[..., Any],
        *args,
        **kwargs
    ):
        """
        Execute an async generator function wrapped in the middleware chain.

        This method is designed for streaming operations where the result
        is yielded incrementally (e.g., LLM streaming responses).

        Args:
            context: Initial middleware context
            async_gen_func: Async generator function to execute
            *args, **kwargs: Arguments for the function

        Yields:
            Items from the async generator

        Raises:
            Any exception from the function

        Example:
            ```python
            async def my_stream():
                for i in range(10):
                    yield i

            async for item in chain.execute_stream(context, my_stream):
                print(item)
            ```
        """
        import time

        context.start_time = time.time()
        context = self.before_execute(context)

        try:
            async for item in async_gen_func(*args, **kwargs):
                # Optionally allow middleware to process chunks
                for mw in self._middlewares:
                    if hasattr(mw, 'on_chunk'):
                        item = mw.on_chunk(context, item)
                yield item

            context.end_time = time.time()
            context.status = "OK"
            # Pass None as result since streaming doesn't have a single result
            context = self.after_execute(context, None)

        except Exception as e:
            context.end_time = time.time()
            context.status = "ERROR"
            context.error = str(e)
            context = self.on_error(context, e)
            raise
