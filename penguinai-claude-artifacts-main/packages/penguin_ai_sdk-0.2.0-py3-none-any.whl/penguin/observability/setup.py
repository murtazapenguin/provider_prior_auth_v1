"""
Penguin Observability Setup

Consolidated setup for OpenTelemetry-based tracing with file export.
This replaces the dual tracing system with a unified OTel pipeline.
"""

import logging
import os
from typing import Optional

logger = logging.getLogger("penguin.observability")

# Global state
_initialized = False
_tracer_provider = None
_file_exporter = None


def setup_tracing(
    service_name: str = "penguin",
    filepath: str = "penguin_traces.jsonl",
    otlp_endpoint: Optional[str] = None,
    otlp_headers: Optional[dict] = None,
    capture_prompts: bool = True,
    capture_completions: bool = True,
) -> bool:
    """
    Set up the consolidated OTel tracing pipeline.

    This configures OpenTelemetry with:
    1. File exporter (always) - writes to JSONL
    2. OTLP exporter (optional) - sends to collector

    Args:
        service_name: Service name for traces
        filepath: Path for JSONL trace file
        otlp_endpoint: Optional OTLP endpoint URL
        otlp_headers: Optional headers for OTLP authentication
        capture_prompts: Whether to capture prompt content
        capture_completions: Whether to capture completion content

    Returns:
        True if setup succeeded

    Example:
        from penguin.observability import setup_tracing

        # Basic setup with file export only
        setup_tracing()

        # With OTLP export to Jaeger/Grafana
        # Note: Use base URL only - /v1/traces is appended automatically
        setup_tracing(
            otlp_endpoint="http://localhost:4318",
            service_name="my-app"
        )
    """
    global _initialized, _tracer_provider, _file_exporter

    if _initialized:
        logger.debug("Tracing already initialized")
        return True

    try:
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import SimpleSpanProcessor, BatchSpanProcessor
        from opentelemetry.sdk.resources import Resource, SERVICE_NAME

        from .exporters.otel_file import OTelFileExporter

        # Create resource with service name
        resource = Resource.create({SERVICE_NAME: service_name})

        # Create tracer provider
        _tracer_provider = TracerProvider(resource=resource)

        # Add file exporter (always)
        _file_exporter = OTelFileExporter(filepath=filepath)
        _tracer_provider.add_span_processor(
            SimpleSpanProcessor(_file_exporter)
        )
        logger.info(f"File exporter configured: {filepath}")

        # Add OTLP exporter if endpoint provided
        endpoint = otlp_endpoint or os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
        if endpoint:
            try:
                from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
                    OTLPSpanExporter,
                )

                headers = otlp_headers or {}
                headers_env = os.environ.get("OTEL_EXPORTER_OTLP_HEADERS", "")
                if headers_env:
                    for pair in headers_env.split(","):
                        if "=" in pair:
                            k, v = pair.split("=", 1)
                            headers[k.strip()] = v.strip()

                otlp_exporter = OTLPSpanExporter(endpoint=endpoint, headers=headers)
                _tracer_provider.add_span_processor(
                    BatchSpanProcessor(otlp_exporter)
                )
                logger.info(f"OTLP exporter configured: {endpoint}")

            except ImportError:
                logger.warning(
                    "OTLP exporter not available. Install opentelemetry-exporter-otlp-proto-http"
                )

        # Set as global tracer provider
        trace.set_tracer_provider(_tracer_provider)
        _initialized = True

        logger.info("Penguin tracing initialized (unified OTel pipeline)")
        return True

    except ImportError as e:
        logger.warning(f"OpenTelemetry not available: {e}")
        return False
    except Exception as e:
        logger.error(f"Failed to setup tracing: {e}")
        return False


def get_file_exporter():
    """
    Get the file exporter for reading/clearing traces.

    Returns:
        OTelFileExporter instance or None
    """
    return _file_exporter


def shutdown_tracing():
    """Shutdown the tracing pipeline and flush remaining spans."""
    global _initialized, _tracer_provider, _file_exporter

    if _tracer_provider:
        _tracer_provider.shutdown()

    _initialized = False
    _tracer_provider = None
    _file_exporter = None


def is_tracing_enabled() -> bool:
    """
    Check if tracing is enabled via environment variable.

    Controlled by PENGUIN_ENABLE_TRACING environment variable.
    Default is False (opt-in).
    """
    return os.environ.get("PENGUIN_ENABLE_TRACING", "false").lower() in ("true", "1", "yes")


def auto_setup_if_enabled():
    """
    Automatically setup tracing if enabled via environment.

    Called automatically when the observability module is imported
    and PENGUIN_ENABLE_TRACING=true.
    """
    if is_tracing_enabled() and not _initialized:
        filepath = os.environ.get("PENGUIN_TRACE_FILE_PATH", "penguin_traces.jsonl")
        service_name = os.environ.get("OTEL_SERVICE_NAME", "penguin")
        setup_tracing(service_name=service_name, filepath=filepath)
