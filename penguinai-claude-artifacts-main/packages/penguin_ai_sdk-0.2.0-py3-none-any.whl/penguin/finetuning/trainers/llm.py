"""
Penguin LLM Finetuning Trainer

Uses Unsloth + TRL SFTTrainer for efficient LLM finetuning.
"""

import time
from pathlib import Path
from typing import Optional, Any

from ..base import BaseTrainer, DependencyError, TrainingError
from ..config import TrainingConfig, DataConfig, TrainingResult
from ..models import get_model, resolve_model_id
from ..callbacks import ProgressCallback, LossThresholdStoppingCallback, MetricLoggingCallback


class LLMTrainer(BaseTrainer):
    """
    LLM Finetuning trainer using Unsloth and TRL.

    Features:
    - 4-bit quantization via Unsloth
    - LoRA adapters
    - Train on responses only (optional)
    - Progress callbacks

    Example:
        trainer = LLMTrainer(
            model_name="qwen3-14b",
            training_config=TrainingConfig.default_llm(),
            data_config=DataConfig(dataset_path="data.csv"),
            output_dir="./adapter"
        )

        with trainer:
            trainer.load_model()
            trainer.load_dataset()
            result = trainer.train()
            trainer.save()
    """

    @property
    def trainer_type(self) -> str:
        return "llm"

    def _check_dependencies(self) -> None:
        """Check that required dependencies are installed."""
        try:
            from unsloth import FastLanguageModel  # noqa: F401
            self._use_unsloth = True
        except ImportError:
            # Fall back to standard transformers
            try:
                from transformers import AutoModelForCausalLM  # noqa: F401
                from trl import SFTTrainer  # noqa: F401
                from peft import get_peft_model  # noqa: F401
                self._use_unsloth = False
            except ImportError as e:
                raise DependencyError(
                    package=str(e.name),
                    trainer_type="llm",
                    install_hint="pip install penguin-ai-sdk[finetuning-unsloth]"
                )

    def load_model(self) -> None:
        """Load model with Unsloth optimizations or standard transformers."""
        self._check_dependencies()

        model_info = get_model(self.model_name)
        hf_model_id = resolve_model_id(self.model_name, "llm")
        max_seq_length = model_info.max_seq_length if model_info else 32000

        if self._use_unsloth:
            self._load_model_unsloth(hf_model_id, max_seq_length)
        else:
            self._load_model_transformers(hf_model_id, max_seq_length)

    def _load_model_unsloth(self, hf_model_id: str, max_seq_length: int) -> None:
        """Load model using Unsloth for optimized training."""
        from unsloth import FastLanguageModel

        # Load base model with 4-bit quantization
        use_4bit = self.training_config.quantization.value in ("int4", "nf4")

        self._model, self._tokenizer = FastLanguageModel.from_pretrained(
            model_name=hf_model_id,
            max_seq_length=max_seq_length,
            dtype=None,  # Auto-detect
            load_in_4bit=use_4bit,
        )

        # Apply LoRA
        if self.training_config.lora:
            lora = self.training_config.lora
            self._model = FastLanguageModel.get_peft_model(
                self._model,
                r=lora.r,
                target_modules=lora.target_modules,
                lora_alpha=lora.lora_alpha,
                lora_dropout=lora.lora_dropout,
                bias=lora.bias,
                use_gradient_checkpointing="unsloth",
                use_rslora=lora.use_rslora,
            )

    def _load_model_transformers(self, hf_model_id: str, max_seq_length: int) -> None:
        """Load model using standard transformers + PEFT."""
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
        from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training

        # Quantization config
        use_4bit = self.training_config.quantization.value in ("int4", "nf4")
        bnb_config = None

        if use_4bit:
            bnb_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.bfloat16,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_use_double_quant=True,
            )

        # Load model
        self._model = AutoModelForCausalLM.from_pretrained(
            hf_model_id,
            quantization_config=bnb_config,
            torch_dtype=torch.bfloat16 if self.training_config.bf16 else torch.float16,
            device_map="auto",
        )

        self._tokenizer = AutoTokenizer.from_pretrained(hf_model_id)

        if self._tokenizer.pad_token is None:
            self._tokenizer.pad_token = self._tokenizer.eos_token

        # Prepare for k-bit training and apply LoRA
        if use_4bit:
            self._model = prepare_model_for_kbit_training(self._model)

        if self.training_config.lora:
            lora = self.training_config.lora
            lora_config = LoraConfig(
                r=lora.r,
                lora_alpha=lora.lora_alpha,
                lora_dropout=lora.lora_dropout,
                target_modules=lora.target_modules,
                bias=lora.bias,
                task_type="CAUSAL_LM",
            )
            self._model = get_peft_model(self._model, lora_config)

    def load_dataset(self) -> None:
        """Load and prepare dataset."""
        import pandas as pd
        from datasets import Dataset

        # Load CSV
        df = pd.read_csv(self.data_config.dataset_path)

        # Validate columns
        input_col = self.data_config.input_column
        output_col = self.data_config.output_column
        reasoning_col = self.data_config.reasoning_column

        if input_col not in df.columns:
            raise ValueError(f"Input column '{input_col}' not found in dataset")
        if output_col not in df.columns:
            raise ValueError(f"Output column '{output_col}' not found in dataset")

        # Validate reasoning column if specified
        if reasoning_col:
            if reasoning_col not in df.columns:
                raise ValueError(f"Reasoning column '{reasoning_col}' not found in dataset")

            # Check if model supports thinking tokens
            model_info = get_model(self.model_name)
            if model_info and not model_info.thinking_start:
                supported_models = self._get_thinking_supported_models()
                raise ValueError(
                    f"Model '{self.model_name}' does not have official thinking token support. "
                    f"Models with thinking support: {', '.join(supported_models)}"
                )

        # Apply chat template
        def format_row(row):
            messages = []
            if self.data_config.system_prompt:
                messages.append({"role": "system", "content": str(self.data_config.system_prompt)})

            user_content = str(row[input_col])
            if self.data_config.user_prompt:
                user_content = f"{self.data_config.user_prompt}\n{user_content}"

            messages.append({"role": "user", "content": user_content})

            # Build assistant message with optional thinking
            assistant_msg = {"role": "assistant", "content": str(row[output_col])}
            if reasoning_col:
                reasoning = str(row[reasoning_col])
                if reasoning and reasoning.strip() and reasoning.lower() != 'nan':
                    assistant_msg["thinking"] = reasoning

            messages.append(assistant_msg)

            # Use custom thinking template if reasoning is present
            if reasoning_col and "thinking" in assistant_msg:
                return self._apply_thinking_template(messages)
            else:
                return self._tokenizer.apply_chat_template(messages, tokenize=False)

        df["final_text"] = df.apply(format_row, axis=1)

        # Filter by length
        df["token_len"] = df["final_text"].apply(
            lambda x: len(self._tokenizer(x)["input_ids"])
        )

        model_info = get_model(self.model_name)
        max_len = model_info.max_seq_length if model_info else self.data_config.max_seq_length

        original_len = len(df)
        df = df[df["token_len"] <= max_len].reset_index(drop=True)

        if len(df) < original_len:
            print(f"Filtered {original_len - len(df)} examples exceeding max length {max_len}")

        if len(df) == 0:
            raise ValueError("No examples remaining after length filtering")

        self._dataset = Dataset.from_pandas(df[["final_text"]])

    def train(self) -> TrainingResult:
        """Execute training."""
        from trl import SFTConfig, SFTTrainer

        start_time = time.time()
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Build training config kwargs
        trainer_kwargs = self.training_config.to_trainer_kwargs()
        trainer_kwargs["output_dir"] = str(self.output_dir)
        trainer_kwargs["packing"] = False
        trainer_kwargs["dataset_num_proc"] = 2
        trainer_kwargs["dataset_text_field"] = "final_text"

        sft_config = SFTConfig(**trainer_kwargs)

        # Build callbacks
        metric_callback = MetricLoggingCallback()
        callbacks = [
            LossThresholdStoppingCallback(threshold=0.01),
            ProgressCallback(str(self.output_dir)),
            metric_callback,
        ]

        # Create trainer
        self._trainer = SFTTrainer(
            model=self._model,
            train_dataset=self._dataset,
            callbacks=callbacks,
            args=sft_config,
            processing_class=self._tokenizer,
        )

        # Apply train on responses only if configured and using Unsloth
        if self.training_config.completion_only and self._use_unsloth:
            model_info = get_model(self.model_name)
            if model_info and model_info.instruction_template:
                from unsloth.chat_templates import train_on_responses_only
                self._trainer = train_on_responses_only(
                    self._trainer,
                    instruction_part=model_info.instruction_template["instruction_part"],
                    response_part=model_info.instruction_template["response_part"],
                    num_proc=2,
                )

        # Train
        try:
            train_result = self._trainer.train()
            training_time = time.time() - start_time

            return TrainingResult(
                success=True,
                output_path=str(self.output_dir),
                final_loss=metric_callback.get_final_loss(),
                total_steps=train_result.global_step,
                training_time_seconds=training_time,
                metrics=train_result.metrics if hasattr(train_result, 'metrics') else {},
            )
        except Exception as e:
            return TrainingResult(
                success=False,
                output_path=str(self.output_dir),
                error_message=str(e),
                training_time_seconds=time.time() - start_time,
            )

    def save(self, save_path: Optional[str] = None) -> str:
        """Save adapter and tokenizer."""
        path = Path(save_path or self.output_dir)
        path.mkdir(parents=True, exist_ok=True)

        self._model.save_pretrained(path)
        self._tokenizer.save_pretrained(path)

        return str(path)

    def _get_thinking_supported_models(self) -> list:
        """Get list of models that support thinking tokens."""
        from ..models import LLM_MODELS
        return [
            model_id for model_id, info in LLM_MODELS.items()
            if info.thinking_start is not None
        ]

    def _apply_thinking_template(self, messages: list) -> str:
        """
        Apply chat template with thinking token support.

        Wraps the thinking content in model-specific thinking tokens.
        """
        model_info = get_model(self.model_name)
        if not model_info:
            # Fall back to standard template for unknown models
            return self._tokenizer.apply_chat_template(messages, tokenize=False)

        think_start = model_info.thinking_start
        think_end = model_info.thinking_end

        # Build custom Jinja2 template with thinking support
        # This template handles system, user, and assistant messages
        # with special handling for assistant thinking content
        if "qwen" in self.model_name.lower():
            # Qwen3 template with thinking tokens
            custom_template = (
                "{% for message in messages %}"
                "{% if message['role'] == 'system' %}"
                "{{ '<|im_start|>system\\n' + message['content'] + '<|im_end|>\\n' }}"
                "{% elif message['role'] == 'user' %}"
                "{{ '<|im_start|>user\\n' + message['content'] + '<|im_end|>\\n' }}"
                "{% elif message['role'] == 'assistant' %}"
                "{{ '<|im_start|>assistant' }}"
                "{% if message.thinking is defined and message.thinking is not none %}"
                f"{{{{ '\\n{think_start}\\n' + message.thinking + '\\n{think_end}' }}}}"
                "{% endif %}"
                "{{ '\\n' + message.content }}"
                "{{ '<|im_end|>\\n' }}"
                "{% endif %}"
                "{% endfor %}"
            )
        elif "phi" in self.model_name.lower():
            # Phi-4 template with thinking tokens
            custom_template = (
                "{% for message in messages %}"
                "{% if message['role'] == 'system' %}"
                "{{ '<|im_start|>system\\n' + message['content'] + '<|im_end|>\\n' }}"
                "{% elif message['role'] == 'user' %}"
                "{{ '<|im_start|>user\\n' + message['content'] + '<|im_end|>\\n' }}"
                "{% elif message['role'] == 'assistant' %}"
                "{{ '<|im_start|>assistant\\n' }}"
                "{% if message.thinking is defined and message.thinking is not none %}"
                f"{{{{ '{think_start}\\n' + message.thinking + '\\n{think_end}\\n' }}}}"
                "{% endif %}"
                "{{ message.content }}"
                "{{ '<|im_end|>\\n' }}"
                "{% endif %}"
                "{% endfor %}"
            )
        elif "mistral" in self.model_name.lower():
            # Mistral template with thinking tokens
            custom_template = (
                "{% for message in messages %}"
                "{% if message['role'] == 'system' %}"
                "{{ '[INST] ' + message['content'] + ' [/INST]' }}"
                "{% elif message['role'] == 'user' %}"
                "{{ '[INST] ' + message['content'] + ' [/INST]' }}"
                "{% elif message['role'] == 'assistant' %}"
                "{% if message.thinking is defined and message.thinking is not none %}"
                f"{{{{ '{think_start}\\n' + message.thinking + '\\n{think_end}\\n' }}}}"
                "{% endif %}"
                "{{ message.content }}"
                "{% endif %}"
                "{% endfor %}"
            )
        else:
            # Default: fall back to standard template
            return self._tokenizer.apply_chat_template(messages, tokenize=False)

        # Apply the custom template
        from jinja2 import Template
        template = Template(custom_template)
        return template.render(messages=messages)
