"""
Penguin Finetuning Module

Programmatic finetuning for LLMs, rerankers, and embedding models.

Usage:
    from penguin.finetuning import train, create_trainer, TrainingConfig, DataConfig

    # Simple high-level API
    result = train(
        "llm",
        dataset_path="data.csv",
        model="qwen3-14b",
        output_dir="./adapter",
        max_steps=100,
    )

    # Or use the trainer directly for more control
    trainer = create_trainer(
        "llm",
        model="qwen3-14b",
        training_config=TrainingConfig(max_steps=100),
        data_config=DataConfig(dataset_path="data.csv"),
    )

    with trainer:  # Auto cleanup
        trainer.load_model()
        trainer.load_dataset()
        result = trainer.train()
        trainer.save()

Installation:
    pip install penguin-ai-sdk[finetuning]           # Basic
    pip install penguin-ai-sdk[finetuning-unsloth]   # With Unsloth acceleration
    pip install penguin-ai-sdk[finetuning-embedding] # With sentence-transformers
    pip install penguin-ai-sdk[finetuning-vllm]      # With vLLM serving

Inference:
    from penguin.finetuning.inference import (
        EmbeddingInference,  # Bi-encoder embeddings
        RerankerInference,   # Cross-encoder scoring
        UnslothInference,    # Local LLM inference
        vLLMServer,          # Production LLM serving
        serve,               # Quick server setup
        infer,               # Quick inference
    )
"""

# Factory functions
from .factory import (
    create_trainer,
    train,
    get_available_trainers,
)

# Configuration
from .config import (
    TrainingConfig,
    DataConfig,
    LoRAConfig,
    TrainingResult,
    TrainingProgress,
    QuantizationType,
    OptimizerType,
    LRSchedulerType,
    EmbeddingLossType,
)

# Model registry
from .models import (
    FinetuneModelInfo,
    TrainerType,
    list_models,
    get_model,
    get_default_model,
    resolve_model_id,
    LLM_MODELS,
    RERANKER_MODELS,
    EMBEDDING_MODELS,
)

# Base class (for custom trainers)
from .base import (
    BaseTrainer,
    FinetuningError,
    ModelNotSupportedError,
    DatasetError,
    TrainingError,
    DependencyError,
)

# Utilities
from .utils import (
    cleanup_gpu_memory,
    get_device,
    is_bfloat16_supported,
    get_gpu_memory_info,
    check_dependencies,
    get_lora_target_modules,
    print_lora_modules,
)

# Dataset validation
from .datasets import (
    validate_llm_dataset,
    validate_reranker_dataset,
    validate_embedding_dataset,
)

# Inference (submodule)
from . import inference

__all__ = [
    # Factory
    "create_trainer",
    "train",
    "get_available_trainers",
    # Config
    "TrainingConfig",
    "DataConfig",
    "LoRAConfig",
    "TrainingResult",
    "TrainingProgress",
    "QuantizationType",
    "OptimizerType",
    "LRSchedulerType",
    "EmbeddingLossType",
    # Models
    "FinetuneModelInfo",
    "TrainerType",
    "list_models",
    "get_model",
    "get_default_model",
    "resolve_model_id",
    "LLM_MODELS",
    "RERANKER_MODELS",
    "EMBEDDING_MODELS",
    # Base
    "BaseTrainer",
    "FinetuningError",
    "ModelNotSupportedError",
    "DatasetError",
    "TrainingError",
    "DependencyError",
    # Utilities
    "cleanup_gpu_memory",
    "get_device",
    "is_bfloat16_supported",
    "get_gpu_memory_info",
    "check_dependencies",
    "get_lora_target_modules",
    "print_lora_modules",
    # Dataset validation
    "validate_llm_dataset",
    "validate_reranker_dataset",
    "validate_embedding_dataset",
    # Inference submodule
    "inference",
]
