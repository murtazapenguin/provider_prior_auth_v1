"""
Penguin Unsloth LLM Inference

Local LLM inference using Unsloth's optimized inference path.
"""

from typing import List, Optional, Dict, Any, Generator, Union
from pathlib import Path

from .base import BaseInferenceEngine, DependencyError
from .config import InferenceConfig


class UnslothInference(BaseInferenceEngine):
    """
    LLM inference engine using Unsloth.

    Provides 2x faster inference through Unsloth's optimized path.
    Supports both raw text generation and chat completion.

    Example:
        engine = UnslothInference(
            adapter_path="./llm_adapter",
            base_model="qwen3-4b",
        )

        # Generate text
        response = engine.generate("What is machine learning?")

        # Stream tokens
        for token in engine.generate_stream("Explain AI"):
            print(token, end="")

        # Chat completion
        response = engine.chat([
            {"role": "user", "content": "Hello!"}
        ])
    """

    def __init__(
        self,
        adapter_path: str,
        base_model: Optional[str] = None,
        config: Optional[InferenceConfig] = None,
        device: str = "auto",
        **kwargs
    ):
        """
        Initialize Unsloth inference engine.

        Args:
            adapter_path: Path to the LoRA adapter
            base_model: Base model name from registry (e.g., "qwen3-4b")
            config: Inference configuration
            device: Device to use ("auto", "cuda", "cpu")
        """
        super().__init__(adapter_path, device, **kwargs)
        self.adapter_path = Path(adapter_path)
        self.base_model = base_model
        self.config = config or InferenceConfig()
        self._chat_template = None

    @property
    def engine_type(self) -> str:
        return "llm_unsloth"

    def _check_dependencies(self) -> None:
        """Check that Unsloth is installed."""
        try:
            from unsloth import FastLanguageModel  # noqa: F401
        except ImportError:
            raise DependencyError(
                package="unsloth",
                engine_type="llm",
                install_hint="pip install penguin-ai-sdk[finetuning-unsloth]"
            )

    def load(self) -> None:
        """Load the model with Unsloth optimization."""
        self._check_dependencies()

        from unsloth import FastLanguageModel

        # Determine dtype
        import torch
        dtype_map = {
            "bfloat16": torch.bfloat16,
            "float16": torch.float16,
            "float32": torch.float32,
        }
        dtype = dtype_map.get(self.config.dtype, None)

        # Load model
        self._model, self._tokenizer = FastLanguageModel.from_pretrained(
            model_name=str(self.adapter_path),
            max_seq_length=self.config.max_seq_length,
            dtype=dtype,
            load_in_4bit=self.config.load_in_4bit,
        )

        # Enable optimized inference
        FastLanguageModel.for_inference(self._model)

        self._loaded = True

    def _format_prompt(self, prompt: str) -> str:
        """Format prompt with chat template if available."""
        if self._tokenizer.chat_template:
            messages = [{"role": "user", "content": prompt}]
            return self._tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
            )
        return prompt

    def _format_messages(self, messages: List[Dict[str, str]]) -> str:
        """Format chat messages using the tokenizer's chat template."""
        if self._tokenizer.chat_template:
            return self._tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
            )

        # Fallback: simple concatenation
        formatted = ""
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            formatted += f"{role}: {content}\n"
        formatted += "assistant: "
        return formatted

    def generate(
        self,
        prompt: str,
        max_new_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None,
        **kwargs
    ) -> str:
        """
        Generate text from a prompt.

        Args:
            prompt: The input prompt
            max_new_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Nucleus sampling probability
            top_k: Top-k sampling
            **kwargs: Additional generation arguments

        Returns:
            Generated text (without the prompt)
        """
        import torch

        if not self._loaded:
            self.load()

        # Format prompt
        formatted = self._format_prompt(prompt)

        # Tokenize
        inputs = self._tokenizer(
            formatted,
            return_tensors="pt",
            add_special_tokens=True,
        ).to(self._model.device)

        # Build generation kwargs
        gen_kwargs = self.config.to_generate_kwargs()
        if max_new_tokens is not None:
            gen_kwargs["max_new_tokens"] = max_new_tokens
        if temperature is not None:
            gen_kwargs["temperature"] = temperature
        if top_p is not None:
            gen_kwargs["top_p"] = top_p
        if top_k is not None:
            gen_kwargs["top_k"] = top_k
        gen_kwargs.update(kwargs)

        # Generate
        with torch.no_grad():
            outputs = self._model.generate(
                **inputs,
                **gen_kwargs,
                pad_token_id=self._tokenizer.pad_token_id,
                eos_token_id=self._tokenizer.eos_token_id,
            )

        # Decode only the new tokens
        input_length = inputs["input_ids"].shape[1]
        generated = outputs[0][input_length:]
        response = self._tokenizer.decode(generated, skip_special_tokens=True)

        return response.strip()

    def generate_stream(
        self,
        prompt: str,
        max_new_tokens: Optional[int] = None,
        **kwargs
    ) -> Generator[str, None, None]:
        """
        Stream generated tokens.

        Args:
            prompt: The input prompt
            max_new_tokens: Maximum tokens to generate
            **kwargs: Additional generation arguments

        Yields:
            Generated tokens one at a time
        """
        import torch
        from transformers import TextIteratorStreamer
        from threading import Thread

        if not self._loaded:
            self.load()

        # Format prompt
        formatted = self._format_prompt(prompt)

        # Tokenize
        inputs = self._tokenizer(
            formatted,
            return_tensors="pt",
            add_special_tokens=True,
        ).to(self._model.device)

        # Build generation kwargs
        gen_kwargs = self.config.to_generate_kwargs()
        if max_new_tokens is not None:
            gen_kwargs["max_new_tokens"] = max_new_tokens
        gen_kwargs.update(kwargs)

        # Create streamer
        streamer = TextIteratorStreamer(
            self._tokenizer,
            skip_prompt=True,
            skip_special_tokens=True,
        )

        # Run generation in thread
        gen_kwargs["streamer"] = streamer
        gen_kwargs["pad_token_id"] = self._tokenizer.pad_token_id
        gen_kwargs["eos_token_id"] = self._tokenizer.eos_token_id

        thread = Thread(
            target=self._model.generate,
            kwargs={**inputs, **gen_kwargs}
        )
        thread.start()

        # Yield tokens
        for token in streamer:
            yield token

        thread.join()

    def chat(
        self,
        messages: List[Dict[str, str]],
        **kwargs
    ) -> str:
        """
        Generate chat completion.

        Args:
            messages: List of message dicts with 'role' and 'content'
            **kwargs: Additional generation arguments

        Returns:
            Assistant's response
        """
        if not self._loaded:
            self.load()

        # Format messages
        formatted = self._format_messages(messages)

        # Generate
        return self.generate(formatted, **kwargs)

    def chat_stream(
        self,
        messages: List[Dict[str, str]],
        **kwargs
    ) -> Generator[str, None, None]:
        """
        Stream chat completion tokens.

        Args:
            messages: List of message dicts with 'role' and 'content'
            **kwargs: Additional generation arguments

        Yields:
            Generated tokens one at a time
        """
        if not self._loaded:
            self.load()

        # Format messages
        formatted = self._format_messages(messages)

        # Stream
        yield from self.generate_stream(formatted, **kwargs)
