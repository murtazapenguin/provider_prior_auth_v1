"""
Penguin Finetuning Inference

Inference engines for finetuned models.

Four inference types are supported:
1. EmbeddingInference - Bi-encoder with sentence-transformers
2. RerankerInference - Cross-encoder scoring for query-document pairs
3. UnslothInference - Local LLM inference with 2x speed optimization
4. vLLMServer - Production LLM serving with OpenAI-compatible API

Example:
    # Embedding inference
    from penguin.finetuning.inference import EmbeddingInference

    engine = EmbeddingInference("./embedding_model")
    embeddings = engine.encode(["text1", "text2"])

    # Reranker inference
    from penguin.finetuning.inference import RerankerInference

    engine = RerankerInference("./reranker_adapter")
    scores = engine.score("query", ["doc1", "doc2"])

    # Local LLM inference
    from penguin.finetuning.inference import UnslothInference

    engine = UnslothInference("./llm_adapter")
    response = engine.generate("What is AI?")

    # Production LLM serving
    from penguin.finetuning.inference import serve
    from penguin.llm import create_client

    server = serve("meta-llama/Llama-2-7b-hf", lora_adapters={"my-model": "./adapter"})
    server.start_background()

    client = create_client("openai", model="my-model", base_url=server.base_url)
"""

from typing import Union, Optional, Dict, Any, List
import numpy as np

# Base classes and errors
from .base import BaseInferenceEngine, InferenceError, DependencyError

# Configuration
from .config import (
    InferenceConfig,
    ServerConfig,
    EmbeddingConfig,
    RerankerConfig,
)

# Inference engines (lazy imports for optional dependencies)
def _get_embedding_inference():
    from .embedding import EmbeddingInference
    return EmbeddingInference

def _get_reranker_inference():
    from .reranker import RerankerInference
    return RerankerInference

def _get_unsloth_inference():
    from .llm_unsloth import UnslothInference
    return UnslothInference

def _get_vllm_server():
    from .llm_vllm import vLLMServer
    return vLLMServer


# Direct imports for type hints
try:
    from .embedding import EmbeddingInference
except ImportError:
    EmbeddingInference = None

try:
    from .reranker import RerankerInference
except ImportError:
    RerankerInference = None

try:
    from .llm_unsloth import UnslothInference
except ImportError:
    UnslothInference = None

try:
    from .llm_vllm import vLLMServer, serve
except ImportError:
    vLLMServer = None
    serve = None


def infer(
    model_path: str,
    input_data: Union[str, List[str]],
    model_type: str = "llm",
    backend: str = "unsloth",
    **kwargs
) -> Union[str, np.ndarray, List[float]]:
    """
    Quick inference on a finetuned model.

    Args:
        model_path: Path to the finetuned model or adapter
        input_data: Input text(s) for inference
        model_type: Type of model ("llm", "embedding", "reranker")
        backend: Backend to use ("unsloth" for LLM, ignored for others)
        **kwargs: Additional arguments passed to the inference engine

    Returns:
        - For LLM: Generated text string
        - For embedding: Numpy array of embeddings
        - For reranker: List of relevance scores

    Example:
        # LLM generation
        response = infer("./llm_adapter", "What is AI?", model_type="llm")

        # Embedding
        embeddings = infer("./embedding_model", ["text1", "text2"], model_type="embedding")

        # Reranker (input_data should be query, documents in kwargs)
        scores = infer("./reranker", "query", model_type="reranker", documents=["doc1", "doc2"])
    """
    if model_type == "llm":
        if backend == "unsloth":
            InferenceClass = _get_unsloth_inference()
            engine = InferenceClass(model_path, **kwargs)
            with engine:
                return engine.generate(input_data)
        else:
            raise ValueError(f"Unknown LLM backend: {backend}")

    elif model_type == "embedding":
        InferenceClass = _get_embedding_inference()
        engine = InferenceClass(model_path, **kwargs)
        with engine:
            return engine.encode(input_data)

    elif model_type == "reranker":
        documents = kwargs.pop("documents", [])
        if not documents:
            raise ValueError("reranker requires 'documents' keyword argument")

        InferenceClass = _get_reranker_inference()
        engine = InferenceClass(model_path, **kwargs)
        with engine:
            return engine.score(input_data, documents)

    else:
        raise ValueError(f"Unknown model_type: {model_type}")


__all__ = [
    # Base
    "BaseInferenceEngine",
    "InferenceError",
    "DependencyError",
    # Config
    "InferenceConfig",
    "ServerConfig",
    "EmbeddingConfig",
    "RerankerConfig",
    # Engines
    "EmbeddingInference",
    "RerankerInference",
    "UnslothInference",
    "vLLMServer",
    # High-level API
    "infer",
    "serve",
]
