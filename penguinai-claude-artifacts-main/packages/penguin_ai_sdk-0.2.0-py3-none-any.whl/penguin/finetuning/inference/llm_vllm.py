"""
Penguin vLLM Server

OpenAI-compatible server wrapper for serving LLMs with LoRA adapters.
"""

import subprocess
import sys
import time
import signal
import os
from typing import Optional, Dict, List, Any
from pathlib import Path

from .config import ServerConfig


class vLLMServerError(Exception):
    """Error related to vLLM server operations."""
    pass


def _find_vllm_executable() -> List[str]:
    """Find the vLLM executable or return Python module command."""
    import shutil

    # Try to find vllm in PATH
    vllm_path = shutil.which("vllm")
    if vllm_path:
        return [vllm_path, "serve"]

    # Try to find vllm in the same directory as the Python executable
    python_dir = Path(sys.executable).parent
    vllm_in_bin = python_dir / "vllm"
    if vllm_in_bin.exists():
        return [str(vllm_in_bin), "serve"]

    # Fall back to python -m vllm.entrypoints.openai.api_server
    return [sys.executable, "-m", "vllm.entrypoints.openai.api_server"]


def _get_adapter_rank(adapter_path: str) -> int:
    """
    Read LoRA rank from adapter_config.json.

    Args:
        adapter_path: Path to the LoRA adapter directory

    Returns:
        The LoRA rank (r value), defaults to 64 if not found
    """
    import json

    config_path = Path(adapter_path) / "adapter_config.json"
    if config_path.exists():
        try:
            with open(config_path) as f:
                config = json.load(f)
                return config.get("r", 64)
        except (json.JSONDecodeError, IOError):
            pass
    return 64  # Default if no config file or error


class vLLMServer:
    """
    vLLM server wrapper for serving LLMs with LoRA adapters.

    Starts a vLLM server with OpenAI-compatible API that can be used
    with the existing penguin.llm OpenAI provider.

    Example:
        server = vLLMServer(
            base_model="meta-llama/Llama-2-7b-hf",
            lora_adapters={"my-model": "./llm_adapter"},
        )

        # Start server (blocking)
        server.start()

        # Or start in background
        server.start_background()

        # Use with penguin.llm
        from penguin.llm import create_client
        client = create_client(
            "openai",
            model="my-model",
            base_url=server.base_url,
        )

        # Stop server
        server.stop()
    """

    def __init__(
        self,
        base_model: str,
        lora_adapters: Optional[Dict[str, str]] = None,
        config: Optional[ServerConfig] = None,
        **kwargs
    ):
        """
        Initialize vLLM server wrapper.

        Args:
            base_model: HuggingFace model ID for the base model
            lora_adapters: Dict mapping adapter names to paths
            config: Server configuration
            **kwargs: Additional vLLM server arguments
        """
        self.base_model = base_model
        self.lora_adapters = lora_adapters or {}
        self.config = config or ServerConfig()
        self.extra_args = kwargs

        self._process: Optional[subprocess.Popen] = None
        self._started = False
        self._log_file = None
        self._log_path: Optional[str] = None

    @property
    def base_url(self) -> str:
        """Get the base URL for the OpenAI-compatible API."""
        return self.config.get_base_url()

    @property
    def log_path(self) -> Optional[str]:
        """Get the path to the server log file."""
        return self._log_path

    @property
    def is_running(self) -> bool:
        """Check if the server is running."""
        if self._process is None:
            return False
        return self._process.poll() is None

    def build_command(self) -> List[str]:
        """
        Build the vLLM serve command.

        Returns:
            List of command arguments
        """
        # Get the vLLM executable (either 'vllm serve' or 'python -m vllm...')
        cmd = _find_vllm_executable()

        # Add model and server options
        cmd.extend([
            self.base_model,
            "--host", self.config.host,
            "--port", str(self.config.port),
        ])

        # LoRA configuration
        if self.lora_adapters and self.config.enable_lora:
            cmd.append("--enable-lora")

            for name, path in self.lora_adapters.items():
                # Resolve path
                resolved_path = str(Path(path).resolve())
                cmd.extend(["--lora-modules", f"{name}={resolved_path}"])

            cmd.extend(["--max-loras", str(self.config.max_loras)])

            # Auto-detect max rank from adapter configs
            max_rank = max(
                (_get_adapter_rank(path) for path in self.lora_adapters.values()),
                default=64
            )
            cmd.extend(["--max-lora-rank", str(max_rank)])

            if self.config.lora_dtype != "auto":
                cmd.extend(["--lora-dtype", self.config.lora_dtype])

        # Tool calling support
        if self.config.enable_auto_tool_choice:
            cmd.append("--enable-auto-tool-choice")
            cmd.extend(["--tool-call-parser", self.config.tool_call_parser])

        # Performance settings
        if self.config.tensor_parallel_size > 1:
            cmd.extend(["--tensor-parallel-size", str(self.config.tensor_parallel_size)])

        cmd.extend(["--gpu-memory-utilization", str(self.config.gpu_memory_utilization)])

        if self.config.max_model_len:
            cmd.extend(["--max-model-len", str(self.config.max_model_len)])

        if self.config.dtype != "auto":
            cmd.extend(["--dtype", self.config.dtype])

        # API key
        if self.config.api_key:
            cmd.extend(["--api-key", self.config.api_key])

        # Extra arguments
        for key, value in self.extra_args.items():
            arg_name = f"--{key.replace('_', '-')}"
            if isinstance(value, bool):
                if value:
                    cmd.append(arg_name)
            else:
                cmd.extend([arg_name, str(value)])

        return cmd

    def health_check(self) -> bool:
        """
        Check if the server is healthy and responding.

        Returns:
            True if server is responding, False otherwise
        """
        import urllib.request
        import urllib.error

        # Use localhost for health check, not the bind address (0.0.0.0)
        # 0.0.0.0 means "bind to all interfaces" but isn't a connectable address
        check_host = "127.0.0.1" if self.config.host == "0.0.0.0" else self.config.host
        health_url = f"http://{check_host}:{self.config.port}/health"

        try:
            with urllib.request.urlopen(health_url, timeout=5) as response:
                return response.status == 200
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError):
            return False

    def wait_for_startup(self, timeout: Optional[int] = None) -> bool:
        """
        Wait for the server to become healthy.

        Args:
            timeout: Maximum time to wait in seconds (default from config)

        Returns:
            True if server started successfully, False if timeout

        Raises:
            vLLMServerError: If server process exits unexpectedly
        """
        timeout = timeout or self.config.startup_timeout
        start_time = time.time()

        while time.time() - start_time < timeout:
            # Check if process is still running
            if self._process and self._process.poll() is not None:
                # Get error output from log file
                log_output = ""
                if hasattr(self, '_log_path') and self._log_path:
                    try:
                        with open(self._log_path, 'r') as f:
                            log_output = f.read()
                    except IOError:
                        pass
                error_msg = f"vLLM server exited with code {self._process.returncode}"
                if log_output:
                    # Show last 2000 chars of log
                    error_msg += f"\n\nServer output:\n{log_output[-2000:]}"
                raise vLLMServerError(error_msg)

            if self.health_check():
                return True

            time.sleep(self.config.health_check_interval)

        return False

    def start(self) -> None:
        """
        Start the vLLM server (blocking).

        This method blocks until the server is stopped (e.g., via Ctrl+C).
        """
        if self._started:
            raise vLLMServerError("Server already started")

        cmd = self.build_command()
        print(f"Starting vLLM server: {' '.join(cmd)}")

        # Run in foreground (blocking)
        try:
            subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError as e:
            raise vLLMServerError(f"vLLM server failed with exit code {e.returncode}")
        except KeyboardInterrupt:
            print("\nServer stopped by user")

    def start_background(self, wait: bool = True) -> subprocess.Popen:
        """
        Start the vLLM server in the background.

        Args:
            wait: Wait for server to become healthy before returning

        Returns:
            The subprocess.Popen object

        Raises:
            vLLMServerError: If server fails to start
        """
        if self._started:
            raise vLLMServerError("Server already started")

        cmd = self.build_command()
        print(f"Starting vLLM server in background: {' '.join(cmd)}")

        # Create log file for server output
        # Using a file instead of PIPE to avoid blocking when buffer fills up
        # (vLLM outputs a lot of progress bars during CUDA graph capture)
        import tempfile
        self._log_file = tempfile.NamedTemporaryFile(
            mode='w',
            prefix='vllm_server_',
            suffix='.log',
            delete=False
        )
        self._log_path = self._log_file.name

        # Start in background with output to file (not PIPE to avoid buffer deadlock)
        self._process = subprocess.Popen(
            cmd,
            stdout=self._log_file,
            stderr=subprocess.STDOUT,  # Merge stderr into stdout
            preexec_fn=os.setsid,  # Create new process group
        )

        self._started = True

        if wait:
            print("Waiting for server to become ready...")
            if not self.wait_for_startup():
                self.stop()
                raise vLLMServerError(
                    f"Server failed to start within {self.config.startup_timeout}s. "
                    f"Check logs at: {self._log_path}"
                )
            print(f"Server ready at {self.base_url}")

        return self._process

    def stop(self) -> None:
        """Stop the background server."""
        if self._process is None:
            return

        if self._process.poll() is None:
            # Send SIGTERM to process group
            try:
                os.killpg(os.getpgid(self._process.pid), signal.SIGTERM)
            except ProcessLookupError:
                pass

            # Wait for graceful shutdown
            try:
                self._process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                # Force kill
                try:
                    os.killpg(os.getpgid(self._process.pid), signal.SIGKILL)
                except ProcessLookupError:
                    pass
                self._process.wait()

        self._process = None
        self._started = False

        # Close log file
        if self._log_file:
            try:
                self._log_file.close()
            except IOError:
                pass
            self._log_file = None

        print("Server stopped")

    def get_client(self, model: Optional[str] = None):
        """
        Get a penguin.llm client configured for this server.

        Args:
            model: Model/adapter name to use (default: first LoRA adapter or base model)

        Returns:
            OpenAIChatClient configured for this server
        """
        from penguin.llm import create_client

        # Default to first LoRA adapter or base model
        if model is None:
            if self.lora_adapters:
                model = next(iter(self.lora_adapters.keys()))
            else:
                model = self.base_model

        return create_client(
            "openai",
            model=model,
            base_url=self.base_url,
            api_key=self.config.api_key or "not-needed",
        )

    def __enter__(self):
        """Context manager entry - start server."""
        self.start_background()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - stop server."""
        self.stop()
        return False


def serve(
    base_model: str,
    lora_adapters: Optional[Dict[str, str]] = None,
    host: str = "0.0.0.0",
    port: int = 8000,
    **kwargs
) -> vLLMServer:
    """
    Create a vLLM server instance.

    Convenience function for creating a vLLMServer.

    Args:
        base_model: HuggingFace model ID for the base model
        lora_adapters: Dict mapping adapter names to paths
        host: Server host
        port: Server port
        **kwargs: Additional server configuration

    Returns:
        vLLMServer instance (not started)

    Example:
        server = serve(
            "meta-llama/Llama-2-7b-hf",
            lora_adapters={"my-model": "./adapter"},
        )
        server.start_background()
    """
    config = ServerConfig(host=host, port=port, **kwargs)
    return vLLMServer(
        base_model=base_model,
        lora_adapters=lora_adapters,
        config=config,
    )
