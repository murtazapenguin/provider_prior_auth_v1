"""
Penguin Embedding Inference

Bi-encoder inference using sentence-transformers.
"""

import json
import os
from pathlib import Path
from typing import List, Optional, Union
import numpy as np

from .base import BaseInferenceEngine, DependencyError
from .config import EmbeddingConfig


class EmbeddingInference(BaseInferenceEngine):
    """
    Embedding inference engine using sentence-transformers.

    Loads finetuned embedding models and generates embeddings for text.

    Example:
        engine = EmbeddingInference("./embedding_model")
        embeddings = engine.encode(["text1", "text2"])

        # With context manager
        with EmbeddingInference("./embedding_model") as engine:
            embeddings = engine.encode(["query text"])
    """

    def __init__(
        self,
        model_path: str,
        device: str = "auto",
        config: Optional[EmbeddingConfig] = None,
        **kwargs
    ):
        """
        Initialize embedding inference engine.

        Args:
            model_path: Path to the finetuned embedding model
            device: Device to use ("auto", "cuda", "cpu")
            config: Embedding configuration
        """
        super().__init__(model_path, device, **kwargs)
        self.config = config or EmbeddingConfig()

    @property
    def engine_type(self) -> str:
        return "embedding"

    def _check_dependencies(self) -> None:
        """Check that sentence-transformers is installed."""
        try:
            from sentence_transformers import SentenceTransformer  # noqa: F401
        except ImportError:
            raise DependencyError(
                package="sentence-transformers",
                engine_type="embedding",
                install_hint="pip install penguin-ai-sdk[finetuning-embedding]"
            )

    def _is_lora_adapter(self) -> bool:
        """Check if the model path contains a LoRA adapter."""
        adapter_config = Path(self.model_path) / "adapter_config.json"
        return adapter_config.exists()

    def _get_base_model_from_adapter(self) -> str:
        """Get the base model ID from adapter_config.json."""
        adapter_config = Path(self.model_path) / "adapter_config.json"
        with open(adapter_config) as f:
            config = json.load(f)
        return config.get("base_model_name_or_path")

    def load(self) -> None:
        """Load the embedding model (supports both full models and LoRA adapters)."""
        self._check_dependencies()

        device = self._resolve_device()

        if self._is_lora_adapter():
            self._load_lora_adapter(device)
        else:
            self._load_sentence_transformer(device)

        self._loaded = True

    def _load_sentence_transformer(self, device: str) -> None:
        """Load a full sentence-transformers model."""
        from sentence_transformers import SentenceTransformer

        try:
            self._model = SentenceTransformer(
                str(self.model_path),
                device=device
            )
        except AttributeError as e:
            # Workaround for transformers 4.57.x bug with AutoTokenizer
            # Fall back to manual loading with transformers
            if "'dict' object has no attribute 'model_type'" in str(e):
                self._load_with_transformers_fallback(device)
            else:
                raise

    def _load_with_transformers_fallback(self, device: str) -> None:
        """Fallback loading using transformers directly (for transformers 4.57.x bug)."""
        import torch
        from transformers import AutoModel, AutoConfig

        model_path = Path(self.model_path)

        # Read config to determine tokenizer class
        config_path = model_path / "config.json"
        if config_path.exists():
            with open(config_path) as f:
                config = json.load(f)
            model_type = config.get("model_type", "")

            # Map model type to tokenizer class
            tokenizer_map = {
                "xlm-roberta": "XLMRobertaTokenizer",
                "bert": "BertTokenizer",
                "roberta": "RobertaTokenizer",
                "distilbert": "DistilBertTokenizer",
            }

            tokenizer_class_name = tokenizer_map.get(model_type)
            if tokenizer_class_name:
                from transformers import AutoTokenizer
                # Import the specific tokenizer class
                tokenizer_module = __import__('transformers', fromlist=[tokenizer_class_name])
                tokenizer_class = getattr(tokenizer_module, tokenizer_class_name)
                self._tokenizer = tokenizer_class.from_pretrained(
                    str(model_path), local_files_only=True
                )
            else:
                raise ValueError(f"Unsupported model type for fallback loading: {model_type}")
        else:
            raise FileNotFoundError(f"No config.json found at {model_path}")

        # Load model
        self._peft_model = AutoModel.from_pretrained(
            str(model_path), local_files_only=True
        )
        self._peft_model.eval()

        if device != "cpu":
            self._peft_model = self._peft_model.to(device)

        self._device = device
        self._is_peft = True  # Use PEFT encoding path (works for both)

    def _load_lora_adapter(self, device: str) -> None:
        """Load a LoRA adapter on top of the base model."""
        try:
            from transformers import AutoModel, AutoTokenizer
            from peft import PeftModel
            import torch
        except ImportError as e:
            raise DependencyError(
                package="peft",
                engine_type="embedding",
                install_hint="pip install peft transformers"
            ) from e

        # Get base model from adapter config
        base_model_id = self._get_base_model_from_adapter()
        if not base_model_id:
            raise ValueError(
                f"Could not determine base model from adapter at {self.model_path}. "
                "Ensure adapter_config.json contains 'base_model_name_or_path'."
            )

        # Load base model and tokenizer
        self._tokenizer = AutoTokenizer.from_pretrained(
            base_model_id, trust_remote_code=True
        )
        base_model = AutoModel.from_pretrained(
            base_model_id, trust_remote_code=True
        )

        # Apply LoRA adapter
        self._peft_model = PeftModel.from_pretrained(base_model, str(self.model_path))
        self._peft_model.eval()

        # Move to device
        if device != "cpu":
            self._peft_model = self._peft_model.to(device)

        self._device = device
        self._is_peft = True

    def _encode_with_peft(
        self,
        texts: List[str],
        batch_size: int,
        normalize: bool,
        show_progress_bar: bool,
    ) -> np.ndarray:
        """Encode texts using the PEFT model with mean pooling."""
        import torch

        all_embeddings = []

        # Process in batches
        for i in range(0, len(texts), batch_size):
            batch_texts = texts[i:i + batch_size]

            # Tokenize
            inputs = self._tokenizer(
                batch_texts,
                padding=True,
                truncation=True,
                max_length=512,
                return_tensors="pt"
            )

            # Move to device
            if self._device != "cpu":
                inputs = {k: v.to(self._device) for k, v in inputs.items()}

            # Forward pass
            with torch.no_grad():
                outputs = self._peft_model(**inputs)

            # Mean pooling over sequence length (excluding padding)
            attention_mask = inputs["attention_mask"]
            token_embeddings = outputs.last_hidden_state
            input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
            embeddings = torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(
                input_mask_expanded.sum(1), min=1e-9
            )

            # Normalize if requested
            if normalize:
                embeddings = torch.nn.functional.normalize(embeddings, p=2, dim=1)

            all_embeddings.append(embeddings.cpu().numpy())

        return np.vstack(all_embeddings)

    def encode(
        self,
        texts: Union[str, List[str]],
        batch_size: Optional[int] = None,
        normalize: Optional[bool] = None,
        show_progress_bar: Optional[bool] = None,
    ) -> np.ndarray:
        """
        Encode texts to embeddings.

        Args:
            texts: Single text or list of texts to encode
            batch_size: Batch size for encoding (default from config)
            normalize: Whether to normalize embeddings (default from config)
            show_progress_bar: Show progress bar (default from config)

        Returns:
            Numpy array of embeddings with shape (n_texts, embedding_dim)
        """
        if not self._loaded:
            self.load()

        # Handle single text
        if isinstance(texts, str):
            texts = [texts]

        # Use appropriate encoding method
        if getattr(self, '_is_peft', False):
            return self._encode_with_peft(
                texts,
                batch_size=batch_size or self.config.batch_size,
                normalize=normalize if normalize is not None else self.config.normalize_embeddings,
                show_progress_bar=show_progress_bar if show_progress_bar is not None else self.config.show_progress_bar,
            )

        embeddings = self._model.encode(
            texts,
            batch_size=batch_size or self.config.batch_size,
            normalize_embeddings=normalize if normalize is not None else self.config.normalize_embeddings,
            show_progress_bar=show_progress_bar if show_progress_bar is not None else self.config.show_progress_bar,
        )

        return embeddings

    def encode_queries(
        self,
        queries: Union[str, List[str]],
        **kwargs
    ) -> np.ndarray:
        """
        Encode queries for retrieval.

        Some models use different prefixes for queries vs documents.
        This method applies query-specific preprocessing if applicable.

        Args:
            queries: Query text(s) to encode
            **kwargs: Additional arguments passed to encode()

        Returns:
            Numpy array of query embeddings
        """
        if not self._loaded:
            self.load()

        # Handle single query
        if isinstance(queries, str):
            queries = [queries]

        # Check if model has query encoding method
        if hasattr(self._model, 'encode_queries'):
            return self._model.encode_queries(queries, **kwargs)

        # Fall back to standard encoding
        return self.encode(queries, **kwargs)

    def encode_documents(
        self,
        documents: Union[str, List[str]],
        **kwargs
    ) -> np.ndarray:
        """
        Encode documents for retrieval.

        Some models use different prefixes for queries vs documents.
        This method applies document-specific preprocessing if applicable.

        Args:
            documents: Document text(s) to encode
            **kwargs: Additional arguments passed to encode()

        Returns:
            Numpy array of document embeddings
        """
        if not self._loaded:
            self.load()

        # Handle single document
        if isinstance(documents, str):
            documents = [documents]

        # Check if model has document encoding method
        if hasattr(self._model, 'encode_documents'):
            return self._model.encode_documents(documents, **kwargs)

        # Fall back to standard encoding
        return self.encode(documents, **kwargs)

    @property
    def embedding_dimension(self) -> int:
        """Get the embedding dimension."""
        if not self._loaded:
            self.load()

        if getattr(self, '_is_peft', False):
            return self._peft_model.config.hidden_size

        return self._model.get_sentence_embedding_dimension()

    @property
    def model_id(self) -> str:
        """Get the model ID (base model for LoRA adapters)."""
        if self._is_lora_adapter():
            return self._get_base_model_from_adapter()
        return str(self.model_path)

    @property
    def is_lora(self) -> bool:
        """Check if this is a LoRA adapter model."""
        return self._is_lora_adapter()
