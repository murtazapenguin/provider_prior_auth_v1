"""
Penguin Finetuning Inference Configuration

Pydantic models for inference configuration.
"""

from typing import Optional, Dict, Any
from pydantic import BaseModel, Field


class InferenceConfig(BaseModel):
    """
    Configuration for text generation inference.

    Used by UnslothInference and other LLM inference engines.
    """
    # Generation parameters
    max_new_tokens: int = 256
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 50
    repetition_penalty: float = 1.0
    do_sample: bool = True

    # Stop tokens
    stop_sequences: Optional[list] = None

    # Quantization
    load_in_4bit: bool = True
    dtype: str = "bfloat16"

    # Memory
    max_seq_length: int = 4096

    def to_generate_kwargs(self) -> Dict[str, Any]:
        """Convert to kwargs for model.generate()."""
        kwargs = {
            "max_new_tokens": self.max_new_tokens,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "top_k": self.top_k,
            "repetition_penalty": self.repetition_penalty,
            "do_sample": self.do_sample,
        }
        return kwargs


class ServerConfig(BaseModel):
    """
    Configuration for vLLM server.

    Controls server startup, LoRA settings, and performance tuning.
    """
    # Network
    host: str = "0.0.0.0"
    port: int = 8000

    # LoRA settings
    enable_lora: bool = True
    max_loras: int = 4
    lora_dtype: str = "auto"  # "auto", "float16", "bfloat16"

    # Tool calling support
    enable_auto_tool_choice: bool = True
    tool_call_parser: str = "hermes"  # "hermes", "mistral", "llama3_json", etc.

    # Performance
    tensor_parallel_size: int = 1
    gpu_memory_utilization: float = 0.9
    max_model_len: Optional[int] = None
    dtype: str = "auto"  # Model dtype

    # API
    api_key: Optional[str] = None

    # Timeouts
    startup_timeout: int = 600  # seconds to wait for server startup
    health_check_interval: float = 1.0  # seconds between health checks

    def get_base_url(self) -> str:
        """Get the base URL for the server."""
        return f"http://{self.host}:{self.port}/v1"


class EmbeddingConfig(BaseModel):
    """
    Configuration for embedding inference.
    """
    batch_size: int = 32
    normalize_embeddings: bool = True
    show_progress_bar: bool = False


class RerankerConfig(BaseModel):
    """
    Configuration for reranker inference.
    """
    batch_size: int = 32
    max_length: int = 512
