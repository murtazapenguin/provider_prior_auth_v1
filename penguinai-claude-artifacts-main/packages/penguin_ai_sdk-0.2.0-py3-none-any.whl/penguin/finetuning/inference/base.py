"""
Penguin Finetuning Inference Base

Abstract base class for inference engines.
"""

import gc
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Optional


class InferenceError(Exception):
    """Base exception for inference errors."""
    pass


class DependencyError(InferenceError):
    """Raised when required dependencies are not installed."""

    def __init__(self, package: str, engine_type: str, install_hint: str = ""):
        self.package = package
        self.engine_type = engine_type
        self.install_hint = install_hint
        message = f"Required package '{package}' not installed for {engine_type} inference."
        if install_hint:
            message += f" Install with: {install_hint}"
        super().__init__(message)


class BaseInferenceEngine(ABC):
    """
    Abstract base class for inference engines.

    All inference engines (embedding, reranker, LLM) inherit from this.
    Provides common functionality like GPU cleanup and context manager support.
    """

    def __init__(
        self,
        model_path: str,
        device: str = "auto",
        **kwargs
    ):
        """
        Initialize the inference engine.

        Args:
            model_path: Path to the finetuned model or adapter
            device: Device to use ("auto", "cuda", "cpu")
            **kwargs: Additional engine-specific arguments
        """
        self.model_path = Path(model_path)
        self.device = device
        self._model = None
        self._tokenizer = None
        self._loaded = False

    @property
    @abstractmethod
    def engine_type(self) -> str:
        """Return the type of inference engine."""
        pass

    @abstractmethod
    def _check_dependencies(self) -> None:
        """Check that required dependencies are installed."""
        pass

    @abstractmethod
    def load(self) -> None:
        """Load the model into memory."""
        pass

    def is_loaded(self) -> bool:
        """Check if model is loaded."""
        return self._loaded

    def cleanup(self) -> None:
        """Clean up GPU memory."""
        self._model = None
        self._tokenizer = None
        self._loaded = False

        gc.collect()

        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                torch.cuda.ipc_collect()
        except ImportError:
            pass

    def _resolve_device(self) -> str:
        """Resolve 'auto' device to actual device."""
        if self.device != "auto":
            return self.device

        try:
            import torch
            return "cuda" if torch.cuda.is_available() else "cpu"
        except ImportError:
            return "cpu"

    def __enter__(self):
        """Context manager entry."""
        if not self._loaded:
            self.load()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit with cleanup."""
        self.cleanup()
        return False
