"""
Penguin Finetuning Model Registry

Centralized model definitions for finetuning.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional


class TrainerType(str, Enum):
    """Types of finetuning trainers."""
    LLM = "llm"
    RERANKER = "reranker"
    EMBEDDING = "embedding"


@dataclass
class FinetuneModelInfo:
    """
    Finetuning model metadata.

    Attributes:
        id: Friendly name (e.g., "qwen3-4b")
        trainer_type: Which trainer this model works with
        hf_model_id: HuggingFace model identifier
        instruction_template: Template parts for chat formatting (LLM only)
        max_seq_length: Maximum sequence length
        description: Human-readable description
        thinking_start: Start token for thinking/reasoning (e.g., "<|think|>")
        thinking_end: End token for thinking/reasoning (e.g., "<|/think|>")
    """
    id: str
    trainer_type: TrainerType
    hf_model_id: str
    instruction_template: Optional[Dict[str, str]] = None
    max_seq_length: int = 32000
    description: str = ""
    thinking_start: Optional[str] = None
    thinking_end: Optional[str] = None


# =============================================================================
# LLM FINETUNING MODELS (Unsloth-optimized)
# =============================================================================

LLM_MODELS: Dict[str, FinetuneModelInfo] = {
    "qwen3-4b": FinetuneModelInfo(
        id="qwen3-4b",
        trainer_type=TrainerType.LLM,
        hf_model_id="unsloth/Qwen3-4B-unsloth-bnb-4bit",
        instruction_template={
            "instruction_part": "<|im_start|>user",
            "response_part": "<|im_start|>assistant",
        },
        max_seq_length=32000,
        description="Qwen3 4B - Fast, efficient for basic tasks",
        thinking_start="<|think|>",
        thinking_end="<|/think|>",
    ),
    "qwen3-14b": FinetuneModelInfo(
        id="qwen3-14b",
        trainer_type=TrainerType.LLM,
        hf_model_id="unsloth/Qwen3-14B-unsloth-bnb-4bit",
        instruction_template={
            "instruction_part": "<|im_start|>user",
            "response_part": "<|im_start|>assistant",
        },
        max_seq_length=32000,
        description="Qwen3 14B - Balanced performance (default)",
        thinking_start="<|think|>",
        thinking_end="<|/think|>",
    ),
    "phi-4": FinetuneModelInfo(
        id="phi-4",
        trainer_type=TrainerType.LLM,
        hf_model_id="unsloth/phi-4-unsloth-bnb-4bit",
        instruction_template={
            "instruction_part": "<|im_start|>user",
            "response_part": "<|im_start|>assistant",
        },
        max_seq_length=32000,
        description="Phi-4 - Microsoft's efficient model",
        thinking_start="<think>",
        thinking_end="</think>",
    ),
    "gemma3-27b": FinetuneModelInfo(
        id="gemma3-27b",
        trainer_type=TrainerType.LLM,
        hf_model_id="unsloth/gemma-3-27b-it-unsloth-bnb-4bit",
        instruction_template={
            "instruction_part": "<start_of_turn>user",
            "response_part": "<start_of_turn>model",
        },
        max_seq_length=32000,
        description="Gemma3 27B - Google's powerful model (no thinking token support)",
        # No official thinking tokens for Gemma 3
    ),
    "mistral-small": FinetuneModelInfo(
        id="mistral-small",
        trainer_type=TrainerType.LLM,
        hf_model_id="unsloth/Mistral-Small-3.1-24B-Instruct-2503",
        instruction_template={
            "instruction_part": "[INST]",
            "response_part": "[/INST]",
        },
        max_seq_length=32000,
        description="Mistral Small 24B",
        thinking_start="<think>",
        thinking_end="</think>",
    ),
    "llama-3.1-8b": FinetuneModelInfo(
        id="llama-3.1-8b",
        trainer_type=TrainerType.LLM,
        hf_model_id="unsloth/Meta-Llama-3.1-8B-Instruct-bnb-4bit",
        instruction_template={
            "instruction_part": "<|start_header_id|>user<|end_header_id|>",
            "response_part": "<|start_header_id|>assistant<|end_header_id|>",
        },
        max_seq_length=90000,
        description="Llama 3.1 8B - Meta's instruction-tuned model (no thinking token support)",
        # No official thinking tokens for Llama 3.1
    ),
}


# =============================================================================
# RERANKER MODELS
# =============================================================================

RERANKER_MODELS: Dict[str, FinetuneModelInfo] = {
    "bge-m3": FinetuneModelInfo(
        id="bge-m3",
        trainer_type=TrainerType.RERANKER,
        hf_model_id="BAAI/bge-m3",
        max_seq_length=8192,
        description="BGE M3 - Multi-lingual, multi-task (default)",
    ),
    "bge-reranker-v2-m3": FinetuneModelInfo(
        id="bge-reranker-v2-m3",
        trainer_type=TrainerType.RERANKER,
        hf_model_id="BAAI/bge-reranker-v2-m3",
        max_seq_length=8192,
        description="BGE Reranker V2 M3 - Optimized for reranking",
    ),
    "bge-reranker-large": FinetuneModelInfo(
        id="bge-reranker-large",
        trainer_type=TrainerType.RERANKER,
        hf_model_id="BAAI/bge-reranker-large",
        max_seq_length=512,
        description="BGE Reranker Large",
    ),
    "bge-reranker-base": FinetuneModelInfo(
        id="bge-reranker-base",
        trainer_type=TrainerType.RERANKER,
        hf_model_id="BAAI/bge-reranker-base",
        max_seq_length=512,
        description="BGE Reranker Base - Efficient",
    ),
}


# =============================================================================
# EMBEDDING MODELS
# =============================================================================

EMBEDDING_MODELS: Dict[str, FinetuneModelInfo] = {
    "bge-m3-embedding": FinetuneModelInfo(
        id="bge-m3-embedding",
        trainer_type=TrainerType.EMBEDDING,
        hf_model_id="BAAI/bge-m3",
        max_seq_length=8192,
        description="BGE M3 - Multi-task embedding model (default)",
    ),
    "gte-qwen2-1.5b": FinetuneModelInfo(
        id="gte-qwen2-1.5b",
        trainer_type=TrainerType.EMBEDDING,
        hf_model_id="Alibaba-NLP/gte-Qwen2-1.5B-instruct",
        max_seq_length=8192,
        description="GTE Qwen2 1.5B - Instruction-following embeddings",
    ),
    "e5-large-v2": FinetuneModelInfo(
        id="e5-large-v2",
        trainer_type=TrainerType.EMBEDDING,
        hf_model_id="intfloat/e5-large-v2",
        max_seq_length=512,
        description="E5 Large V2 - General-purpose embeddings",
    ),
    "bge-large-en-v1.5": FinetuneModelInfo(
        id="bge-large-en-v1.5",
        trainer_type=TrainerType.EMBEDDING,
        hf_model_id="BAAI/bge-large-en-v1.5",
        max_seq_length=512,
        description="BGE Large EN v1.5 - English embeddings",
    ),
}


# =============================================================================
# COMBINED REGISTRY
# =============================================================================

ALL_MODELS: Dict[str, FinetuneModelInfo] = {
    **LLM_MODELS,
    **RERANKER_MODELS,
    **EMBEDDING_MODELS,
}


# =============================================================================
# DEFAULT MODELS
# =============================================================================

DEFAULT_MODELS: Dict[TrainerType, str] = {
    TrainerType.LLM: "qwen3-14b",
    TrainerType.RERANKER: "bge-m3",
    TrainerType.EMBEDDING: "bge-m3-embedding",
}


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_model(model_id: str) -> Optional[FinetuneModelInfo]:
    """
    Get model info by ID.

    Args:
        model_id: Friendly model name (e.g., "qwen3-14b")

    Returns:
        FinetuneModelInfo or None if not found
    """
    return ALL_MODELS.get(model_id)


def list_models(trainer_type: Optional[str] = None) -> List[FinetuneModelInfo]:
    """
    List all available models, optionally filtered by trainer type.

    Args:
        trainer_type: Filter by trainer type ("llm", "reranker", "embedding")

    Returns:
        List of FinetuneModelInfo
    """
    models = list(ALL_MODELS.values())
    if trainer_type:
        try:
            tt = TrainerType(trainer_type)
            models = [m for m in models if m.trainer_type == tt]
        except ValueError:
            return []
    return models


def get_default_model(trainer_type: str) -> str:
    """
    Get default model ID for a trainer type.

    Args:
        trainer_type: "llm", "reranker", or "embedding"

    Returns:
        Default model ID

    Raises:
        ValueError: If trainer type is unknown
    """
    try:
        tt = TrainerType(trainer_type)
        return DEFAULT_MODELS.get(tt, list(DEFAULT_MODELS.values())[0])
    except ValueError:
        raise ValueError(
            f"Unknown trainer type: '{trainer_type}'. "
            f"Valid types: {', '.join(t.value for t in TrainerType)}"
        )


def resolve_model_id(model_id: str, trainer_type: str) -> str:
    """
    Resolve model ID to HuggingFace model ID.

    If model_id is a known friendly name, returns the HuggingFace ID.
    Otherwise, assumes it's already a HuggingFace ID.

    Args:
        model_id: Friendly name or HuggingFace ID
        trainer_type: Expected trainer type

    Returns:
        HuggingFace model ID

    Raises:
        ValueError: If model exists but is for wrong trainer type
    """
    model = get_model(model_id)
    if model:
        tt = TrainerType(trainer_type)
        if model.trainer_type != tt:
            raise ValueError(
                f"Model '{model_id}' is for {model.trainer_type.value}, "
                f"not {trainer_type}"
            )
        return model.hf_model_id
    # Assume it's already a HuggingFace model ID
    return model_id


def get_models_by_type(trainer_type: str) -> Dict[str, FinetuneModelInfo]:
    """
    Get all models for a specific trainer type.

    Args:
        trainer_type: "llm", "reranker", or "embedding"

    Returns:
        Dictionary of model_id -> FinetuneModelInfo
    """
    if trainer_type == "llm":
        return LLM_MODELS
    elif trainer_type == "reranker":
        return RERANKER_MODELS
    elif trainer_type == "embedding":
        return EMBEDDING_MODELS
    else:
        return {}
