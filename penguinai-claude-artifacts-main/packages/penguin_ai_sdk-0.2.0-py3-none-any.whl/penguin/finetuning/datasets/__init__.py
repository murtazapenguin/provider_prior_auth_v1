"""
Penguin Finetuning Datasets

Dataset utilities for different training types.
"""

from typing import List, Dict, Any, Optional
from pathlib import Path


def validate_llm_dataset(dataset_path: str, input_column: str = "input", output_column: str = "output") -> Dict[str, Any]:
    """
    Validate an LLM training dataset.

    Args:
        dataset_path: Path to CSV file
        input_column: Name of input column
        output_column: Name of output column

    Returns:
        Dict with validation results
    """
    import pandas as pd

    path = Path(dataset_path)
    if not path.exists():
        return {"valid": False, "error": f"File not found: {dataset_path}"}

    if not path.suffix.lower() == ".csv":
        return {"valid": False, "error": "Expected CSV file"}

    try:
        df = pd.read_csv(path)

        errors = []
        if input_column not in df.columns:
            errors.append(f"Missing input column: {input_column}")
        if output_column not in df.columns:
            errors.append(f"Missing output column: {output_column}")

        if errors:
            return {"valid": False, "errors": errors}

        # Count null values
        null_inputs = df[input_column].isnull().sum()
        null_outputs = df[output_column].isnull().sum()

        return {
            "valid": True,
            "rows": len(df),
            "columns": list(df.columns),
            "null_inputs": int(null_inputs),
            "null_outputs": int(null_outputs),
        }
    except Exception as e:
        return {"valid": False, "error": str(e)}


def validate_reranker_dataset(
    dataset_path: str,
    query_column: str = "query",
    positive_column: str = "pos",
    negative_column: str = "neg"
) -> Dict[str, Any]:
    """
    Validate a reranker training dataset.

    Args:
        dataset_path: Path to directory with JSONL files
        query_column: Name of query column
        positive_column: Name of positive passages column
        negative_column: Name of negative passages column

    Returns:
        Dict with validation results
    """
    import json

    path = Path(dataset_path)

    if not path.exists():
        return {"valid": False, "error": f"Path not found: {dataset_path}"}

    # Find JSONL files
    if path.is_file():
        files = [path]
    else:
        files = list(path.glob("*.jsonl")) + list(path.glob("*.json"))

    if not files:
        return {"valid": False, "error": "No JSON/JSONL files found"}

    total_examples = 0
    errors = []
    missing_pos = 0
    missing_neg = 0

    for file_path in files:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                for line_num, line in enumerate(f, 1):
                    if not line.strip():
                        continue

                    data = json.loads(line)
                    total_examples += 1

                    if query_column not in data:
                        errors.append(f"{file_path.name}:{line_num} missing {query_column}")
                    if positive_column not in data or not data[positive_column]:
                        missing_pos += 1
                    if negative_column not in data or not data[negative_column]:
                        missing_neg += 1

        except json.JSONDecodeError as e:
            errors.append(f"{file_path.name}: JSON error - {e}")
        except Exception as e:
            errors.append(f"{file_path.name}: {e}")

    if errors and len(errors) > 5:
        errors = errors[:5] + [f"... and {len(errors) - 5} more errors"]

    return {
        "valid": len(errors) == 0 and total_examples > 0,
        "files": len(files),
        "examples": total_examples,
        "missing_positives": missing_pos,
        "missing_negatives": missing_neg,
        "errors": errors if errors else None,
    }


def validate_embedding_dataset(
    dataset_path: str,
    anchor_column: str = "anchor",
    positive_column: str = "positive",
    negative_column: str = "negative"
) -> Dict[str, Any]:
    """
    Validate an embedding training dataset.

    Args:
        dataset_path: Path to JSONL file or directory
        anchor_column: Name of anchor text column
        positive_column: Name of positive text column
        negative_column: Name of negative text column

    Returns:
        Dict with validation results
    """
    import json

    path = Path(dataset_path)

    if not path.exists():
        return {"valid": False, "error": f"Path not found: {dataset_path}"}

    if path.is_file():
        files = [path]
    else:
        files = list(path.glob("*.jsonl")) + list(path.glob("*.json"))

    if not files:
        return {"valid": False, "error": "No JSON/JSONL files found"}

    total_examples = 0
    triplets = 0
    pairs = 0
    errors = []

    for file_path in files:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue

                    data = json.loads(line)
                    total_examples += 1

                    has_anchor = anchor_column in data and data[anchor_column]
                    has_positive = positive_column in data and data[positive_column]
                    has_negative = negative_column in data and data[negative_column]

                    if has_anchor and has_positive and has_negative:
                        triplets += 1
                    elif has_anchor and has_positive:
                        pairs += 1

        except json.JSONDecodeError as e:
            errors.append(f"{file_path.name}: JSON error - {e}")
        except Exception as e:
            errors.append(f"{file_path.name}: {e}")

    valid_examples = triplets + pairs

    return {
        "valid": valid_examples > 0 and len(errors) == 0,
        "files": len(files),
        "total_examples": total_examples,
        "triplets": triplets,
        "pairs": pairs,
        "invalid_examples": total_examples - valid_examples,
        "errors": errors if errors else None,
    }


__all__ = [
    "validate_llm_dataset",
    "validate_reranker_dataset",
    "validate_embedding_dataset",
]
