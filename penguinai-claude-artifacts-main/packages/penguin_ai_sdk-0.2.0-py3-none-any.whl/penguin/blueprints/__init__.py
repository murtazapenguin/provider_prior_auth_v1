"""
Penguin Blueprints Module

Store and retrieve reusable workflow/code patterns.

Example:
    ```python
    from penguin.llm import create_client
    from penguin.blueprints import BlueprintRegistry, Blueprint

    client = create_client("gemini", model="gemini-2.0-flash")
    registry = BlueprintRegistry(client)

    # Add a new blueprint
    registry.add_blueprint(
        name="hcc_extraction_pdf",
        description="Extracts HCC codes from a scanned PDF using OCR + LLM",
        workflow="1. OCR the PDF 2. Extract codes using LLM",
        code="def extract_hcc(pdf_path): ...",
        tags=["medical", "extraction", "pdf"]
    )

    # Search methods (no LLM, fast):
    blueprint = registry.find_blueprint("extract HCC")  # Best match
    results = registry.search_blueprints("medical codes")  # Multiple matches with scores
    results = registry.search_by_tags(["medical", "extraction"])  # By tags

    # LLM-based semantic search (slower, more accurate):
    blueprint = await registry.find_relevant_blueprint("Extract CPT codes from PDF")
    ```
"""

from .models import Blueprint, Skill  # Skill is alias for backwards compat
from .registry import BlueprintRegistry, SkillRegistry  # SkillRegistry is alias

__all__ = [
    "Blueprint",
    "BlueprintRegistry",
    # Backwards compatibility
    "Skill",
    "SkillRegistry",
]
