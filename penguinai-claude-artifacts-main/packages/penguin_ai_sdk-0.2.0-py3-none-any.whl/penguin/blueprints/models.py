from pydantic import BaseModel
from typing import Optional, List, Dict, Any

class Blueprint(BaseModel):
    """A reusable workflow/code pattern that can be applied to similar tasks."""
    name: str           # Unique identifier (e.g., "hcc_extraction_pdf")
    description: str    # "Extracts HCC codes from a scanned PDF using OCR + LLM"
    workflow: str       # The textual strategy/workflow
    code: str           # The successful Python code
    tags: List[str] = []
    implementation_hints: List[str] = []  # Hints for code generation (LLM vs code, models, etc.)


# Backwards compatibility alias
Skill = Blueprint