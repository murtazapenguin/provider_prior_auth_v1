import json
import logging
import re
from difflib import SequenceMatcher
from pathlib import Path
from typing import List, Optional, Dict, Any, Tuple, Set
from .models import Blueprint
from ..llm.base import BaseChatCompletionClient
from ..llm.messages import UserMessage

logger = logging.getLogger("penguin.blueprints")

# Default storage location in user's home directory
DEFAULT_STORAGE_PATH = Path.home() / ".penguin" / "blueprints.json"


class BlueprintRegistry:
    """
    Registry for storing and retrieving reusable workflow/code blueprints.

    Blueprints are persisted to disk as JSON and can be retrieved using
    LLM-based semantic matching.

    Example:
        ```python
        from penguin.llm import create_client
        from penguin.blueprints import BlueprintRegistry

        client = create_client("bedrock", model="claude-sonnet-4-5")
        registry = BlueprintRegistry(client)

        # Add a blueprint
        registry.add_blueprint(
            name="hcc_extraction",
            description="Extract HCC codes from medical documents",
            workflow="1. OCR document 2. Extract codes with LLM",
            code="def extract_hcc(doc): ...",
            tags=["medical", "extraction"]
        )

        # Find relevant blueprint for new task
        blueprint = await registry.find_relevant_blueprint("Extract CPT codes")
        ```
    """

    def __init__(
        self,
        llm_provider: BaseChatCompletionClient,
        storage_path: Optional[str] = None
    ):
        """
        Initialize the blueprint registry.

        Args:
            llm_provider: Any LLM client (Bedrock, Gemini, OpenAI) for semantic search
            storage_path: Path to JSON storage file. Defaults to ~/.penguin/blueprints.json
        """
        self.llm = llm_provider

        # Use default path if not specified
        if storage_path is None:
            self.storage_path = DEFAULT_STORAGE_PATH
        else:
            self.storage_path = Path(storage_path)

        # Ensure parent directory exists
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)

        self.blueprints: Dict[str, Blueprint] = {}
        self._load_from_disk()

    # --- 1. CRUD Operations ---

    def add_blueprint(
        self,
        name: str,
        description: str,
        workflow: str,
        code: str = "",
        tags: Optional[List[str]] = None,
        implementation_hints: Optional[List[str]] = None
    ) -> Blueprint:
        """
        Add a new blueprint to the registry.

        Args:
            name: Unique identifier for the blueprint
            description: Human-readable description of what this blueprint does
            workflow: The workflow/strategy text
            code: Optional generated code (can be added later)
            tags: Optional list of tags for categorization
            implementation_hints: Optional list of hints for code generation

        Returns:
            The created Blueprint object

        Raises:
            ValueError: If a blueprint with this name already exists
        """
        if name in self.blueprints:
            raise ValueError(f"Blueprint '{name}' already exists. Use update_blueprint() to modify.")

        blueprint = Blueprint(
            name=name,
            description=description,
            workflow=workflow,
            code=code,
            tags=tags or [],
            implementation_hints=implementation_hints or []
        )
        self.blueprints[name] = blueprint
        self._save_to_disk()
        logger.info(f"Blueprint '{name}' added to registry.")
        return blueprint

    def update_blueprint(
        self,
        name: str,
        description: Optional[str] = None,
        workflow: Optional[str] = None,
        code: Optional[str] = None,
        tags: Optional[List[str]] = None,
        implementation_hints: Optional[List[str]] = None
    ) -> Blueprint:
        """
        Update an existing blueprint.

        Args:
            name: Name of the blueprint to update
            description: New description (if provided)
            workflow: New workflow (if provided)
            code: New code (if provided)
            tags: New tags (if provided)
            implementation_hints: New implementation hints (if provided)

        Returns:
            The updated Blueprint object

        Raises:
            KeyError: If blueprint doesn't exist
        """
        if name not in self.blueprints:
            raise KeyError(f"Blueprint '{name}' not found.")

        bp = self.blueprints[name]

        # Update only provided fields
        updated = Blueprint(
            name=name,
            description=description if description is not None else bp.description,
            workflow=workflow if workflow is not None else bp.workflow,
            code=code if code is not None else bp.code,
            tags=tags if tags is not None else bp.tags,
            implementation_hints=implementation_hints if implementation_hints is not None else bp.implementation_hints
        )

        self.blueprints[name] = updated
        self._save_to_disk()
        logger.info(f"Blueprint '{name}' updated.")
        return updated

    def delete_blueprint(self, name: str) -> bool:
        """
        Delete a blueprint from the registry.

        Args:
            name: Name of the blueprint to delete

        Returns:
            True if deleted, False if not found
        """
        if name in self.blueprints:
            del self.blueprints[name]
            self._save_to_disk()
            logger.info(f"Blueprint '{name}' deleted.")
            return True
        return False

    def get_blueprint(self, name: str) -> Optional[Blueprint]:
        """Get a blueprint by name."""
        return self.blueprints.get(name)

    def list_blueprints(self) -> List[Dict[str, Any]]:
        """
        List all blueprints in the registry.

        Returns:
            List of dicts with name, description, tags, and metadata for each blueprint
        """
        return [
            {
                "name": bp.name,
                "description": bp.description,
                "tags": bp.tags,
                "has_code": bool(bp.code),
                "has_hints": bool(bp.implementation_hints),
                "hints_count": len(bp.implementation_hints)
            }
            for bp in self.blueprints.values()
        ]

    def __len__(self) -> int:
        """Return number of blueprints in registry."""
        return len(self.blueprints)

    # --- 2. Search Helper Methods ---

    def _normalize_text(self, text: str) -> str:
        """
        Normalize text for matching: lowercase, remove special chars, standardize.

        Examples:
            "ICD-10" → "icd10"
            "ICD 10" → "icd 10"
            "Extract_HCC" → "extracthcc"
        """
        text = text.lower()
        text = re.sub(r'[^a-z0-9\s]', '', text)  # Remove special chars (keep spaces)
        text = re.sub(r'\s+', ' ', text).strip()  # Normalize whitespace
        return text

    def _tokenize(self, text: str) -> Set[str]:
        """Split normalized text into word tokens."""
        normalized = self._normalize_text(text)
        return set(normalized.split()) if normalized else set()

    def _word_similarity(self, word1: str, word2: str) -> float:
        """
        Calculate similarity between two words.

        Returns:
            1.0: Exact match
            0.85: Partial match (one word contains the other)
            0.0-1.0: Fuzzy match using SequenceMatcher
        """
        if word1 == word2:
            return 1.0
        # Partial match: "extract" in "extraction"
        if word1 in word2 or word2 in word1:
            return 0.85
        # Fuzzy match for typos
        return SequenceMatcher(None, word1, word2).ratio()

    def _calculate_relevance(self, query_tokens: Set[str], doc_tokens: Set[str]) -> float:
        """
        Calculate relevance score based on word-level matching.

        For each query word, finds the best matching document word.
        Final score is normalized by query length.

        Returns:
            0.0-1.0 relevance score
        """
        if not query_tokens or not doc_tokens:
            return 0.0

        total_score = 0.0
        for q_word in query_tokens:
            best_match = max(
                (self._word_similarity(q_word, d_word) for d_word in doc_tokens),
                default=0.0
            )
            total_score += best_match

        # Normalize by query length
        return total_score / len(query_tokens)

    # --- 3. LLM Search ---
    async def llm_search(self, task: str) -> Optional[Blueprint]:
        """
        Use LLM to find the most semantically relevant blueprint for a task.

        The LLM understands intent and can match tasks that are conceptually
        similar even if they use different words.

        Args:
            task: Natural language description of what you want to do

        Returns:
            Best matching Blueprint, or None if nothing relevant

        Example:
            ```python
            # LLM understands "CPT codes" is similar to "HCC codes"
            bp = await registry.llm_search("Extract CPT codes from scanned PDFs")
            # Returns: hcc_extraction blueprint
            ```
        """
        if not self.blueprints:
            return None

        # Prepare the "Index Card" for the Librarian
        blueprints_index = ""
        for name, blueprint in self.blueprints.items():
            blueprints_index += f"- NAME: {name}\n  DESC: {blueprint.description}\n  TAGS: {', '.join(blueprint.tags)}\n\n"

        prompt = f"""
        SYSTEM: You are a smart Librarian for a Code Library.

        CONTEXT: We have a list of existing 'Blueprints' (solved coding tasks).
        CURRENT TASK: "{task}"

        AVAILABLE BLUEPRINTS INDEX:
        {blueprints_index}

        INSTRUCTION:
        1. Analyze the CURRENT TASK.
        2. Look through the BLUEPRINTS INDEX.
        3. Identify if ANY existing blueprint is highly relevant or can serve as a template.
           - Example: If task is "Extract CPT codes" and blueprint is "Extract HCC codes", that IS relevant.
        4. Return ONLY the `NAME` of the best match.
        5. If nothing is relevant, return 'NONE'.
        """

        # Use thinking=False because this is a simple classification task
        response = await self.llm.create([UserMessage(prompt)])
        match_name = response.content.strip()

        if "NONE" in match_name.upper():
            return None

        # Clean up output just in case (e.g., if LLM says "The match is name")
        for name in self.blueprints.keys():
            if name in match_name:
                logger.info(f"Found relevant blueprint: {name}")
                return self.blueprints[name]

        return None

    # --- 4. Text Search (Fast, No LLM) ---

    def find_by_text(
        self,
        query: str,
        min_score: float = 0.4,
        max_results: int = 5
    ) -> List[Tuple[Blueprint, float]]:
        """
        Find blueprints by text using word-level fuzzy matching.

        Fast search (no LLM call) that:
        - Normalizes text (ICD-10 → icd10)
        - Matches individual words
        - Handles partial matches: "extract" → "extraction"
        - Returns multiple results with relevance scores

        Args:
            query: Search query string
            min_score: Minimum relevance score (0.0-1.0), default 0.4
            max_results: Maximum number of results to return

        Returns:
            List of (Blueprint, score) tuples, sorted by relevance (highest first)

        Example:
            ```python
            results = registry.find_by_text("HCC extraction")
            for bp, score in results:
                print(f"{bp.name}: {score:.2f}")
            ```
        """
        if not self.blueprints:
            return []

        query_tokens = self._tokenize(query)
        if not query_tokens:
            return []

        results: List[Tuple[Blueprint, float]] = []

        for name, blueprint in self.blueprints.items():
            # Check exact name match first (normalized)
            if self._normalize_text(query) == self._normalize_text(name):
                results.append((blueprint, 1.0))
                continue

            # Build searchable text from name, description, and tags
            doc_text = f"{name} {blueprint.description} {' '.join(blueprint.tags)}"
            doc_tokens = self._tokenize(doc_text)

            # Calculate word-level relevance
            score = self._calculate_relevance(query_tokens, doc_tokens)

            if score >= min_score:
                results.append((blueprint, round(score, 3)))

        # Sort by score descending
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:max_results]

    # --- 5. Tag Search ---

    def find_by_tags(self, tags: List[str], match_all: bool = False) -> List[Blueprint]:
        """
        Find blueprints by tags.

        Args:
            tags: List of tags to search for
            match_all: If True, blueprint must have ALL tags. If False, ANY tag matches.

        Returns:
            List of matching blueprints

        Example:
            ```python
            # Find blueprints with ANY of these tags
            results = registry.find_by_tags(["medical", "extraction"])

            # Find blueprints with ALL these tags
            results = registry.find_by_tags(["medical", "extraction"], match_all=True)
            ```
        """
        if not tags:
            return []

        tags_lower = {t.lower() for t in tags}
        results = []

        for blueprint in self.blueprints.values():
            bp_tags_lower = {t.lower() for t in blueprint.tags}

            if match_all:
                # All query tags must be in blueprint tags
                if tags_lower.issubset(bp_tags_lower):
                    results.append(blueprint)
            else:
                # Any query tag matches
                if tags_lower & bp_tags_lower:  # Intersection
                    results.append(blueprint)

        return results

    # --- Storage Helpers ---

    def _save_to_disk(self) -> None:
        """Save all blueprints to disk as JSON."""
        data = {k: v.model_dump() for k, v in self.blueprints.items()}
        try:
            self.storage_path.write_text(json.dumps(data, indent=2))
            logger.debug(f"Saved {len(data)} blueprints to {self.storage_path}")
        except Exception as e:
            logger.error(f"Failed to save blueprints to {self.storage_path}: {e}")

    def _load_from_disk(self) -> None:
        """Load blueprints from disk JSON file."""
        if self.storage_path.exists():
            try:
                data = json.loads(self.storage_path.read_text())
                for name, props in data.items():
                    self.blueprints[name] = Blueprint(**props)
                logger.debug(f"Loaded {len(data)} blueprints from {self.storage_path}")
            except json.JSONDecodeError as e:
                logger.error(f"Invalid JSON in {self.storage_path}: {e}")
            except Exception as e:
                logger.error(f"Failed to load blueprints from {self.storage_path}: {e}")

    def export_to_file(self, path: str) -> None:
        """Export blueprints to a specific file path."""
        data = {k: v.model_dump() for k, v in self.blueprints.items()}
        Path(path).write_text(json.dumps(data, indent=2))
        logger.info(f"Exported {len(data)} blueprints to {path}")

    def import_from_file(self, path: str, overwrite: bool = False) -> int:
        """
        Import blueprints from a JSON file.

        Args:
            path: Path to the JSON file
            overwrite: If True, overwrite existing blueprints with same name

        Returns:
            Number of blueprints imported
        """
        data = json.loads(Path(path).read_text())
        imported = 0
        for name, props in data.items():
            if name in self.blueprints and not overwrite:
                logger.warning(f"Skipping '{name}' - already exists (use overwrite=True)")
                continue
            self.blueprints[name] = Blueprint(**props)
            imported += 1
        self._save_to_disk()
        logger.info(f"Imported {imported} blueprints from {path}")
        return imported


# Backwards compatibility alias
SkillRegistry = BlueprintRegistry