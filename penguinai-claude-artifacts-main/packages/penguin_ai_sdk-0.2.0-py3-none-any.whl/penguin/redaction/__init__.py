"""
Penguin PII Redaction Module

API-based PII detection and redaction.

Usage:
    from penguin.redaction import PenguinPIIRedactor

    redactor = PenguinPIIRedactor()

    # Simple redaction
    redacted = redactor.redact("John Smith's email is john@example.com")

    # Detect entities
    entities = redactor.predict("Contact Jane at jane@corp.com")

    # Full details
    result = redactor.redact_with_details("Call 555-1234")
"""

from .models import PIIEntity, RedactionResult
from .base import BaseRedactor
from .providers.penguin_pii import PenguinPIIRedactor

__all__ = [
    "PIIEntity",
    "RedactionResult",
    "BaseRedactor",
    "PenguinPIIRedactor",
]
